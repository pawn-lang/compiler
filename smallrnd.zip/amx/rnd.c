/*

cell size _MUST_ be 32bit.
forseeable problems on 16bit machines.
unknown about 64bit machines.

*/

#include "amx.h"
#include <time.h>

#define RNG_M 2147483647L	/* m = 2^31 - 1 */
#define RNG_A 48271L
#define RNG_Q 127773L		/* m div a */
#define RNG_R 2836L			/* m mod a */

cell rnd_seed;

cell set_rnd_seed(AMX *amx, cell *params);
cell reset_rnd_seed(AMX *amx, cell *params);
cell get_rnd_seed(AMX *amx, cell *params);
cell rnd(AMX *amx, cell *params);

cell df_rnd(void);
void df_set_rnd_seed(cell s);

/**[ INTERNAL HELPER ROUTINES ]*********************************************/

cell df_rnd(void)
{
	cell low, high, test;

	high = rnd_seed / RNG_Q;
	low = rnd_seed % RNG_Q;
	test = RNG_A * low - RNG_R * high;
	if(test>0)
		rnd_seed = test;
	else
		rnd_seed = test + RNG_M;

	return rnd_seed;
}

void df_set_rnd_seed(cell s)
{
	rnd_seed=s;
}

/**[ AMX ROUTINES ]*******************************************************/

cell reset_rnd_seed(AMX *amx, cell *params)
{
	df_set_rnd_seed((time(NULL)%(RNG_M-1))+1);
	return 0;
}

cell set_rnd_seed(AMX *amx, cell *params)
{
	df_set_rnd_seed(params[1]);
	return 0;
}

cell get_rnd_seed(AMX *amx, cell *params)
{
	return(rnd_seed);
}

cell rnd(AMX *amx, cell *params)
{
	cell low, high, test;

	high = rnd_seed / RNG_Q;
	low = rnd_seed % RNG_Q;
	test = RNG_A * low - RNG_R * high;
	if(test>0)
		rnd_seed = test;
	else
		rnd_seed = test + RNG_M;

	if(params[0]>0)
	{
		if(params[1]==0)
			return rnd_seed;
		else
			return (rnd_seed%params[1]);
	}
	else
		return rnd_seed;
}

AMX_NATIVE_INFO random_Natives[]=
{
	{"rnd", rnd},
	{"get_rnd_seed", get_rnd_seed},
	{"set_rnd_seed", set_rnd_seed},
	{"reset_rnd_seed", reset_rnd_seed},

	{0,0}
};
