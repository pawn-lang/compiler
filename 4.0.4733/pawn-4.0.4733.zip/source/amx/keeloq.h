/* see keeloq.c for information */
uint32_t	KeeLoq_Encrypt (const uint32_t data, const uint64_t key);
uint32_t	KeeLoq_Decrypt (const uint32_t data, const uint64_t key);
