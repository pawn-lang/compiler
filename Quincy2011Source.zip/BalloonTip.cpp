/* BalloonTip
 * A balloon-style tooltip based on the callout control published
 * in Dr. Dobb's Journal of August 2004.
 *
 * $Id: BalloonTip.cpp 4523 2011-06-21 15:03:47Z thiadmer $
 */

#include "stdafx.h"
#include "BalloonTip.h"
#include "callout.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


const short TIP_TIMER_ID = 10001;

HINSTANCE CBalloonTip::hinstCallout = 0;

BEGIN_MESSAGE_MAP(CBalloonTip, CWnd)
	//{{AFX_MSG_MAP(CBalloonTip)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


CBalloonTip::CBalloonTip()
{
    m_snDelay = 1000;
    m_TimerSet = FALSE;
	hinstCallout = NULL;
	hwndCallout = NULL;
	m_Callback = NULL;
}

CBalloonTip::~CBalloonTip()
{
	if (::IsWindow(hwndCallout))
		::DestroyWindow(hwndCallout);
	hwndCallout = NULL;
}

BOOL CBalloonTip::CreateTipWnd(CWnd* pParentWnd, const char *Text, int Delay, BOOL Reformat)
{
	// Load the callout DLL
	if (hinstCallout == NULL) {
		hinstCallout = LoadLibrary("callout.dll");
		if (hinstCallout == NULL)
			return FALSE;
	} /* if */

    // Create a dummy (child) window, in order to capture timer events
    CWnd::CreateEx(NULL, NULL, "", WS_CHILD, 0, 0, 10, 10, pParentWnd->GetSafeHwnd(), NULL);
    ShowWindow(SW_HIDE);

    m_snDelay = Delay;
	hwndCallout = ::CreateWindow("Callout", Text, WS_CHILD, 0, 0, 0, 0, 
								 pParentWnd->GetSafeHwnd(), 0, GetModuleHandle(NULL), NULL);
	if (!::IsWindow(hwndCallout))
		return FALSE;

	// Set callout options
	Callout_SetTailOffset(hwndCallout, 16, FALSE);
	Callout_SetReformatText(hwndCallout, Reformat, FALSE);
	Callout_SetVertAlign(hwndCallout, CS_ALIGNBELOW, FALSE);
	//Callout_SetTailStyle(hwndCallout, CS_THINK, FALSE);

	return TRUE;
}

void CBalloonTip::Hide(BOOL RestartTimer)
{
    if (::IsWindow(hwndCallout) && ::IsWindowVisible(hwndCallout))
        ::ShowWindow(hwndCallout, SW_HIDE);	// hide callout if it is displayed
	if (RestartTimer)
        StartTimer(500);   // (re-)start the timer 
}

BOOL CBalloonTip::Show(CPoint *anchor, BOOL infotips, int activeindex)
{
	if (!::IsWindow(hwndCallout))
		return FALSE;

	// reset timeout, because it may have been lengthened
	Callout_SetTimeout(hwndCallout, 10000);	// time-out of 10 seconds

	// look up the text to display
	BOOL ok = TRUE;
	BOOL show = TRUE;
	ASSERT(anchor);
	if (m_Callback != NULL) {
		const char *text = m_Callback(anchor, m_CallbackUser, infotips, activeindex);
		if (text != NULL) {
			::SetWindowText(hwndCallout, text);
			show = strcmp(text, "?") != 0;
			free((void*)text);
		} else {
			ok = FALSE;
		} /* if */
	} /* if */
	if (ok) {
		Callout_SetAnchor(hwndCallout, anchor->x, anchor->y);
		if (show) {
			::ShowWindow(hwndCallout, SW_SHOWNA);
			::SetWindowPos(hwndCallout, NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
		} else {
			::ShowWindow(hwndCallout, SW_HIDE);
		} /* if */
	} /* if */
	return ok;
}

void CBalloonTip::PostponeTimeout()
{
	if (::IsWindow(hwndCallout))
		Callout_SetTimeout(hwndCallout, 30000);	// expand time-out to 30 seconds
}

BOOL CBalloonTip::IsVisible(CPoint *anchor)
{
	if (!::IsWindow(hwndCallout))
		return FALSE;
	if (anchor) {
		long pos = Callout_GetAnchor(hwndCallout);
		anchor->x = LOWORD(pos);
		anchor->y = HIWORD(pos);
	} /* if */
	return ::IsWindowVisible(hwndCallout);
}

CString CBalloonTip::GetText()
{
	if (!::IsWindow(hwndCallout))
		return CString("");
	int len = ::GetWindowTextLength(hwndCallout) + 1;
	CString result;
	::GetWindowText(hwndCallout,result.GetBuffer(len),len);
	return CString(result.GetBuffer(len));
}

void CBalloonTip::SetText(const CString &string)
{
	if (::IsWindow(hwndCallout))
		::SetWindowText(hwndCallout, string);
}

void CBalloonTip::ForwardMouseMove(CPoint point)
{
    if (!GetSafeHwnd() || hwndCallout == NULL)
        return ;

    if (m_pntPrevPos != point) {
		Hide();
        m_pntPrevPos = point;
        StartTimer();       // (re-)start the timer 
    } /* if */
}

void CBalloonTip::OnTimer(UINT nIDEvent) 
{
    if (nIDEvent == TIP_TIMER_ID) {
        StopTimer();
		Show(&m_pntPrevPos);
    } /* if */

	CWnd::OnTimer(nIDEvent);
}

void CBalloonTip::StartTimer(short Delay)
{
	if (Delay < 0)
		Delay = m_snDelay;
	StopTimer();
    SetTimer(TIP_TIMER_ID, Delay, 0);
	m_TimerSet = TRUE;
}

void CBalloonTip::StopTimer()
{
	if (m_TimerSet) {
		KillTimer(TIP_TIMER_ID);
		m_TimerSet = FALSE;
	} /* if */
}
