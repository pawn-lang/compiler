// GrepInput.cpp : implementation file
// $Id: GrepInput.cpp 4029 2008-11-04 16:26:23Z thiadmer $

#include "stdafx.h"
#include "quincy.h"
#include "GrepInput.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GrepInput dialog


GrepInput::GrepInput(CWnd* pParent)
	: CDialog(GrepInput::IDD, pParent)
{
	//{{AFX_DATA_INIT(GrepInput)
	m_strGrepInput = _T("");
	m_bMatchCase = true;
	m_bMatchWord = false;
	//}}AFX_DATA_INIT
}


void GrepInput::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GrepInput)
	DDX_Text(pDX, IDC_GREPINPUT, m_strGrepInput);
	DDX_Check(pDX, IDC_MATCHCASE, m_bMatchCase);
	DDX_Check(pDX, IDC_MATCHWORD, m_bMatchWord);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(GrepInput, CDialog)
	//{{AFX_MSG_MAP(GrepInput)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GrepInput message handlers
