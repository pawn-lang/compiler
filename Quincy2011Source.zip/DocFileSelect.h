#if !defined(AFX_DOCFILESELECT_H__05310E53_11CC_48B7_A061_F0F3EF2A43A7__INCLUDED_)
#define AFX_DOCFILESELECT_H__05310E53_11CC_48B7_A061_F0F3EF2A43A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DocFileSelect.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDocFileSelect dialog

class CDocFileSelect : public CDialog
{
// Construction
public:
	CDocFileSelect(CWnd* pParent = NULL);   // standard constructor
	~CDocFileSelect();

// Dialog Data
	//{{AFX_DATA(CDocFileSelect)
	enum { IDD = IDD_HELPSELECT };
	CString	m_strDocList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDocFileSelect)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDocFileSelect)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDblclkDoclist();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	std::map<const char*,int> m_mapFilenames;
	static CString m_strRecentDocument;
	CString m_strSelectedFile;
	int m_nSelectedPage;
public:
	void SetFilemap(const std::map<const char*,int> *filenames);
	const char *GetDocumentFile(int *page);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOCFILESELECT_H__05310E53_11CC_48B7_A061_F0F3EF2A43A7__INCLUDED_)
