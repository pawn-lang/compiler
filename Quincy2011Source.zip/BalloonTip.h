#ifndef _BALLOONTIP_H_
#define _BALLOONTIP_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "afxtempl.h"

typedef const char * (*BALLOONTEXT)(LPPOINT position, LPVOID User, BOOL InfoTips, int ActiveIndex);

class CBalloonTip : public CWnd
{
public:
	CBalloonTip(); //  Default Constructor.
	virtual ~CBalloonTip();

public:
    BOOL CreateTipWnd(CWnd *pParentWnd, const char *Text = "", int Delay = 1000, BOOL Reformat = FALSE);
    void ForwardMouseMove(CPoint point);
	void Hide(BOOL RestartTimer = FALSE);
	BOOL Show(CPoint *anchor, BOOL infotips = TRUE, int activeindex = -1);
	void PostponeTimeout();
	BOOL IsVisible(CPoint *anchor=NULL);
	void SetCallback(BALLOONTEXT f, LPVOID user = NULL) { m_Callback = f; m_CallbackUser = user; }
	HWND GetCalloutWindow() { return hwndCallout; }

	CString GetText();
	void SetText(const CString &string);

protected:
	void StopTimer();                   //  single-shot timer, for tooltip time-out 
	void StartTimer(short Delay = -1);	//  -1 = use standard delay

	// <---- Generated message map functions --->
protected:
	//{{AFX_MSG(CBalloonTip)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	static HINSTANCE hinstCallout;
	HWND		hwndCallout;
    short int   m_snDelay;              //  delay time to display callout
    CPoint      m_pntPrevPos;           //  to detect mouse movement
	BOOL		m_TimerSet;

	BALLOONTEXT m_Callback;
	LPVOID		m_CallbackUser;

}; // End of CBalloonTip Class defination

#endif // _BALLOONTIP_H_
