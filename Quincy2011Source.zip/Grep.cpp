// ----- grep.cpp
// $Id: Grep.cpp 4258 2010-06-17 10:21:31Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "grep.h"
#include "EditorView.h"
#include "EditorDoc.h"
#include "Compiler.h"
#include "ErrorLogDialog.h"

char* Grep::extensions[] = {
	"p", "pawn", "pwn", "inc"
};

Grep* Grep::pGrep;

Grep::Grep() : grepcount(sizeof(extensions) / sizeof(char*))
{
	status = idle;
	m_pdlgGrepInput = new GrepInput;
	grepstepper = 0;
	m_pConsoleApp = new ConsoleApp(theApp.Enquote(theApp.QuincyBinPath() + "\\grep.exe"), &Notify, &Collect);
	pGrep = this;
}

Grep::~Grep()
{
	delete m_pdlgGrepInput;
	delete m_pConsoleApp;
	pGrep = 0;
}

void Grep::OnGrep() 
{
	ASSERT(m_pdlgGrepInput != 0);
	bool grepping;

	// if there is a workspace, use the path to the workspace file
	CString strPath;
	if (theApp.IsProjectActive()) {
		strPath = theApp.ProjectPath();
	} else if (theApp.GetMDIChild()) {
		CView* pActiveView = theApp.GetMDIChild()->GetActiveView();
		ASSERT(pActiveView != 0);
		CDocument* pDoc = pActiveView->GetDocument();
		ASSERT(pDoc != 0);
		strPath = pDoc->GetPathName();
	} /* if */
	if (!strPath.IsEmpty()) {
		strPath = theApp.GetFilePath(strPath);
		_chdir(strPath);
	} /* if */

	if (theApp.GetMDIChild()) {
		CView* pActiveView = theApp.GetMDIChild()->GetActiveView();
		ASSERT(pActiveView != 0);
		m_pdlgGrepInput->m_strGrepInput = ((CEditorView*)pActiveView)->SelectedText().c_str();
	} /* if */

	if (m_pdlgGrepInput->DoModal() == IDOK)	{
		if (!m_pdlgGrepInput->m_strGrepInput.IsEmpty())	{

			Compiler *pCompiler = theApp.GetCompiler();
			if (!pCompiler) {
				MessageBeep(MB_ICONSTOP);
				return;
			} /* if */
			pCompiler->CreateErrorLog();
			CErrorLogDialog *dlgResults = pCompiler->GetErrorLog();
			if (!dlgResults) {
				MessageBeep(MB_ICONSTOP);
				return;
			} /* if */
			dlgResults->ClearSearchView();
			// dlgResults->AddSearchMessage("Searching for \"" + m_pdlgGrepInput->m_strGrepInput + "\"");

			GrepLog.clear();
			m_nGrepCount = 0;

			m_strParams = " -n ";				// prefix line number to each match
			m_strParams += "-S ";				// search subdirectories

			if (!m_pdlgGrepInput->m_bMatchCase)
				m_strParams += "-i ";			// ignore case
			if (m_pdlgGrepInput->m_bMatchWord)
				m_strParams += "-w ";			// match words
			m_strParams += "\"" + m_pdlgGrepInput->m_strGrepInput + "\"";

			grepstepper = 0;
			RunGrep(extensions[grepstepper]);
		}
	}
}

void Grep::Notify()
{
	ASSERT(pGrep != 0);
	pGrep->NotifyTermination();
}

void Grep::NotifyTermination()
{
	if (++grepstepper < grepcount) {
		RunGrep(extensions[grepstepper]);
	} else if (m_nGrepCount == 0) {
		ASSERT(theApp.GetCompiler());
		CErrorLogDialog *dlgResults = theApp.GetCompiler()->GetErrorLog();
		ASSERT(dlgResults);
		dlgResults->AddSearchMessage("No matches found");
	} /* if */
}


void Grep::Collect(DWORD bufct)
{
	ASSERT(pGrep != 0);
	pGrep->CollectMessages(bufct);
}

void Grep::CollectMessages(DWORD bufct)
{
	char *line = new char[bufct+1];
	ASSERT(m_pConsoleApp);
	if (m_pConsoleApp->ReadConsole(line, bufct) != 0)	{
		// ------ put entry into grep response
		CString strLine(line);
		if (strLine.Find("No such file or directory") == -1)	{
			if (strLine.Find("Invalid argument") == -1)	{
				if (strLine.Find("usage") == -1)	{
					int ndx;
					do
						if ((ndx = strLine.Find('\t')) != -1)
							strLine.SetAt(ndx, ' ');
					while (ndx != -1);
					if ((ndx = strLine.Find(':')) != -1)	{
						ASSERT(theApp.GetCompiler());
						CErrorLogDialog *dlgResults = theApp.GetCompiler()->GetErrorLog();
						ASSERT(dlgResults);
						dlgResults->AddSearchMessage(strLine);
						CString strFile = strLine.Left(ndx);
						int lineno = atoi(strLine.GetBuffer(0) + ndx + 1);
						ErrorMessage ell;
						ell.m_strFileSpec = strFile;
						ell.m_nLineNumber = lineno;
						GrepLog.push_back(ell);;
						++m_nGrepCount;
					}
				}
			}
		}
	}
	delete line;
}

void Grep::RunGrep(const CString& params)
{
	ASSERT(m_pConsoleApp != 0);
	m_pConsoleApp->Run(m_strParams + " *." + params);
}

void Grep::Stop()
{
	ASSERT(m_pConsoleApp);
	ASSERT(theApp.GetCompiler());
	CErrorLogDialog *dlgResults = theApp.GetCompiler()->GetErrorLog();
	ASSERT(dlgResults);
	dlgResults->AddSearchMessage("Stopped by user");
	m_pConsoleApp->Stop();
}

void Grep::SelectGrepLine(int nsel)
{
	if (nsel != -1 && m_nGrepCount > 0 && nsel < GrepLog.size())
		theApp.SelectFileAndLine(GrepLog[nsel].m_strFileSpec, GrepLog[nsel].m_nLineNumber);
}

