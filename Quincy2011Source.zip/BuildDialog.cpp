// BuildDialog.cpp : implementation file
// $Id: BuildDialog.cpp 4258 2010-06-17 10:21:31Z thiadmer $

#include "stdafx.h"
#include "quincy.h"
#include "OptionsSheet.h"
#include "BuildDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBuildDialog dialog


CBuildDialog::CBuildDialog(CWnd* pParent)
	: CPropertyPage(CBuildDialog::IDD)
{
	//{{AFX_DATA_INIT(CBuildDialog)
	m_strDefine = _T("");
	m_strInclude = _T("");
	m_strCmdLineOptions = _T("");
	m_Report = FALSE;
	m_Verbose = FALSE;
	m_strTargetPath = _T("");
	m_FixedName = BST_INDETERMINATE;
	m_BuildOverlay = FALSE;
	m_strRuntimeDirectory = _T("");
	//}}AFX_DATA_INIT
}


void CBuildDialog::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBuildDialog)
	DDX_Control(pDX, IDC_TARGETHOST, m_TargetHostDropList);
	DDX_Control(pDX, IDC_DEBUG, m_DebugDropList);
	DDX_Control(pDX, IDC_OPTIMIZE, m_OptimizeDropList);
	DDX_Text(pDX, IDC_DEFINE, m_strDefine);
	DDX_Text(pDX, IDC_INCLUDE, m_strInclude);
	DDX_Text(pDX, IDC_EDIT1, m_strCompiler);
	DDX_Text(pDX, IDC_CMDLINEOPTIONS, m_strCmdLineOptions);
	DDX_Check(pDX, IDC_REPORT, m_Report);
	DDX_Check(pDX, IDC_VERBOSE, m_Verbose);
	DDX_Text(pDX, IDC_TARGETPATH, m_strTargetPath);
	DDX_Check(pDX, IDC_FIXEDNAME, m_FixedName);
	DDX_Check(pDX, IDC_BUILD_OVERLAY, m_BuildOverlay);
	DDX_Text(pDX, IDC_RUNTIMEDIRECTORY, m_strRuntimeDirectory);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBuildDialog, CPropertyPage)
	//{{AFX_MSG_MAP(CBuildDialog)
	ON_BN_CLICKED(IDC_BROWSEINCLUDES, OnBrowseincludes)
	ON_BN_CLICKED(IDC_BROWSECOMPILER, OnBrowsecompiler)
	ON_BN_CLICKED(IDC_BROWSETARGET, OnBrowsetarget)
	ON_CBN_SELCHANGE(IDC_OPTIMIZE, OnSelchangeOptimize)
	ON_CBN_SELCHANGE(IDC_DEBUG, OnSelchangeDebug)
	ON_BN_CLICKED(IDC_BROWSERUNTIMEWK, OnBrowseruntimewk)
	ON_CBN_SELCHANGE(IDC_TARGETHOST, OnSelchangeTargetfile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBuildDialog message handlers
BOOL CBuildDialog::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	UpdateData();

	CButton *chk;
	VERIFY(chk = (CButton*)GetDlgItem(IDC_FIXEDNAME));
	chk->EnableWindow(m_bFixedNameEnabled);

	VERIFY(chk = (CButton*)GetDlgItem(IDC_BUILD_OVERLAY));
	chk->EnableWindow(m_bOverlayEnabled);

	m_OptimizeDropList.SetCurSel(m_nOptimize);
	m_DebugDropList.SetCurSel(m_nDebugLevel);

	// find all target configuration files, get version numbers from them
	int IdxMatch = 0;
	CFileFind finder;
	CString path = theApp.ToolsPath();
	BOOL bWorking = finder.FindFile(path + "*.cfg");
	while (bWorking) {
		bWorking = finder.FindNextFile();
		CString name = finder.GetFileName();	// base name
		// skip any profile that starts with "uncrustify"
		if (name.Left(10).CompareNoCase("uncrustify") == 0)
			continue;
		CString filename = path + name;			// full path
		// strip the extension
		int pos = name.Find(".cfg");
		ASSERT(pos >= 0);						// must be found, we searched for this extension
		name = name.Left(pos);
		// save whether this is the current target host
		BOOL bMatch = (name.CompareNoCase(m_strTargetHost) == 0);
		// read the configuration file, see whether there is a "prefix" file
		FILE *file;
		file = fopen(filename.GetBuffer(MAX_PATH), "rt");
		if (file)	{
			char line[300];
			fgets(line, sizeof line, file);
			fclose(file);
			char *start, *end;
			if ((start = strstr(line, " -p:")) != NULL) {
				start += 4;
				char *end = start;
				while (*end != '\0' && *end > ' ')
					end++;
				filename = start;
				filename = theApp.IncludePath() + filename.Left((int)(end - start));
				// read the first line from the file, see if a version is present
				file = fopen(filename.GetBuffer(MAX_PATH), "rt");
				if (file)	{
					fgets(line, sizeof line, file);
					fclose(file);
					char *start = strstr(line, "version");
					if (start == NULL)
						start = strstr(line, "Version");
					if (start != NULL) {
						start += 7;
						while (*start != '\0' && (*start <= ' ' || *start == ':'))
							start++;
						char *end = start;
						while (*end != '\0' && *end > ' ')
							end++;
						CString version = start;
						version = version.Left((int)(end - start));
						name = name + " * " + version;
					} /* if */
				} /* if */
			} /* if */
		} /* if */
		int idx = m_TargetHostDropList.AddString(name);
		if (bMatch)
			IdxMatch = idx;
	} /* while */

	m_TargetHostDropList.SetCurSel(IdxMatch);

	// for Vista and above, remove the WS_EX_CLIENTEDGE style from the pushbuttons
	OSVERSIONINFOEX osversion = theApp.OSVersion();
	if (osversion.dwMajorVersion >= 6) {
		CButton *chk;
		DWORD exstyle;
		VERIFY(chk = (CButton*)GetDlgItem(IDC_BROWSEINCLUDES));
		chk->ModifyStyleEx(WS_EX_CLIENTEDGE, 0, SWP_FRAMECHANGED);
		VERIFY(chk = (CButton*)GetDlgItem(IDC_BROWSETARGET));
		chk->ModifyStyleEx(WS_EX_CLIENTEDGE, 0, SWP_FRAMECHANGED);
		VERIFY(chk = (CButton*)GetDlgItem(IDC_BROWSECOMPILER));
		chk->ModifyStyleEx(WS_EX_CLIENTEDGE, 0, SWP_FRAMECHANGED);
		VERIFY(chk = (CButton*)GetDlgItem(IDC_BROWSERUNTIMEWK));
		chk->ModifyStyleEx(WS_EX_CLIENTEDGE, 0, SWP_FRAMECHANGED);
	} /* if */

	return true;
}

void CBuildDialog::OnOK() 
{
	UpdateData();
	CPropertyPage::OnOK();
}

BOOL CBuildDialog::OnSetActive() 
{
	static_cast<COptionsSheet*>(GetParent())->RegisterActiveIndex();
	return CPropertyPage::OnSetActive();
}


void CBuildDialog::OnBrowseincludes() 
{
	CString includes;
	if (theApp.SelectFolder("#include directory", &includes))	{
		if (!m_strInclude.IsEmpty())
			m_strInclude += ';';
		m_strInclude += includes;
		UpdateData(0);
	}
}

void CBuildDialog::OnBrowsecompiler() 
{
	if (theApp.SelectFolder("Compiler", &m_strCompiler))
		UpdateData(0);
}

void CBuildDialog::OnBrowsetarget() 
{
	CString target;
	if (theApp.SelectFolder("Output directory", &target))	{
		m_strTargetPath = target;
		UpdateData(0);
	}
}

void CBuildDialog::OnBrowseruntimewk() 
{
	if (theApp.SelectFolder("Runtime Working Files", &m_strRuntimeDirectory))
		UpdateData(0);
	
}

void CBuildDialog::OnSelchangeOptimize() 
{
	int idx = m_OptimizeDropList.GetCurSel();
	if( idx < 0 )
		return;
	m_nOptimize = idx;
}

void CBuildDialog::OnSelchangeDebug() 
{
	int idx = m_DebugDropList.GetCurSel();
	if( idx < 0 )
		return;
	m_nDebugLevel = idx;
	if (m_nDebugLevel >= 2) {
		((CButton*)GetDlgItem(IDC_VERBOSE))->SetCheck(BST_CHECKED);
		GetDlgItem(IDC_VERBOSE)->EnableWindow(false);
	} else {
		GetDlgItem(IDC_VERBOSE)->EnableWindow();
	} /* if */
	UpdateData();	
}


void CBuildDialog::OnSelchangeTargetfile() 
{
	int idx = m_TargetHostDropList.GetCurSel();
	if( idx < 0 )
		return;
	
	CString name;
	m_TargetHostDropList.GetLBText(idx, name);
	if (!name.IsEmpty() && name[0] != '(') {
		// strip off the version, if any
		idx = name.Find(" * ");
		if (idx >= 0)
			m_strTargetHost = name.Left(idx);
	} else {
		m_strTargetHost.Empty();
	} /* if */

	/* enable all controls, because we have not (re-)loaded the
	 * new host configuration, and therefore we do not know which
	 * controls should now be disabled.
	 */
	CButton *chk;
	chk = (CButton*)GetDlgItem(IDC_FIXEDNAME);
	ASSERT(chk);
	chk->EnableWindow(true);

	chk = (CButton*)GetDlgItem(IDC_BUILD_OVERLAY);
	ASSERT(chk);
	chk->EnableWindow(true);
}
