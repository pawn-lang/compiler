#include <windows.h>
#include "rs232.h"

HANDLE RS232::InternalOpen()
{
  static long stdbaud[] = {1200, 2400, 4800, 9600, 14400, 19200, 28800, 38400, 57600, 115200, 230400 };

  /* set up the connection */
  char buffer[40];
  if (Port>=10)
    wsprintf(buffer,"\\\\.\\com%d",Port);
  else
    wsprintf(buffer,"com%d",Port);
  HANDLE handle=CreateFile(buffer,GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
  if (handle==INVALID_HANDLE_VALUE)
    return handle;

  DCB dcb;
  GetCommState(handle,&dcb);
  /* first set the baud rate only, because this may fail for a non-standard
   * baud rate
   */
  dcb.BaudRate=Baud;
  if (!SetCommState(handle,&dcb) || dcb.BaudRate!=Baud) {
    /* find the lowest standard baud rate */
    int i;
    for (i=0; (i+1)<sizearray(stdbaud) && stdbaud[i]<Baud; i++)
      /* nothing */;
    dcb.BaudRate=Baud=stdbaud[i];
  } /* if */
  dcb.ByteSize=(unsigned char)Data;
  switch (Stop) {
  case 1:
    dcb.StopBits=ONESTOPBIT;
    break;
  case 2:
    dcb.StopBits=TWOSTOPBITS;
    break;
  } /* switch */
  switch (Parity) {
  case 0:
    dcb.Parity=NOPARITY;
    break;
  case 1:
    dcb.Parity=EVENPARITY;
    break;
  case 2:
    dcb.Parity=ODDPARITY;
    break;
  case 3:
    dcb.Parity=MARKPARITY;
    break;
  } /* switch */
  dcb.fDtrControl= (FlowCtrl == Flow_DtrDsr || FlowCtrl == Flow_RtsCts) ? DTR_CONTROL_ENABLE : DTR_CONTROL_DISABLE;
  dcb.fOutX=(FlowCtrl == Flow_XonXoff);
  dcb.fInX=(FlowCtrl == Flow_XonXoff);
  /* leave the buffer limits and others at their defaults (if there are defaults) */
  if (dcb.XonChar == 0)
    dcb.XonChar = 0x11;
  if (dcb.XoffChar == 0)
    dcb.XoffChar = 0x13;
  if (dcb.XoffLim == 0)
    dcb.XoffLim = 128;
  if (dcb.XonLim == 0)
    dcb.XonLim = 512;
  dcb.fNull=FALSE;
  dcb.fRtsControl= (FlowCtrl == Flow_RtsCts) ? RTS_CONTROL_HANDSHAKE : RTS_CONTROL_DISABLE;
  SetCommState(handle,&dcb);
  SetCommMask(handle,EV_RXCHAR|EV_TXEMPTY);

  COMMTIMEOUTS commtimeouts;
  commtimeouts.ReadIntervalTimeout        =0x7fffffff;
  commtimeouts.ReadTotalTimeoutMultiplier =0;
  commtimeouts.ReadTotalTimeoutConstant   =1;
  commtimeouts.WriteTotalTimeoutMultiplier=0;
  commtimeouts.WriteTotalTimeoutConstant  =0;
  SetCommTimeouts(handle,&commtimeouts);

  return handle;
}

BOOL RS232::Open(int port,int baud,int databits,int stopbits,int parity,int flowctrl)
{
	/* close port if one is already open */
	Close();

	if (port > 0)
		Port = port;
	if (baud > 0)
		Baud = baud;
	if (port > 0 && baud > 0) {
		Data = databits;
		Stop = stopbits;
		Parity = parity;
		FlowCtrl = flowctrl;
	} /* if */

	if ((handlePort=InternalOpen()) == INVALID_HANDLE_VALUE)
		return FALSE;

	return TRUE;
}

BOOL RS232::Close()
{
	if (handlePort!=INVALID_HANDLE_VALUE) {
		CloseHandle(handlePort);
		handlePort=INVALID_HANDLE_VALUE;
	} /* if */
	return TRUE;
}

size_t RS232::PutData(const unsigned char *buffer, size_t length)
{
	if (!IsOpen())
		return 0;

	unsigned long size;
	WriteFile(handlePort, buffer, length, &size, NULL);
	return size;
}

size_t RS232::GetData(unsigned char *buffer, size_t maxlength)
{
	if (!IsOpen())
		return 0;

	unsigned long size;
	ReadFile(handlePort, buffer, maxlength, &size, NULL);
	return size;
}

void RS232::EscapeCommFunction(int command)
{
	if (IsOpen())
		::EscapeCommFunction(handlePort, command);
}

