// --------- QuincyDebug.cpp
// $Id: QuincyDebug.cpp 4240 2010-04-06 15:55:46Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "textview.h"
#include "debugger.h"
#include "WatchDialog.h"
#include "mainfrm.h"

Debugger* Debugger::pDebugger;

Debugger::Debugger()
{
	m_nDrive = _getdrive();
	m_pOldPath = _getcwd(0, MAX_PATH);
	std::string exe = theApp.ToolsPath();
	int type = (theApp.GetDebugPort() != 0) ? DEBUG_REMOTE : DEBUG_LOCAL;
	exe += theApp.GetDebuggerName(type);
	CString strexe = theApp.Enquote(exe.c_str());
	gdb = new ConsoleApp(strexe, &Notify, &Collect);
	pDebugger = this;
	atprompt = false;
	watching = false;

	currentlineno = 0;
	ExamineWnd = 0;
	GobbledData = false;
}

Debugger::~Debugger()
{

	_chdrive(m_nDrive);
	_chdir(m_pOldPath);
	delete m_pOldPath;
	delete gdb;
	pDebugger = 0;
}

void Debugger::LoadDebugger(std::string cmdline)
{
	try	{
		CString strCmdLine(cmdline.c_str());

		strRedirect.Empty();

		CString strRedirectedStdin;
		int index = strCmdLine.Find('<');
		if (index != -1 && index < strCmdLine.GetLength()-1)	{
			theApp.ParseFileSpec(strRedirectedStdin, strCmdLine, index);
			strRedirect = " < ";
			strRedirect += strRedirectedStdin;
		}
		CString strRedirectedStdout;
		index = strCmdLine.Find('>');
		if (index != -1 && index < strCmdLine.GetLength()-1)	{
			bool append = false;
			if (strCmdLine[index+1] == '>')	{
				index++;
				append = true;
			}
			theApp.ParseFileSpec(strRedirectedStdout, strCmdLine, index);
			strRedirect += append ? " >> " : " > ";
			strRedirect += strRedirectedStdout;
		}

		if (theApp.GetDebuggerAutoHide() && theApp.GetDebugPort() == 0)
			strCmdLine = theApp.Enquote(strCmdLine) + " -term=hide";
		else
			strCmdLine = theApp.Enquote(strCmdLine) + " -term=off";

		if (theApp.GetDebugPort() != 0) {
			CString strPort;
			strPort.Format(" -rs232=%d,%d", theApp.GetDebugPort(), theApp.GetDebugBaudrate());
			strCmdLine += strPort;
			theApp.CreateGdbConsole(TRUE, TRUE);
		} /* if */

		gdb->Run(strCmdLine.GetBuffer(0), theApp.GetDebugPort() != 0);
		theApp.ClearGdbConsole();
		theApp.DisplayGdbText("--- PawnDbg started ---");
	}
	catch(...)	{
		AfxMessageBox("\nCannot execute PawnDbg", MB_ICONSTOP);
	}
}

void Debugger::StartProgram(bool SendGo)
{
	currentsrc = "";
	currentlineno = 0;
	atprompt = false;
	if (SendGo) {
		CString cmd("g");
		cmd += strRedirect;
		PostCommand(cmd.GetBuffer(0));
	} /* if */
}

void Debugger::StepIntoProgram()
{
	StartProgram(false);
}

void Debugger::SendCommand(char* cmd)
{
	if (atprompt)	{
		strncpy(lastcommand,cmd,99);
		gdb->WriteConsole(cmd);
		theApp.DisplayGdbText(cmd);
		atprompt = false;
	}
	else
		PostCommand(cmd);
}

void Debugger::PostCommand(const char* cmd)
{
	cmds.push(cmd);
}

void Debugger::Notify()
{
	ASSERT(pDebugger != 0);
	pDebugger->NotifyTermination();
}

void Debugger::NotifyTermination()
{
	if (atprompt)	{
		theApp.DisplayGdbText(" ");
		atprompt = false;
	}
	theApp.DisplayGdbText("--- PawnDbg terminated ---");
	if (theApp.GetGdbConsole()->IsAutoClose())
		theApp.GetGdbConsole()->ShowWindow(SW_HIDE);
	currentsrc = "";
	currentlineno = 0;
	theApp.InvalidateAllViews();
	theApp.StopDebugger();  // this function in CQuincyApp destroys the debugger object
							// so don't do anything after this call except in the dtor
}

// --- called from the console application thread while compiling is going on
void Debugger::Collect(DWORD bufct)
{
	ASSERT(pDebugger != 0);
	pDebugger->CollectGdbMessages(bufct);
}

inline bool Debugger::IsText(const char* buf, const char* txt) const
{
	return strnicmp(buf, txt, strlen(txt)-1) == 0;
}

void Debugger::SetWatchExpressions(CString* exp, int ct)
{
	PostCommand("cwatch *");

	CWatchDialog* watch = theApp.GetWatchDialog();
	if (watch)	{
		CListBox* lb = watch->GetWatchListbox();
		if (lb)
			lb->ResetContent();
	} /* if */

	for (int idx = 0; idx < ct; idx++) {
		CString cmd = exp[idx];
		int pos = cmd.Find('=');
		if (pos > 0) {
			while (pos > 0 && cmd[pos - 1] == ' ')
				pos--;
			cmd = cmd.Left(pos);
		} /* if */
		cmd = "watch " + cmd;
		PostCommand(cmd.GetBuffer(0));
	} /* for */

	/* cause a sendcommand now */
	if (atprompt) {
		SendCommand(const_cast<char*>(cmds.front().c_str()));
		cmds.pop();
	} /* if */
}

void Debugger::PostResponse(const char* res)
{
	CWatchDialog* watch = theApp.GetWatchDialog();
	if (watch)	{
		CListBox* lb = watch->GetWatchListbox();
		if (lb)	{
			std::string symbol(res);
			int pos = symbol.find(' ');
			if (pos < 0)
				pos = symbol.find('\t');
			std::string value;
			value = symbol.substr(pos);
			symbol = symbol.substr(0, pos + 1);
			symbol += " = ";
			while (value[0] == ' ' || value[0] == '\t')
				value.erase(0, 1);
			int sel = lb->FindString(-1, symbol.c_str());
			if (sel != LB_ERR)
				lb->DeleteString(sel);

			symbol = symbol + value;
			lb->InsertString(sel, const_cast<char*>(symbol.c_str()));
		}
	}
}

void Debugger::DisplayData(const char* cp)
{
	if (ExamineWnd != 0)	{
		// examine response
		if (::IsWindow(ExamineWnd)) {
			::SetWindowText(ExamineWnd, cp);
			if (!::IsWindowVisible(ExamineWnd)) {
				::ShowWindow(ExamineWnd, SW_SHOWNA);
				GobbledData = true;
			} /* if */
		} /* if */
		ExamineWnd = 0;
	} else {
		// watch response
		PostResponse(cp);
	}
}

const char *skipwhite(const char *str)
{
	while (*str != '\0' && (unsigned char)*str <= ' ')
		str++;
	return str;
}

void Debugger::CollectGdbMessages(DWORD bufct)
{
	char *buf = new char[bufct+1];
	ASSERT(gdb != 0);
	if (gdb->ReadConsole(buf, bufct) != 0)	{
		theApp.DisplayGdbText(buf);

		// ---- parse the message from PawnDbg to see what to do with it besides display it
		if (IsText(buf, "dbg> "))	{
			// ---- this is the PawnDbg prompt
			atprompt = true;
			// --- next display will be a command and will be appended
			//     to the prompt on the display in the gdb console window
			theApp.AppendNextText();
			if (cmds.size() != 0)	{
				// ---- command(s) posted to be sent at the prompt
				SendCommand(const_cast<char*>(cmds.front().c_str()));
				cmds.pop();
			} else if (!GobbledData) {
				theApp.SetStepping();
				theApp.BringToTop();
			} /* if (cmds.size() != 0 && !GlobbledData) */
			GobbledData = false;
		} else if (IsText(skipwhite(buf), "!file ")) {
			const char *ptr = strchr(skipwhite(buf), ' ');
			ASSERT(ptr != NULL);
			if (ptr != NULL)
				steppingsrc = skipwhite(ptr);
		} else if (IsText(skipwhite(buf), "symbol not found")) {
			DisplayData("??");
		} else if (IsText(skipwhite(buf), "!watch ")) {
			const char *cp = skipwhite(buf) + 6;		// skip "!watch"
			cp = strpbrk(skipwhite(cp), " \t");	// skip variable name
			if (cp)
				DisplayData(skipwhite(cp));
		} else if (IsText(skipwhite(buf), "!loc ") || IsText(skipwhite(buf), "!glb ")) {
			const char *cp = skipwhite(buf) + 4;// skip "!loc" or "!glb"
			cp = strpbrk(skipwhite(cp), " \t");	// skip variable name
			if (cp)
				DisplayData(skipwhite(cp));
		} else if (IsText(buf, "Program exited"))	{
			// ---- the program being debugged has exited on its own
			if (strstr(buf, " with code 03."))
				AfxMessageBox("assert failed", MB_ICONEXCLAMATION);
			SendCommand("quit");
		} else if (IsText(buf, "The program is running"))	{
			// --- ??? user must be stopping a running program
			atprompt = true;
			if (AfxMessageBox("Terminate running program?", MB_YESNO | MB_ICONQUESTION) == IDYES)	{
				SendCommand("y");
				frame = mainframe = "";
			} else
				SendCommand("n");
		} else if (isdigit(*skipwhite(buf)) && strchr(buf,'*') != NULL) {
			// ---- single step. The numerical value is the line number
			steppinglineno = atoi(buf);
		}
	}
	delete [] buf;
}

int Debugger::CurrentLineNo() const
{
	return currentlineno;
}
const CString* Debugger::CurrentSrcFile() const
{
	static CString str;
	str = currentsrc.c_str();
	return &str;
}

void Debugger::ShowPCCaret(bool bOnOff)
{
	if (currentlineno != 0)	{
		CTextView* pView = theApp.GetTextView(currentsrc.c_str());
		if (pView != 0)
			if (bOnOff)
				pView->DrawMargins();
			else
				pView->PadMargin();
	}
}

void Debugger::SelectSteppingSourceLine()
{
	ShowPCCaret(false);
	if (theApp.SelectFileAndLine(steppingsrc.c_str(), steppinglineno))	{
		currentsrc = steppingsrc;
		currentlineno = steppinglineno;
	}
	ShowPCCaret(true);
}

void Debugger::Stop()
{
	if (atprompt)
		SendCommand("quit");
	else	{
		gdb->Stop();
		atprompt = false;
		frame = mainframe = "";
	}
}

bool Debugger::StepTo(const CString& strFile, int nLineNo)
{
	if (atprompt)	{
		CString cmd;
		cmd.Format("g %s:%d", strFile, nLineNo);
		SendCommand(cmd.GetBuffer(0));
		return true;
	}
	return false;
}

bool Debugger::ExecuteRunningProgram()
{
	if (atprompt)	{
		SendCommand("g");
		atprompt = false;
		return true;
	}
	return false;
}
// ------- the step command
bool Debugger::StepProgram()
{
	if (atprompt)	{
		SendCommand("s");
		atprompt = false;
		return true;
	}
	return false;
}
// ----- the step over command
bool Debugger::StepOver()
{
	if (atprompt)	{
		SendCommand("n");
		atprompt = false;
		return true;
	}
	return false;
}

// ----- the step out command
bool Debugger::StepOut()
{
	if (atprompt)	{
		SendCommand("g func");
		atprompt = false;
		return true;
	}
	return false;
}

void Debugger::SetBreakpoint(Breakpoint& bp)
{
	char lineno[20];
	sprintf(lineno, "%d", bp.m_nLineNo);
	std::string cmd("break ");
	cmd += theApp.GetFileName(bp.m_strFile);
	cmd += ':';
	cmd += lineno;
	SendCommand(const_cast<char*>(cmd.c_str()));
}

void Debugger::ClearBreakpoint(Breakpoint& bp)
{
	char lineno[20];
	sprintf(lineno, "%d", bp.m_nLineNo);
	std::string cmd("cbreak ");
	cmd += theApp.GetFileName(bp.m_strFile);
	cmd += ':';
	cmd += lineno;
	if (!atprompt)
		PostCommand(const_cast<char*>(cmd.c_str()));
	else
		SendCommand(const_cast<char*>(cmd.c_str()));
}

void Debugger::ClearBreakpoint()
{
	char *cmd = "cbreak *";
	if (!atprompt)
		PostCommand(cmd);
	else
		SendCommand(cmd);
}

void Debugger::GetVariableValue(const CString& strVarName, HWND hwnd)
{
	ExamineWnd = hwnd;
	std::string cmd("d ");
	cmd += strVarName;
	SendCommand(const_cast<char*>(cmd.c_str()));
}

void Debugger::SetVariableValue(const CString& strVarName, const CString& strVarValue)
{
	std::string cmd("set ");
	cmd += strVarName;
	cmd += "=";
	cmd += strVarValue;
	SendCommand(const_cast<char*>(cmd.c_str()));
}
