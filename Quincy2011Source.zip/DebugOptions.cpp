// DebugOptions.cpp : implementation file
// $Id: DebugOptions.cpp 4124 2009-06-15 07:07:32Z thiadmer $

#include "stdafx.h"
#include "quincy.h"
#include "OptionsSheet.h"
#include "DebugOptions.h"
#include "Registry.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDebugOptions property page

CDebugOptions::CDebugOptions(CWnd* pParent)
	: CPropertyPage(CDebugOptions::IDD)
{
	//{{AFX_DATA_INIT(CDebugOptions)
	m_AutoTransfer = FALSE;
	m_DebugBaudrate = 0;
	m_Local = 0;
	m_EnableLog = FALSE;
	//}}AFX_DATA_INIT
	m_DebugPort = 0;
}


void CDebugOptions::DoDataExchange(CDataExchange* pDX)
{
	GetDlgItem(IDC_DBG_BAUD)->EnableWindow((m_Local == 1));
	GetDlgItem(IDC_DBG_PORTNUM)->EnableWindow((m_Local == 1));

	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDebugOptions)
	DDX_Radio(pDX, IDC_DBG_LOCAL, m_Local);
	DDX_CBIndex(pDX, IDC_DBG_BAUD, m_DebugBaudrate);
	DDX_Check(pDX, IDC_AUTOTRANSFER, m_AutoTransfer);
	DDX_Check(pDX, IDC_ENABLELOG, m_EnableLog);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDebugOptions, CPropertyPage)
	//{{AFX_MSG_MAP(CDebugOptions)
	ON_BN_CLICKED(IDC_DBG_LOCAL, OnDbgLocal)
	ON_BN_CLICKED(IDC_DBG_SERIAL, OnDbgSerial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDebugOptions message handlers

BOOL CDebugOptions::OnSetActive() 
{
	static_cast<COptionsSheet*>(GetParent())->RegisterActiveIndex();
	return CPropertyPage::OnSetActive();
}

void CDebugOptions::OnDbgLocal() 
{
	m_DebugPort = 0;
	GetDlgItem(IDC_DBG_BAUD)->EnableWindow(FALSE);
	GetDlgItem(IDC_DBG_PORTNUM)->EnableWindow(FALSE);
}

void CDebugOptions::OnDbgSerial() 
{
	m_DebugPort = 0;	
	GetDlgItem(IDC_DBG_BAUD)->EnableWindow(TRUE);
	GetDlgItem(IDC_DBG_PORTNUM)->EnableWindow(TRUE);
}

void CDebugOptions::OnOK() 
{
	if (m_Local == 1) {
		CComboBox *cb = reinterpret_cast<CComboBox *>(GetDlgItem(IDC_DBG_PORTNUM));
		ASSERT(cb);
		CString value;
		int idx = cb->GetCurSel();
		if (idx >= 0) {
			cb->GetLBText(idx, value);
			CString substr = value.Left(3);
			if (substr.CompareNoCase("COM") == 0) 
				m_DebugPort = atoi(value.Mid(3));
		} /* if */
	} /* if */

	CPropertyPage::OnOK();
}

BOOL CDebugOptions::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// fill the list with port numbers
	CComboBox *cb = reinterpret_cast<CComboBox *>(GetDlgItem(IDC_DBG_PORTNUM));
	ASSERT(cb);
	CRegistry reg;
	reg.Open("Hardware\\DEVICEMAP\\SERIALCOMM", HKEY_LOCAL_MACHINE);
	size_t count = reg.Count();
	CRegEntry *entry;
	for (size_t i = 0; i < count; i++) {
		entry = reg.GetAt(i);
		std::string name = entry->lpszName;
		// explicit cast needed to resolve ambiguity
		std::transform(name.begin(), name.end(), name.begin(), tolower);
		if (name.find("serial") != std::string::npos || name.find("oxser") != std::string::npos 
			|| name.find("vcp") != std::string::npos
			|| strncmp((LPTSTR)entry, "COM", 3) == 0)
			cb->AddString(*entry);
	} /* for */
	reg.Close();

	// select the proper port
	if (m_DebugPort > 0) {
		CString str;
		str.Format("COM%d", m_DebugPort);
		cb->SelectString(0, str);
	} /* if */

	// see whether the local/remote debugging options are available
	if (!theApp.CanDebug(DEBUG_LOCAL)) {
		CButton *btn = (CButton*)GetDlgItem(IDC_DBG_LOCAL);
		btn->EnableWindow(FALSE);
		btn->SetCheck(BST_UNCHECKED);
	} /* if */
	if (!theApp.CanDebug(DEBUG_REMOTE)) {
		CButton *btn = (CButton*)GetDlgItem(IDC_DBG_SERIAL);
		btn->EnableWindow(FALSE);
		btn->SetCheck(BST_UNCHECKED);
		m_DebugPort = 0;
		GetDlgItem(IDC_DBG_BAUD)->EnableWindow(FALSE);
		GetDlgItem(IDC_DBG_PORTNUM)->EnableWindow(FALSE);
	} /* if */

	return TRUE;
}
