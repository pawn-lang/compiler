// DocFileSelect.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "DocFileSelect.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDocFileSelect dialog


CDocFileSelect::CDocFileSelect(CWnd* pParent /*=NULL*/)
	: CDialog(CDocFileSelect::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDocFileSelect)
	m_strDocList = _T("");
	//}}AFX_DATA_INIT
}


CDocFileSelect::~CDocFileSelect()
{
	m_mapFilenames.clear();
}


void CDocFileSelect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDocFileSelect)
	DDX_LBString(pDX, IDC_DOCLIST, m_strDocList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDocFileSelect, CDialog)
	//{{AFX_MSG_MAP(CDocFileSelect)
	ON_LBN_DBLCLK(IDC_DOCLIST, OnDblclkDoclist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDocFileSelect message handlers

CString CDocFileSelect::m_strRecentDocument = "";

void CDocFileSelect::SetFilemap(const std::map<const char*,int> *filenames)
{
	ASSERT(filenames != NULL);
	m_mapFilenames.clear();
	m_mapFilenames = *filenames;
}


const char *CDocFileSelect::GetDocumentFile(int *page)
{
	if (m_strSelectedFile.IsEmpty())
		return NULL;
	ASSERT(page != NULL);
	*page = m_nSelectedPage;
	return m_strSelectedFile;
}


BOOL CDocFileSelect::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	/* add the filenames to the listbox */
	CListBox *pList = (CListBox*)GetDlgItem(IDC_DOCLIST);
	ASSERT(pList);
	std::map<const char*, int>::iterator p;
	for (p = m_mapFilenames.begin(); p != m_mapFilenames.end(); p++) {
		std::string name = p->first;
		int pos;
		if ((pos = name.rfind('\\')) >= 0)
			name = name.assign(name, pos + 1, name.length());
		if ((pos = name.rfind('.')) >= 0)
			name = name.assign(name, 0, pos);
		char *ptr;
		while ((ptr = (char*)strrchr(name.c_str(), '_')) != NULL)
			*ptr = ' ';
		pList->AddString(name.c_str());
	} /* for */

	/* select the active item */
	if (!m_strRecentDocument.IsEmpty()) {
		int item = pList->FindStringExact(0, m_strRecentDocument);
		pList->SetCurSel(item);
	} /* if */

	return TRUE;
}

void CDocFileSelect::OnOK() 
{
	CListBox *pList = (CListBox*)GetDlgItem(IDC_DOCLIST);
	ASSERT(pList);
	int item = pList->GetCurSel();
	if (item >= 0) {
		pList->GetText(item, m_strRecentDocument);

		// since this is the same order as in the map, browse through the map
		std::map<const char*, int>::iterator p;
		for (p = m_mapFilenames.begin(); item > 0 && p != m_mapFilenames.end(); p++, item--)
			/* nothing */;
		m_strSelectedFile = p->first;
		m_nSelectedPage = p->second;
	} else {
		m_strSelectedFile.Empty();
	} /* if */
	CDialog::OnOK();
}

void CDocFileSelect::OnDblclkDoclist() 
{
	OnOK();	
}
