// HelpIndex.cpp : implementation file
// $Id: HelpIndex.cpp 4258 2010-06-17 10:21:31Z thiadmer $

#include "stdafx.h"
#include "HelpIndex.h"

CHelpIndex::CHelpIndex()
{
}

CHelpIndex::~CHelpIndex()
{
	m_index.clear();
	m_filetable.clear();
}

void CHelpIndex::AddFile(const char *filename, int id)
{
	std::string fname = (filename!=NULL) ? filename : "";
	m_filetable.insert(std::make_pair(id, fname));
}

void CHelpIndex::AddPage(const char *key, int id, int page)
{
	CPageRef ref(id, page);
	m_index.insert(std::make_pair(key, ref));
}

bool CHelpIndex::ScanFile(const char *indexfile, int id, const char *docfile)
{
	FILE *fp = fopen(indexfile, "rt");
	if (!fp)
		return false;

	if (!docfile)
		docfile = indexfile;
	AddFile(docfile, id);

	char line[128];
	while (fgets(line, sizeof line, fp)) {
		int softpage = 0, hardpage = 0;
		char macro[64] = "", label[64] = "", type[64] = "";
		sscanf(line, "%[^{]{%[^}]}{%d}{%[^}]}{%d}", macro, label, &softpage, type, &hardpage);
		if (strcmp(macro, "\\@definelabel") == 0
			&& strcmp(type, "page") == 0
			&& hardpage > 0)
		{
			char *ptr = label;
			if (*ptr == 'p' && *(ptr+1) == '.')
				ptr += 2;
			AddPage(ptr, id, hardpage);
		} /* if */
	} /* while */

	fclose(fp);
	return true;
}

std::map<const char*,int> *CHelpIndex::LookUp(const char *key)
{
	std::map<const char*,int> *filenames;
	filenames = new(std::map<const char*,int>);
	filenames->clear();

	ASSERT(key != NULL);
	std::multimap<std::string, CPageRef>::iterator p;
	for (p = m_index.begin(); p != m_index.end(); p++) {
		if (p->first.compare(key) == 0) {
			CPageRef pr = p->second;
			const char *name = LookUp(pr.GetId());
			int page = pr.GetPage();
			filenames->insert(std::pair<const char*,int>(name, page));
		} /* if */
	} /* for */

	return filenames;
}

const char *CHelpIndex::LookUp(int id)
{
	std::multimap<int, std::string>::iterator p;

	if (id == 0)
		p = m_filetable.begin();
	else
		p = m_filetable.find(id);
	return (p == m_filetable.end()) ? NULL : p->second.c_str();
}
