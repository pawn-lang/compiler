#ifndef SHELLFOLDER_H
#define SHELLFOLDER_H

#ifdef __cplusplus
extern "C" {
#endif

#define CSIDL_DESKTOP                   0x0000  /* {user}\Desktop (namespace root) */
#define CSIDL_INTERNET                  0x0001  /* Internet Explorer virtual folder (support?) */
#define CSIDL_PROGRAMS                  0x0002  /* {user}\Start Menu\Programs */
#define CSIDL_CONTROLS                  0x0003  /* My Computer\Control Panel (virtual folder for control panel applets) (support?) */
#define CSIDL_PRINTERS                  0x0004  /* My Computer\Printers (virtual folder for installed printers) (support?) */
#define CSIDL_PERSONAL                  0x0005  /* {user}\My Documents */
#define CSIDL_FAVORITES                 0x0006  /* {user}\Favourites */
#define CSIDL_STARTUP                   0x0007  /* {user}\Start Menu\Programs\Startup */
#define CSIDL_RECENT                    0x0008  /* {user}\Recent (recently used documents) */
#define CSIDL_SENDTO                    0x0009  /* {user}\SendTo folder */
#define CSIDL_BITBUCKET                 0x000a  /* Recycle bin (directory) (support?) */
#define CSIDL_STARTMENU                 0x000b  /* {user}\Start Menu */
/* 0x000c to 0x000f unknown */
#define CSIDL_DESKTOPDIRECTORY          0x0010  /* {user}\Desktop (file objects on the desktop) */
#define CSIDL_DRIVES                    0x0011  /* My Computer applets (support?) */
#define CSIDL_NETWORK                   0x0012  /* Top level of the network hierarchy (support?) */
#define CSIDL_NETHOOD                   0x0013  /* {user}\NetHood (network neighborhood) */
#define CSIDL_FONTS                     0x0014  /* {Windows}\Fonts */
#define CSIDL_TEMPLATES                 0x0015  /* {user}\Templates (document templates) */
#define CSIDL_COMMON_STARTMENU          0x0016  /* {All users}\Start Menu */
#define CSIDL_COMMON_PROGRAMS           0X0017  /* {All users}\Start Menu\Programs */
#define CSIDL_COMMON_STARTUP            0x0018  /* {All users}\Start Menu\Programs\Startup */
#define CSIDL_COMMON_DESKTOPDIRECTORY   0x0019  /* {All users}\Desktop (file objects on the desktop) */
#define CSIDL_APPDATA                   0x001a  /* {user}\Application Data */
#define CSIDL_PRINTHOOD                 0x001b  /* {user}\Network neighborhood */
#define CSIDL_LOCAL_APPDATA             0x001c  /* {user}\Local Settings\Application Data (non roaming) */
#define CSIDL_ALTSTARTUP                0x001d  /* Alternate Startup ({user} profile) */
#define CSIDL_COMMON_ALTSTARTUP         0x001e  /* Alternate Startup folder ({All Users} profile) */
#define CSIDL_COMMON_FAVORITES          0x001f  /* {All users}\Favourites */
#define CSIDL_INTERNET_CACHE            0x0020  /* {user}\Local Settings\Temporary Internet Files */
#define CSIDL_COOKIES                   0x0021  /* {user}\Cookies */
#define CSIDL_HISTORY                   0x0022  /* {user}\Local Settings\History */
#define CSIDL_COMMON_APPDATA            0x0023  /* {All users}\Application Data */
#define CSIDL_WINDOWS                   0x0024  /* result of GetWindowsDirectory() */
#define CSIDL_SYSTEM                    0x0025  /* result of GetSystemDirectory() */
#define CSIDL_PROGRAM_FILES             0x0026  /* C:\Program Files (folder that most programs install into) */
#define CSIDL_MYPICTURES                0x0027  /* {user}\My documents\My pictures */
#define CSIDL_PROFILE                   0x0028  /* {user} (root directory for the user profile) */
#define CSIDL_SYSTEMX86                 0x0029  /* 'x86 system directory on RISC */
#define CSIDL_PROGRAM_FILESX86          0x002a  /* 'x86 C:\Program Files directory on RISC */
#define CSIDL_PROGRAM_FILES_COMMON      0x002b  /* C:\Program Files\Common Files */
#define CSIDL_PROGRAM_FILES_COMMONX86   0x002c  /* 'x86 C:\Program Files\Common Files on RISC */
#define CSIDL_COMMON_TEMPLATES          0x002d  /* {All users}\Templates (document templates) */
#define CSIDL_COMMON_DOCUMENTS          0x002e  /* {All users}\Documents */
#define CSIDL_COMMON_ADMINTOOLS         0x002f  /* {All users}\Start Menu\Programs\Administrative Tools */
#define CSIDL_ADMINTOOLS                0x0030  /* {user}\Start Menu\Programs\Administrative Tools */
#define CSIDL_CONNECTIONS               0x0031
#define CSIDL_COMMON_MUSIC              0x0035
#define CSIDL_COMMON_PICTURES           0x0036
#define CSIDL_COMMON_VIDEO              0x0037
#define CSIDL_RESOURCES                 0x0038
#define CSIDL_RESOURCES_LOCALIZED       0x0039
#define CSIDL_COMMON_OEM_LINKS          0x003a
#define CSIDL_CDBURN_AREA               0x003b
#define CSIDL_COMPUTERSNEARME           0x003d

#define CSIDL_FLAG_PER_USER_INIT        0x0800
#define CSIDL_FLAG_NO_ALIAS             0x1000
#define CSIDL_FLAG_DONT_VERIFY          0x4000  /* combine with CSIDL_ value */
#define CSIDL_FLAG_CREATE               0x8000  /* combine with CSIDL_ value to force create on SHGetSpecialFolderLocation() */
#define CSIDL_FLAG_MASK                 0xFF00  /* mask for all possible flag values */

#define SHGFP_TYPE_CURRENT              0
#define SHGFP_TYPE_DEFAULT              1


BOOL GetShellFolder(int FolderID,LPTSTR pszSelectedDir);
void MkProfileName(LPTSTR Profile,LPCTSTR BaseName,LPCTSTR AppName,HINSTANCE hinst);

#ifdef __cplusplus
}
#endif

#endif /* SHELLFOLDER_H */
