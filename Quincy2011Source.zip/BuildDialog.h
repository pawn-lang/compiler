#if !defined(AFX_BUILDDIALOG_H__8BD5EC81_72CA_11D4_A77C_00207815827F__INCLUDED_)
#define AFX_BUILDDIALOG_H__8BD5EC81_72CA_11D4_A77C_00207815827F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// BuildDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBuildDialog dialog

class CBuildDialog : public CPropertyPage
{
// Construction
public:
	CBuildDialog(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBuildDialog)
	enum { IDD = IDD_BUILD_PROPERTIES };
	CComboBox	m_TargetHostDropList;
	CComboBox	m_DebugDropList;
	CComboBox	m_OptimizeDropList;
	CString	m_strDefine;
	CString	m_strInclude;
	CString	m_strCompiler;
	CString	m_strCmdLineOptions;
	BOOL	m_Report;
	BOOL	m_Verbose;
	CString	m_strTargetPath;
	BOOL	m_FixedName;
	BOOL	m_BuildOverlay;
	CString	m_strRuntimeDirectory;
	//}}AFX_DATA
	int m_nOptimize;
	int m_nDebugLevel;
	int m_iMaxOptimize;				// 1 .. 3 (instruction set)
	bool m_bOverlayEnabled;			// whether overlay code may be generated
	CString m_strTargetHost;
	BOOL m_bFixedNameEnabled;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBuildDialog)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBuildDialog)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnBrowseincludes();
	afx_msg void OnBrowsecompiler();
	afx_msg void OnVerbose();
	afx_msg void OnReport();
	afx_msg void OnBrowsetarget();
	afx_msg void OnSelchangeOptimize();
	afx_msg void OnSelchangeDebug();
	afx_msg void OnBrowseruntimewk();
	afx_msg void OnSelchangeTargetfile();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BUILDDIALOG_H__8BD5EC81_72CA_11D4_A77C_00207815827F__INCLUDED_)
