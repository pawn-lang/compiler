// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////
#include "EnBitmap.h"
#include "MTabWnd.h"
#include "SymBrowseDialog.h"

class CMainFrame : public CMDITabFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();
	void HideTYCPPCommand();
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
//	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
	void DoClose()
		{ OnClose(); }
	void LoadWindowPlacement();
	void SaveWindowPlacement();
	void SetRowColumn(int row, int column);

	void SetLowPane(HWND hwnd);
	void SetRightPane(HWND hwnd);
	HWND GetLowPane() { return m_hwndPaneBottom && ::IsWindowVisible(m_hwndPaneBottom) ? m_hwndPaneBottom : NULL; }
	HWND GetRightPane() { return m_hwndPaneBottom && ::IsWindowVisible(m_hwndPaneRight) ? m_hwndPaneRight : NULL; }

	CSymBrowseDialog* GetSymBrowser() const
		{ return SymBrowseCreated ? m_pdlgSymBrowse : NULL; }
	void CreateSymBrowser();
	bool UpdateSymBrowser(const CString &filename = _T(""));
	int LookupSymbol(const CString &symbol, CString *filename, int *line,
		             CString *syntax, CString *summary, int nextmatch = -1);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

private:
	void GetClientArea(RECT *prcClient, RECT *prcPaneBottom, RECT *prcPaneRight);

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar24  m_wndToolBar;
	HWND        m_hwndPaneBottom;
	HWND        m_hwndPaneRight;

	bool SymBrowseCreated;
	CSymBrowseDialog* m_pdlgSymBrowse;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnWindowCloseAll();
	afx_msg void OnFileSaveAll();
	afx_msg void OnUpdateFileSaveAll(CCmdUI* pCmdUI);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnActivateApp(BOOL bActive, DWORD hTask);
	afx_msg void OnUpdateWindowCloseAll(CCmdUI* pCmdUI);
	afx_msg void OnVisibleSpaces();
	afx_msg void OnUpdateVisibleSpaces(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
