#if !defined(AFX_MDICLIENT_H__07D11962_0399_11D3_BC0D_89BC9BB36074__INCLUDED_)
#define AFX_MDICLIENT_H__07D11962_0399_11D3_BC0D_89BC9BB36074__INCLUDED_

/////////////////////////////////////////////////////////////////////////////
//
// Copyright � 1998 Written by Dieter Fauth 
//		mailto:fauthd@zvw.de 
//  
// This code may be used in compiled form in any way you desire. This    
// file may be redistributed unmodified by any means PROVIDING it is     
// not sold for profit without the authors written consent, and     
// providing that this notice and the authors name and all copyright     
// notices remains intact. If the source code in this file is used in     
// any  commercial application then a statement along the lines of     
// "Portions Copyright � 1999 Dieter Fauth" must be included in     
// the startup banner, "About" box or printed documentation. An email     
// letting me know that you are using it would be nice as well. That's     
// not much to ask considering the amount of work that went into this.    
//    
// This file is provided "as is" with no expressed or implied warranty.    
// The author accepts no liability for any damage/loss of business that    
// this product may cause.    
//  
// ==========================================================================  
// HISTORY:	  
// ==========================================================================  
//			1.00	08 May 1999	- Initial release.  
// ==========================================================================  
//  
/////////////////////////////////////////////////////////////////////////////

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MdiClient.h : header file
//
class CTabBar;

/////////////////////////////////////////////////////////////////////////////
// CMdiClient window

class CMdiClient : public CWnd
{
// Construction
public:
	CMdiClient();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMdiClient)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMdiClient();
	CTabBar  *m_pWndTabs;

protected:
	void RemoveHandle(HWND hWnd);
	void AddHandle(HWND hWnd);

	// Generated message map functions
protected:
	//{{AFX_MSG(CMdiClient)
	//}}AFX_MSG
	afx_msg LRESULT OnMDICreate(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnMDIDestroy(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MDICLIENT_H__07D11962_0399_11D3_BC0D_89BC9BB36074__INCLUDED_)
