// titlebar.h : header file
//
#ifndef _TABBAR_H_58A62F03_FEFE_11D2_BC0D_006008CCD137
#define _TABBAR_H_58A62F03_FEFE_11D2_BC0D_006008CCD137

/////////////////////////////////////////////////////////////////////////////
//
// Copyright � 1998 Written by Dieter Fauth 
//		mailto:fauthd@zvw.de 
//  
// This code may be used in compiled form in any way you desire. This    
// file may be redistributed unmodified by any means PROVIDING it is     
// not sold for profit without the authors written consent, and     
// providing that this notice and the authors name and all copyright     
// notices remains intact. If the source code in this file is used in     
// any  commercial application then a statement along the lines of     
// "Portions Copyright � 1999 Dieter Fauth" must be included in     
// the startup banner, "About" box or printed documentation. An email     
// letting me know that you are using it would be nice as well. That's     
// not much to ask considering the amount of work that went into this.    
//    
// This file is provided "as is" with no expressed or implied warranty.    
// The author accepts no liability for any damage/loss of business that    
// this product may cause.    
//  
// ==========================================================================  
// HISTORY:	  
// ==========================================================================  
//			1.00	08 May 1999	- Initial release.  
// ==========================================================================  
//  
/////////////////////////////////////////////////////////////////////////////

#include "TabCtrlEx.h"

/////////////////////////////////////////////////////////////////////////////
// CTabBar window
#define CTabBar_parent CControlBar 
class CTabBar : public CTabBar_parent
{
	DECLARE_DYNAMIC(CTabBar)
// Construction
public:
// Construction
public:
	CTabBar();

// Attributes
public:
	void RemoveHandle(HWND hWnd);
	void AddHandle(HWND hWnd);
	void SetTitles(void);
	int  HandleCount()	{ return m_tabctrl.GetItemCount(); }
	
// Operations
public:
	BOOL Create(CWnd* pParentWnd,
		DWORD dwStyle = WS_CHILD | WS_VISIBLE | CBRS_TOP,
		UINT nID = AFX_IDW_STATUS_BAR);

// Implementation
public:
//	virtual ~CTabBar();
  	virtual void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);

protected:
//	CTabCtrl   m_tabctrl;		// works also, but the Ex version gives a nice look
	CTabCtrlEx m_tabctrl;
	CImageList m_imagelist;
	bool IsRGB;

// Overrides
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabBar)
	//}}AFX_VIRTUAL

protected:
	// Generated message map functions
	//{{AFX_MSG(CTabBar)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	afx_msg void OnSelchange(NMHDR* pNMHDR, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif

