// MainFrm.cpp : implementation of the CMainFrame class
// $Id: mainfrm.cpp 4535 2011-07-07 09:15:22Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "debugger.h"

#include "MainFrm.h"
#include "TextView.h"
#include "TextDocument.h"
#include "childfrm.h"
#include "ErrorLogDialog.h"
#include "Compiler.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_WINDOW_CLOSE_ALL, OnWindowCloseAll)
	ON_COMMAND(ID_FILE_SAVE_ALL, OnFileSaveAll)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_ALL, OnUpdateFileSaveAll)
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_ACTIVATEAPP()
	ON_UPDATE_COMMAND_UI(ID_WINDOW_CLOSE_ALL, OnUpdateWindowCloseAll)
	ON_COMMAND(IDM_SHOWSPACES, OnVisibleSpaces)
	ON_UPDATE_COMMAND_UI(IDM_SHOWSPACES, OnUpdateVisibleSpaces)
	//}}AFX_MSG_MAP
	// Global help commands
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_EXT,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
};


/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	SymBrowseCreated = false;
	m_pdlgSymBrowse = new CSymBrowseDialog;
}

CMainFrame::~CMainFrame()
{
	delete m_pdlgSymBrowse;
}

void CMainFrame::HideTYCPPCommand()
{
#ifdef _DEBUG
	m_wndToolBar.GetToolBarCtrl().HideButton(ID_WRITETUTORIAL);
#endif
	m_wndToolBar.GetToolBarCtrl().HideButton(ID_TYCPP);
	CMenu* menu = GetMenu();
	ASSERT(menu != 0);
	menu->RemoveMenu(ID_TYCPP, MF_BYCOMMAND);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	m_hwndPaneBottom = 0;
	m_hwndPaneRight = 0;

	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	LoadWindowPlacement();
	if (!m_wndToolBar.CreateEx(this) || !m_wndToolBar.LoadToolBar(IDR_MAINFRAME)) {
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	} /* if */
	if (theApp.IsRGBmode())
		m_wndToolBar.SetFullColorImage(IDR_MAINFRAME_RGB, RGB(192,192,192), 16);

#ifndef _DEBUG
	m_wndToolBar.GetToolBarCtrl().HideButton(ID_WRITETUTORIAL);
#endif

#ifndef TYCPP
  #ifdef _DEBUG
	m_wndToolBar.GetToolBarCtrl().HideButton(ID_WRITETUTORIAL);
  #endif
	HideTYCPPCommand();
#endif

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}


	m_wndStatusBar.SetPaneInfo(1, ID_INDICATOR_EXT, 0, 120);
	m_wndStatusBar.SetPaneText(1, "");

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to be dockable
#if 0
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
#endif

	if (CMDITabFrameWnd::CreateTabs() == -1)
		return -1;

	LoadBarState("Settings");

	// add client scrolling support
	// m_hWndMDIClient->ModifyStyle(0, WS_HSCROLL | WS_VSCROLL, 0);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// Use the specific class name we established earlier
	cs.lpszClass = _T("QuincyAppClass");
	return CMDIFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

void CMainFrame::LoadWindowPlacement()
{
	CString strBuffer = theApp.GetProfileString("Settings", "WindowPos");
	if (!strBuffer.IsEmpty())	{
		WINDOWPLACEMENT wp;
		int cRead = _stscanf(strBuffer, "%i:%i:%i:%i:%i:%i:%i:%i:%i:%i",
				&wp.flags, &wp.showCmd,
				&wp.ptMinPosition.x, &wp.ptMinPosition.y,
				&wp.ptMaxPosition.x, &wp.ptMaxPosition.y,
				&wp.rcNormalPosition.left, &wp.rcNormalPosition.top,
				&wp.rcNormalPosition.right, &wp.rcNormalPosition.bottom);

		if (cRead == 10)	{
			wp.showCmd = theApp.m_nCmdShow;
			if (wp.flags & WPF_RESTORETOMAXIMIZED)
				theApp.m_nCmdShow = SW_SHOWMAXIMIZED;
			SetWindowPlacement(&wp);
		}
	}
}

VOID CMainFrame::SaveWindowPlacement()
{
	WINDOWPLACEMENT wp;
	if (GetWindowPlacement(&wp))	{
		if (IsZoomed())
			wp.flags = WPF_RESTORETOMAXIMIZED;
		CString strBuffer;
		strBuffer.Format("%i:%i:%i:%i:%i:%i:%i:%i:%i:%i",
			wp.flags, wp.showCmd,
			wp.ptMinPosition.x, wp.ptMinPosition.y,
			wp.ptMaxPosition.x, wp.ptMaxPosition.y,
			wp.rcNormalPosition.left, wp.rcNormalPosition.top,
			wp.rcNormalPosition.right, wp.rcNormalPosition.bottom);
		theApp.WriteProfileString("Settings", "WindowPos", strBuffer);
	}
}


void CMainFrame::SetRowColumn(int row, int column)
{
	if (::IsWindow(m_wndStatusBar.m_hWnd))	{
		CString str;
		if (row >= 0 && column >= 0)
			str.Format("Ln %d, Col %d", row, column);
		m_wndStatusBar.SetPaneText(1, str.GetBuffer(0));
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnClose()
{
	if (theApp.StopDebugging())	{
		theApp.SaveOpenDocuments();
		SaveBarState("Settings");
		SaveWindowPlacement();
		CMDIFrameWnd::OnClose ();
	}
}

void CMainFrame::OnWindowCloseAll()
{
	theApp.SaveAllModified();
	theApp.CloseAllDocuments(false);
	theApp.CloseBuildPanel();
	theApp.CloseSymBrowser();
}

void CMainFrame::OnUpdateWindowCloseAll(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(theApp.IsFileOpen());
}

void CMainFrame::OnFileSaveAll()
{
	theApp.SaveAllDocuments();
}

void CMainFrame::OnUpdateFileSaveAll(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(false);
}

BOOL CMainFrame::OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch (LOWORD(wParam)) {
	case ID_WINDOW_NEXT_PANE:
		CMDITabFrameWnd::OnWindowNextPane();
	case ID_WINDOW_PREV_PANE:
		CMDITabFrameWnd::OnWindowPrevPane();
	} /* switch */

	return CMDIFrameWnd::OnCommand(wParam, lParam);
}


void CMainFrame::OnDestroy()
{
	CMDIFrameWnd::OnDestroy();
}

void CMainFrame::GetClientArea(RECT *prcClient, RECT *prcPaneBottom, RECT *prcPaneRight)
{
	RECT rcFrame;
	GetClientRect(&rcFrame);
	// get position of tool bar(s) (top position of client area)
	RECT rcBar;
	if (m_wndMdiClient.m_pWndTabs != NULL)
		m_wndMdiClient.m_pWndTabs->GetWindowRect(&rcBar);
	else
		m_wndToolBar.GetWindowRect(&rcBar);	//for no TAB bar
	ScreenToClient((LPPOINT)&rcBar.right);
	int yTop = rcBar.bottom;
	// get position status bar (bottom position of the client area of bottom pane)
	m_wndStatusBar.GetClientRect(&rcBar);
	int yBottom = rcFrame.bottom - rcBar.bottom;
	// see whether there is a bottom pane
	int ySeparator;
	RECT rcPaneBottom;
	if (m_hwndPaneBottom != 0) {
		::GetWindowRect(m_hwndPaneBottom, &rcPaneBottom);
		::OffsetRect(&rcPaneBottom, -rcPaneBottom.left, -rcPaneBottom.top);
		ySeparator = yBottom - rcPaneBottom.bottom;
	} else {
		ySeparator = rcPaneBottom.bottom = yBottom;
	} /* if */
	// see whether there is a right pane
	int xSeparator;
	RECT rcPaneRight;
	if (m_hwndPaneRight != 0) {
		::GetWindowRect(m_hwndPaneRight, &rcPaneRight);
		::OffsetRect(&rcPaneRight, -rcPaneRight.left, -rcPaneRight.top);
		xSeparator = rcFrame.right - rcPaneRight.right;
	} else {
		xSeparator = rcPaneRight.right = rcFrame.right;
	} /* if */
	// fill in the structures
	if (prcClient)
		SetRect(prcClient, 0, yTop, xSeparator, ySeparator - yTop);
	if (prcPaneBottom)
		SetRect(prcPaneBottom, 0, ySeparator, rcFrame.right, rcPaneBottom.bottom);
	if (prcPaneRight)
		SetRect(prcPaneRight, xSeparator, yTop, rcPaneRight.right, ySeparator - yTop);
}

void CMainFrame::SetLowPane(HWND hwnd)
{
	HWND hwndOldPane = m_hwndPaneBottom;
	m_hwndPaneBottom = hwnd;

	RECT rcClient, rcPaneBottom, rcPaneRight;
	GetClientArea(&rcClient, &rcPaneBottom, &rcPaneRight);

	// move the dialog inside its parent
	::MoveWindow(m_hWndMDIClient, rcClient.left, rcClient.top, rcClient.right, rcClient.bottom, TRUE);
	if (m_hwndPaneBottom) {
		if (m_hwndPaneRight)
			::MoveWindow(m_hwndPaneRight, rcPaneRight.left, rcPaneRight.top, rcPaneRight.right, rcPaneRight.bottom, TRUE);
		::MoveWindow(m_hwndPaneBottom, rcPaneBottom.left, rcPaneBottom.top, rcPaneBottom.right, rcPaneBottom.bottom, TRUE);
		if (!::IsWindowVisible(m_hwndPaneBottom))
			::ShowWindow(m_hwndPaneBottom, SW_SHOWNA);
	} else if (hwndOldPane) {
		::ShowWindow(hwndOldPane, SW_HIDE);
		if (m_hwndPaneRight)
			::MoveWindow(m_hwndPaneRight, rcPaneRight.left, rcPaneRight.top, rcPaneRight.right, rcPaneRight.bottom, TRUE);
	} /* if */
}

void CMainFrame::SetRightPane(HWND hwnd)
{
	HWND hwndOldPane = m_hwndPaneRight;
	m_hwndPaneRight = hwnd;

	RECT rcClient, rcPaneRight;
	GetClientArea(&rcClient, NULL, &rcPaneRight);

	// move the dialog inside its parent
	::MoveWindow(m_hWndMDIClient, rcClient.left, rcClient.top, rcClient.right, rcClient.bottom, TRUE);
	if (m_hwndPaneRight) {
		::MoveWindow(m_hwndPaneRight, rcPaneRight.left, rcPaneRight.top, rcPaneRight.right, rcPaneRight.bottom, TRUE);
		if (!::IsWindowVisible(m_hwndPaneRight))
			::ShowWindow(m_hwndPaneRight, SW_SHOWNA);
	} else if (hwndOldPane) {
		::ShowWindow(hwndOldPane, SW_HIDE);
	} /* if */
}

void CMainFrame::OnSize(UINT nType, int cx, int cy)
{
	CMDIFrameWnd::OnSize(nType, cx, cy);

	if (m_hwndPaneBottom != 0 && ::IsWindowVisible(m_hwndPaneBottom))
		SetLowPane(m_hwndPaneBottom);
	if (m_hwndPaneRight != 0 && ::IsWindowVisible(m_hwndPaneRight))
		SetRightPane(m_hwndPaneRight);
}

BOOL CMainFrame::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;	// background is not erased, but we say so anyway to avoid flicker
	//return CMDIFrameWnd::OnEraseBkgnd(pDC);
}

void CMainFrame::OnActivateApp(BOOL bActive, DWORD hTask)
{
	CMDIFrameWnd::OnActivateApp(bActive, hTask);

	// check the timestamp of all open files
	if (bActive) {
		POSITION tpos = theApp.GetFirstDocTemplatePosition();
		while (tpos != 0) {
			CDocTemplate* pTem = theApp.GetNextDocTemplate(tpos);
			ASSERT(pTem != 0);
			POSITION dpos = pTem->GetFirstDocPosition();
			while (dpos != 0)	{
    			CTextDocument* pDoc = static_cast<CTextDocument*>(pTem->GetNextDoc(dpos));
    			ASSERT(pDoc != 0);
    			int status = pDoc->CheckFileTime();
    			if (status) {
    				CString pathname = pDoc->GetPathName();
    				CString msg;
    				int defbtn = 0;
    				if (pDoc->IsModified()) {
    					msg.Format("The file \"%s\" was modified by another application,\n"
    							   "but you also have unsaved changes in this file.\n\n"
    							   "Reload it from disk (and loose your changes)?", pathname);
    					defbtn = MB_DEFBUTTON2;
    				} else {
    					msg.Format("The file \"%s\" was modified by another application.\n\n"
    							   "Reload it from disk?", pathname);
    				} /* if */
    				int reply = MessageBox(msg, "File modified", MB_YESNO | MB_ICONQUESTION);
    				if (reply == IDYES) {
    					pDoc->OnOpenDocument(pathname);
    					CEditorView *pView = pDoc->GetView();
    					pView->ResetKeywords();
    					pDoc->UpdateView();
    				} else {
    					pDoc->UpdateFileTime();	// do not warn twice
    				} /* if */
    			} /* if */
			} /* while (dpos) */
		} /* while (tpos) */

		// if there is an open file, activate it
		CMDIChildWnd* pFocusWnd = theApp.GetMDIChild();
		if (pFocusWnd)
			pFocusWnd->SetFocus();
	} /* if */
}

void CMainFrame::OnVisibleSpaces() 
{
	bool option = !theApp.ShowTabSpaces();
	theApp.SetShowTabSpaces(option);
	theApp.InvalidateAllViews();
}

void CMainFrame::OnUpdateVisibleSpaces(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(theApp.ShowTabSpaces());
}

void CMainFrame::CreateSymBrowser()
{
	ASSERT(m_pdlgSymBrowse != 0);
	if (!SymBrowseCreated) {
		m_pdlgSymBrowse->Create(IDD_SYMBROWSE);
		SymBrowseCreated = true;
		SetRightPane(m_pdlgSymBrowse->m_hWnd);
	} /* if */
}

bool CMainFrame::UpdateSymBrowser(const CString &filename)
{
	ASSERT(m_pdlgSymBrowse != 0);
	int length = filename.GetLength();
	if (length == 0) {
		return m_pdlgSymBrowse->LoadAllReportFiles() > 0;
	} else {
		/* find period position (the extension may not always be ".amx") */
		int ext = filename.ReverseFind('.');
		if (ext > 0)
			return m_pdlgSymBrowse->LoadReportFile(filename.Left(ext) + ".xml");
	} /* if */
	return false;
}

int CMainFrame::LookupSymbol(const CString &symbol, CString *filename, int *line,
							 CString *syntax, CString *summary, int nextmatch)
{
	ASSERT(m_pdlgSymBrowse != 0);
	return m_pdlgSymBrowse->Lookup(symbol, filename, line, syntax, summary, nextmatch);
}
