// ReaderWrapper.h: interface for the CReaderWrapper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_READERWRAPPER_H__F594660B_67F3_461B_A7A7_42CE142D68D7__INCLUDED_)
#define AFX_READERWRAPPER_H__F594660B_67F3_461B_A7A7_42CE142D68D7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ddeml.h"

/*************************************************************************

  SeaSideTech - www.seasidetech.net.
  -------------------------------------

* Software: CReaderWrapper                                                     *
* Version:  1.1						                                           *
* Date:     2004-11-09			                                               *
* Author:   Vincent FLOURIOT - vincent.flouriot@seasidetech.net                *
* License:  Freeware                                                           *
*                                                                              *
* You may use, modify and redistribute this software as you wish.              *

**************************************************************************

						OVERVIEW

  This class uses DDE messages to communicate with acrobat reader (or acrobat)
  Most of usefull DDE messages have been wrapped into that class.
  Acrobat DDE messages are described in the adobe document called IACReference.pdf
  (this document can be downloaded inside the ADOBE SDK)

**************************************************************************

 Evolution of the component CReaderWrapper.:
 -----------------------------------------
  (initials, date, modification)

   created by :	 Vincent Flouriot  08/10/04
				 1.1 : First release

*************************************************************************/

class CReaderWrapper  
{
public:
	
	/*Constructor*/
	CReaderWrapper(CString stPdfFile);
	virtual ~CReaderWrapper();
	
	/*Open the document to reader*/
	BOOL DocOpen(CString stPdfFile = "");

	/*Seek to page (first page number is 1)*/
	void GoToPage(int iPage);

	/*Seek to bookmark*/
	void GoToPage(const char * bookmark);

	/*Close all documents*/
	void CloseAllDocs();

	/*Close the current document*/
	void DocClose();
	
	/*Exit AR application*/
	void ExitAcrobat();

	/*Print the document, displaying a modal print dialog box*/
	void FilePrint();
	
	/*Print the document, without displaying a modal print dialog box*/
	void FilePrintSilent();
	
	/*If set, the wrapper closes the previous file opened, so that multiple 
	 *calls (to different files) won't open meny windows*/
	void SetAutoClose(BOOL value);

	/*Returns whether the DDE interface was correctly set up*/
	BOOL Valid() const
		{ return hConv != NULL; }

private:
	
	BOOL _ExecuteQuery(CString stQuery);
	CString stPdfFileName;
	DWORD dwIdInst;
	HCONV hConv;
	BOOL AutoClose;
	BOOL TryDDE;
};

#endif // !defined(AFX_READERWRAPPER_H__F594660B_67F3_461B_A7A7_42CE142D68D7__INCLUDED_)
