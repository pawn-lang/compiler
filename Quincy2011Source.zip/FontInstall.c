// FontInstall: installs a font (for the session) if it is not already present
// $Id: FontInstall.c 4258 2010-06-17 10:21:31Z thiadmer $
#include <windows.h>

int CALLBACK EnumFontsProc(ENUMLOGFONTEX *lf, NEWTEXTMETRICEX *tm,
                           DWORD fonttype, LPARAM lpInfo)
{
  // return 0 to stop search (font name was found)
  return lstrcmpi((LPSTR)lpInfo,lf->elfLogFont.lfFaceName) != 0;
}

BOOL CheckFontInstall(LPSTR lpFontname, LPSTR lpFilename)
{
  int result;
  HDC hdc;
  LOGFONT lf;

  lf.lfCharSet = DEFAULT_CHARSET;
  strcpy(lf.lfFaceName, lpFontname);
  hdc = GetDC(0);
  result = EnumFontFamiliesEx(hdc, &lf, EnumFontsProc, (LPARAM)lpFontname, 0);
  ReleaseDC(0, hdc);

  if (result != 0) {
    if (lpFilename!=NULL && AddFontResource(lpFilename)) {
      SendMessage(HWND_BROADCAST, WM_FONTCHANGE, 0, 0L);
      return TRUE;                      // font now installed
    } else {
      return FALSE;                     // could not install font
    } /* if */
  } else {
    return TRUE;                        // font already installed
  } /* if */
}

