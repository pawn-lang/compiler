// ChildFrm.cpp : implementation of the CChildFrame class
// $Id: ChildFrm.cpp 4535 2011-07-07 09:15:22Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "compiler.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "EditorDoc.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame classes

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	m_pview = 0;
}

CChildFrame::~CChildFrame()
{
}

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers


void CChildFrame::OnContextMenu(CWnd *pWnd, CPoint point)
{
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_MAINFRAME));
	UINT action;

	if (m_pview != 0)	{
		CMenu* pPopup;
		CEditorView* editorview = dynamic_cast<CEditorView*>(m_pview);
		ASSERT(editorview);
		pPopup = menu.GetSubMenu(1);
		ASSERT(pPopup != 0);

		/* also set the text cursor to the location clicked on */
		editorview->HideInfoTip();
		CPoint pt = point;
		ScreenToClient(&pt);
		pt = editorview->ScreenToCharCoordinates(pt);
		editorview->SetLineColumn(pt.y + 1, pt.x + 1);

		action = editorview->IsFindText() ? MF_ENABLED : MF_DISABLED | MF_GRAYED;
		pPopup->EnableMenuItem(ID_EDIT_FIND_NEXT, action);
		action = editorview->IsSelectionMarked() ? MF_ENABLED : MF_DISABLED | MF_GRAYED;
		pPopup->EnableMenuItem(ID_EDIT_CUT, action);
		pPopup->EnableMenuItem(ID_EDIT_COPY, action);
		action = editorview->IsSelectionMarked() || !editorview->IsRecording() ? MF_ENABLED : MF_DISABLED | MF_GRAYED;
		pPopup->EnableMenuItem(ID_EDIT_CLEAR, action);
		action = IsClipboardFormatAvailable(CF_TEXT) ? MF_ENABLED : MF_DISABLED | MF_GRAYED;
		pPopup->EnableMenuItem(ID_EDIT_PASTE, action);
		action = editorview->GetDocument()->CanUndo() ? MF_ENABLED : MF_DISABLED | MF_GRAYED;
		pPopup->EnableMenuItem(ID_EDIT_UNDO, action);
		action = editorview->GetDocument()->CanRedo() ? MF_ENABLED : MF_DISABLED | MF_GRAYED;
		pPopup->EnableMenuItem(ID_EDIT_REDO, action);
		action = editorview->CanMatchBraces() ? MF_ENABLED : MF_DISABLED | MF_GRAYED;
		pPopup->EnableMenuItem(ID_BRACEMATCH, action);
		// ---- display and track the popup menu, sending commands to the view object
		editorview->EnableInfoTip(false);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, pWnd);
		editorview->EnableInfoTip(true);
	}
}



