/* Routines to get "special" folder locations.
 * (Originally written for Yawpi).
 */
#define WIN32_LEAN_AND_MEAN
#include <tchar.h>
#include <windows.h>
#include <shlobj.h>

#if defined UNICODE || defined _UNICODE
  #define SHGETFOLDERPATH "SHGetFolderPathW"
#else
  #define SHGETFOLDERPATH "SHGetFolderPathA"
#endif

static void _SHFree(void *p)       // free shell item identifier memory
{
    IMalloc     *pMalloc;

    SHGetMalloc(&pMalloc);
    if (pMalloc != NULL) {
        pMalloc->lpVtbl->Free(pMalloc, p);
        pMalloc->lpVtbl->Release(pMalloc);
    }
}

typedef HRESULT (WINAPI *fpSHGetFolderPath)(HWND hwndOwner, int nFolder, HANDLE hToken, DWORD dwFlags, LPTSTR pszPath);
typedef HRESULT (WINAPI *fpSHGetSpecialFolderLocation)(HWND hwndOwner, int nFolder, LPITEMIDLIST *ppidl);
#if !defined CSIDL_FLAG_DONT_VERIFY
  #define CSIDL_FLAG_DONT_VERIFY  0x4000
#endif
#if !defined CSIDL_FLAG_CREATE
  #define CSIDL_FLAG_CREATE       0x8000
#endif
#if !defined SHGFP_TYPE_CURRENT
  #define SHGFP_TYPE_CURRENT      0
  #define SHGFP_TYPE_DEFAULT      1
#endif

BOOL GetShellFolder(int FolderID, LPTSTR pszSelectedDir)
{
    /* check platform support */
    BOOL bValid = FALSE;
    fpSHGetFolderPath xSHGetFolderPath = NULL;
    fpSHGetSpecialFolderLocation xSHGetSpecialFolderLocation = NULL;
    HINSTANCE hinstShell;

    *pszSelectedDir = '\0';

    /* SHELL32.DLL should already have been implicitly loaded, because of the
     * calls to SHGetMalloc() and SHGetPathFromIDList(). The alternative DLL,
     * SHFOLDER.DLL is usually not loaded, though.
     */
    hinstShell = LoadLibrary("shell32.dll");
    if (hinstShell == NULL)
        hinstShell = LoadLibrary("shfolder.dll");
    if (hinstShell == NULL)
        return FALSE;

    xSHGetFolderPath = (void*)GetProcAddress(hinstShell, SHGETFOLDERPATH);
    if (xSHGetFolderPath == NULL) {
        /* new function is not present in this DLL (probably SHFOLDER.DLL) */
        FreeLibrary(hinstShell);
        hinstShell = LoadLibrary("shfolder.dll");
        if (hinstShell != NULL)
            xSHGetFolderPath = (void*)GetProcAddress(hinstShell, SHGETFOLDERPATH);
    } /* if */

    if (xSHGetFolderPath == NULL) {
        /* new function is not present in either DLL, try the older function */
        xSHGetSpecialFolderLocation = (void*)GetProcAddress(hinstShell, "SHGetSpecialFolderLocation");
        if (xSHGetSpecialFolderLocation == NULL) {
            /* older function is not present in this DLL (possibly SHFOLDER.DLL),
             * try the first DLL
             */
            FreeLibrary(hinstShell);
            hinstShell = LoadLibrary("shell32.dll");
            if (hinstShell == NULL)
                return FALSE;
            xSHGetSpecialFolderLocation = (void*)GetProcAddress(hinstShell, "SHGetSpecialFolderLocation");
            if (xSHGetSpecialFolderLocation == NULL) {
                FreeLibrary(hinstShell);
                return FALSE;
            } /* if */
        } /* if */
    } /* if */

    /* now we have obtained either of two functions in either of two DLLs */
    if (xSHGetFolderPath != NULL) {
        HRESULT hr;
        hr = xSHGetFolderPath(NULL, FolderID | CSIDL_FLAG_CREATE, NULL, SHGFP_TYPE_CURRENT, pszSelectedDir);
        if (!SUCCEEDED(hr) || *pszSelectedDir == '\0')
            xSHGetFolderPath(NULL, FolderID | CSIDL_FLAG_DONT_VERIFY, NULL, SHGFP_TYPE_CURRENT, pszSelectedDir);
        bValid = *pszSelectedDir != '\0';
    } else {
        LPITEMIDLIST pidl;
        if (xSHGetSpecialFolderLocation(NULL, FolderID, &pidl) == NOERROR) {
            if (SHGetPathFromIDList(pidl, pszSelectedDir))
                bValid = TRUE;
            _SHFree(pidl);
        } /* if */
    } /* if */

    FreeLibrary(hinstShell);
    return bValid;
}

/* The default location for the application's profile is the application
 * directory: the path where the EXE also resides. If this path is not writable
 * (e.g. on a CD-ROM or protected by Microsoft Windows), the function creates
 * a directory under "Local Settings\Application Data". It then copies the
 * original profile file (from the application directory) to the "Application
 * Data" directory (but only if it does not yet exist). Therefore, any content
 * pre-configured in the profile (at installation time) is copied to the
 * writeable directory.
 *
 * Profile  [out] full path to the profile
 * BaseName [in]  base name of the profile, including extension (e.g. "quincy.ini")
 * AppName  [in]  name for the subdirectory in the "Application Data" directory,
 *                if the main directory happens to be read-only
 * hinst    [in]  program/DLL instance
 */
void MkProfileName(LPTSTR Profile,LPCTSTR BaseName,LPCTSTR AppName,HINSTANCE hinst)
{
  TCHAR path[MAX_PATH];
  TCHAR *ptr;
  DWORD attrib;

  GetModuleFileName(hinst, path, MAX_PATH);
  if ((ptr=strrchr(path, '\\')) != NULL)
    *ptr='\0';    /* there should always be a path (if Microsoft's doc. is right) */
  _tcscpy(Profile, path);
  _tcscat(Profile, _T("\\"));
  _tcscat(Profile, BaseName);

  /* If the file does not exist, try to create it first (to check whether the
   * location is acceptable).
   */
  attrib = GetFileAttributes(Profile);
  if (attrib == 0xffffffff) {
    /* the file does not exist, try to create it */
    HANDLE fh=CreateFile(Profile,GENERIC_WRITE|GENERIC_READ,0,NULL,CREATE_NEW,
                         FILE_ATTRIBUTE_NORMAL | FILE_FLAG_DELETE_ON_CLOSE, NULL);
    if (fh != INVALID_HANDLE_VALUE)
      CloseHandle(fh);
  } /* if */

  /* If no write access to the application directory, create a path in the
   * "Local Settings\Application Data"; then copy the original profile file
   * from the application directory to "Application Data".
   */
  attrib = GetFileAttributes(Profile);
  if ((attrib & FILE_ATTRIBUTE_READONLY)!=0 && GetShellFolder(CSIDL_APPDATA,path)) {
    /* no write permission, change the path (new path to use was found) */
    _tcscat(path, _T("\\"));
    _tcscat(path, AppName);
    CreateDirectory(path, NULL);
    _tcscat(path, _T("\\"));
    _tcscat(path, BaseName);
	if (GetFileAttributes(path) == 0xffffffff) {
		CopyFile(Profile, path, TRUE);   /* copy the file, but fail if it already exists */
	    SetFileAttributes(path, FILE_ATTRIBUTE_NORMAL);  /* remove any "read-only" attribute */
	} /* if */
    _tcscpy(Profile, path);
  } /* if */
}
