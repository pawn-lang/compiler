// SymBrowseDialog.cpp : implementation file
// $Id: errorlogdialog.cpp 4240 2010-04-06 15:55:46Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "MainFrm.h"
#include "SymBrowseDialog.h"
#include "tinyxml/tinyxml.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSymBrowseDialog dialog

IMPLEMENT_DYNAMIC(CSymBrowseDialog, CDialog)

CSymBrowseDialog::CSymBrowseDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSymBrowseDialog::IDD, pParent)
{
	SymbolList.Next = 0;
}

CSymBrowseDialog::~CSymBrowseDialog()
{
	Clear();
}

void CSymBrowseDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSymBrowseDialog, CDialog)
	//{{AFX_MSG_MAP(CSymBrowseDialog)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_SHOWWINDOW()
	ON_WM_CLOSE()
	ON_WM_NCHITTEST()
	ON_BN_CLICKED(IDCLOSE, OnExplicitClose)
	ON_NOTIFY(NM_DBLCLK, IDC_SYMTREE, &CSymBrowseDialog::OnDblclkTree)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSymBrowseDialog message handlers

int CSymBrowseDialog::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	theApp.RestoreDialogWindowPosition("SymbolBrowser", this);
	return 0;
}

void CSymBrowseDialog::OnDestroy()
{
	theApp.SaveDialogWindowPosition("SymbolBrowser", this);
	CDialog::OnDestroy();
}

BOOL CSymBrowseDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	ShowWindow(SW_HIDE);
	SetParent((CMainFrame*)theApp.m_pMainWnd);
	((CMainFrame*)theApp.m_pMainWnd)->SetRightPane(0);

    CRect rc;
    GetClientRect(&rc);
	PostMessage(WM_SIZE, SIZE_RESTORED, MAKELONG(rc.right, rc.bottom));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSymBrowseDialog::OnDblclkTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	// -- get the current selection and send to CQuincyApp object
	CTreeCtrl *tree = (CTreeCtrl*)GetDlgItem(IDC_SYMTREE);
	ASSERT(tree != NULL);
	HTREEITEM leaf = tree->GetSelectedItem();
	CSymbolEntry *item;
	item = (CSymbolEntry*)tree->GetItemData(leaf);
	if (item) {
		const char *symbolname = item->SymbolName.GetBuffer();
		ASSERT(symbolname != 0);
		const char *ptr = strchr(symbolname, ':');
		if (ptr)
			symbolname = ptr + 1;
		if (strlen(symbolname) == 0)
			symbolname = 0;
		theApp.SelectFileAndLine(item->Source, item->Line, false, symbolname);
	} /* if */
	*pResult = 0;
}

void CSymBrowseDialog::OnSize(UINT nType, int cx, int cy)
{
#define LEFTMARGIN		8
#define RIGHTMARGIN		8
#define TOPMARGIN		2
#define BOTTOMMARGIN	4
#define BUTTONWIDTH		14
#define BUTTONHEIGHT	14

	CDialog::OnSize(nType, cx, cy);

    CRect rc;
    GetClientRect(&rc);

	// resize treeview
	CWnd *tree = GetDlgItem(IDC_SYMTREE);
	if (tree && ::IsWindow(tree->m_hWnd)) {
		tree->MoveWindow(rc.left+LEFTMARGIN, rc.top+2*TOPMARGIN+BUTTONHEIGHT, rc.right-LEFTMARGIN-RIGHTMARGIN, rc.bottom-BUTTONHEIGHT-TOPMARGIN-BOTTOMMARGIN, TRUE);
		tree->RedrawWindow();
	} /* if */

	// move "Close" button
	CWnd *btn = GetDlgItem(IDCLOSE);
	if (btn && ::IsWindow(btn->m_hWnd))
		btn->MoveWindow(rc.right-(BUTTONWIDTH+1), rc.top+TOPMARGIN, BUTTONWIDTH, BUTTONHEIGHT, TRUE);

	// cause MDI client window to be resized
	static int recurs = 0;
	ASSERT(recurs >= 0);
	if (recurs == 0) {
		recurs++;
		((CMainFrame*)theApp.m_pMainWnd)->SetRightPane(this->m_hWnd);
		recurs--;
	} /* if */
}

void CSymBrowseDialog::OnShowWindow(BOOL bShow, UINT nStatus)
{
	static int recurse = 0;

	recurse++;
	CDialog::OnShowWindow(bShow, nStatus);
	if (recurse==1)
		((CMainFrame*)theApp.m_pMainWnd)->SetRightPane(bShow ? this->m_hWnd : 0);
	recurse--;
}

void CSymBrowseDialog::OnClose()
{
	((CMainFrame*)theApp.m_pMainWnd)->SetRightPane(0);
	CDialog::OnClose();
}

void CSymBrowseDialog::OnExplicitClose()
{
	OnClose();	/* EndDialog() does not call this one automatically */
	EndDialog(1);
}

LRESULT CSymBrowseDialog::OnNcHitTest(CPoint point)
{
	UINT hit = CDialog::OnNcHitTest(point);

	if (hit == HTTOPLEFT || hit == HTBOTTOMLEFT)
		hit = HTLEFT;
	else if (hit != HTLEFT && hit != HTSYSMENU && hit != HTCLOSE)
		hit = HTBORDER;
	return hit;
}

HTREEITEM CSymBrowseDialog::AddSection(const CString &name)
{	
	CTreeCtrl *tree = (CTreeCtrl*)GetDlgItem(IDC_SYMTREE);
	ASSERT(tree != NULL);

	HTREEITEM item;
	item = tree->GetNextItem(TVI_ROOT, TVGN_ROOT);
	while (item) {
		CString str = tree->GetItemText(item);
		if (str.CompareNoCase(name) == 0)
			break;	// matching name found, nothing to do
		item = tree->GetNextItem(item, TVGN_NEXT);
	} /* while */
	if (!item) {
		item = tree->InsertItem(name);
		tree->SetItemData(item, 0);
	} /* if */
	return item;
}

void CSymBrowseDialog::RebuildTree(const CSymbolEntry *root)
{
	if (!::IsWindow(m_hWnd))
		return;

	CTreeCtrl *tree = (CTreeCtrl*)GetDlgItem(IDC_SYMTREE);
	ASSERT(tree != NULL);

	/* save which leaf/leaves is open */
	CString openbranch;
	HTREEITEM section;
	section = tree->GetNextItem(TVI_ROOT, TVGN_ROOT);
	while (section) {
		UINT state = tree->GetItemState(section, TVIS_EXPANDED);
		if (state)
			openbranch = tree->GetItemText(section);
		section = tree->GetNextItem(section, TVGN_NEXT);
	} /* while */

	/* clear entire tree, then repopulate */
	tree->DeleteAllItems();

	CSymbolEntry *item;
	item = root->Next;
	while (item) {
		char type = 0;
		if (item->SymbolName[1] == ':')
			type = item->SymbolName[0];

		HTREEITEM parent = AddSection(_T("All symbols"));
		HTREEITEM leaf = tree->InsertItem(item->Syntax, parent);
		tree->SetItemData(leaf, (DWORD)item);

		switch (type) {
		case 'T':
			parent = AddSection(_T("Enumerations"));
			leaf = tree->InsertItem(item->Syntax, parent);
			tree->SetItemData(leaf, (DWORD)item);
			break;
		case 'C':
			parent = AddSection(_T("Constants"));
			leaf = tree->InsertItem(item->Syntax, parent);
			tree->SetItemData(leaf, (DWORD)item);
			break;
		case 'V':
			parent = AddSection(_T("Global variables"));
			leaf = tree->InsertItem(item->Syntax, parent);
			tree->SetItemData(leaf, (DWORD)item);
			break;
		case 'M':
			parent = AddSection(_T("Functions"));
			leaf = tree->InsertItem(item->Syntax, parent);
			tree->SetItemData(leaf, (DWORD)item);
			break;
		} /* switch */

		item = item->Next;
	} /* while */

	/* open branch that was open at the start of this routine */
	if (openbranch.GetLength() > 0) {
		section = tree->GetNextItem(TVI_ROOT, TVGN_ROOT);
		while (section) {
			CString str = tree->GetItemText(section);
			if (str.CompareNoCase(openbranch) == 0)
				tree->SetItemState(section, TVIS_EXPANDED, TVIS_EXPANDED);
			section = tree->GetNextItem(section, TVGN_NEXT);
		} /* while */
	} /* if */
}

void CSymBrowseDialog::Clear()
{
	SymbolList.Remove();
	if (IsWindow(m_hWnd))
		RebuildTree(&SymbolList);
}

bool CSymBrowseDialog::LoadReportFile(const CString& file, bool RefreshTree)
{
	SymbolList.Remove(file);

	TiXmlDocument doc(file);
	if (!doc.LoadFile())
		return false;
	TiXmlHandle docHandle(&doc);
	TiXmlElement *child = docHandle.FirstChild("doc").FirstChild("members").FirstChild("member").Element();
	if (!child)
		return false;
	while (child) {
		TiXmlElement *summary = child->FirstChildElement(_T("summary"));
		TiXmlElement *location = child->FirstChildElement(_T("location"));
		if (location) {
			CString symname = child->Attribute(_T("name"));		// for type and sorting
			CString syntax = child->Attribute(_T("syntax"));	// for display
			CString source = location->Attribute(_T("file"));
			int line = (int)strtol(location->Attribute(_T("line")), NULL, 10);
			/* make a full path, if needed */
			if (source[0] != _T('\\') && (source.GetLength() > 1 && source[1] != _T(':'))) {
				CString TgtPath = theApp.GetFilePath(file);
				source = TgtPath + _T("\\") + source;
			} /* if */
			SymbolList.Add(file, symname, syntax, 
						   summary ? summary->GetText() : "", 
						   source, line);
		} /* if */
		child = child->NextSiblingElement();
	} /* while */

	if (RefreshTree)
		RebuildTree(&SymbolList);

	return true;
}

int CSymBrowseDialog::LoadAllReportFiles(const CString& path)
{
	int count = 0;
	CFileFind ff;
	BOOL bWorking = ff.FindFile(path + _T("\\*.xml"));
	while (bWorking) {
		bWorking = ff.FindNextFile();
		CString name = path + _T("\\") + ff.GetFileName();
		if (LoadReportFile(name, false))
			count++;
	} /* while */
	RebuildTree(&SymbolList);
	return count;
}

int CSymBrowseDialog::LoadAllReportFiles()
{
	/* get path */
	CString TgtPath = theApp.GetTargetPath();
	if (TgtPath.IsEmpty()) {
		if (theApp.IsProjectActive()) {
			TgtPath = theApp.ProjectPath();
		} else if (theApp.GetMDIChild()) {
			CView* pActiveView = theApp.GetMDIChild()->GetActiveView();
			ASSERT(pActiveView != 0);
			CDocument* pDoc = pActiveView->GetDocument();
			ASSERT(pDoc != 0);
			TgtPath = pDoc->GetPathName();
		} /* if */
		if (!TgtPath.IsEmpty()) {
			TgtPath = theApp.GetFilePath(TgtPath);
		} else {
			char path[MAX_PATH];
			_getcwd(path, MAX_PATH);
			TgtPath = path;
		} /* if */
	} /* if */
	return LoadAllReportFiles(TgtPath);
}

/* Lookup()
 * Looks up a symbol in the "browse" information.
 * "nextmatch" should be -1 to find an exact match. If "nextmatch" is positive,
 * it will perform a partial match (any string matching parameter "symbol" in
 * the length of "symbol" is matched), but the first "nextmatch" number of matches
 * will be skipped. So, if "nextmatch" is zero, the first partial match is 
 * returned; if "nextmatch" is 1, the second partial match is returned.
 */
int CSymBrowseDialog::Lookup(const CString &symbol, CString *filename, int *line,
							 CString *syntax, CString *summary, int nextmatch)
{
	CSymbolEntry *item = &SymbolList;
	while (item) {
		CString symname = item->SymbolName.Mid(2);
		bool match;
		if (nextmatch >= 0)
			symname = symname.Left(symbol.GetLength());
		if (symname.Compare(symbol) == 0) {
			if (--nextmatch < 0) {
				if (filename)
					*filename = item->Source;
				if (line)
					*line = item->Line;
				if (syntax)
					*syntax = item->Syntax;
				if (summary)
					*summary = item->Summary;
				return 1;
			} /* if */
		} /* if */
		item = item->Next;
	} /* while */
	return 0;
}

bool CSymbolEntry::Add(const CString &xmlfile, const CString &symname, 
					   const CString &syntax, const CString &summary, 
					   const CString &source, int line)
{
	CSymbolEntry *item;

	/* first see whether the item exists already (same name, same source file, 
	 * same syntax); if so, only update the line number
	 */
	for (item = this; item; item = item->Next) {
		if (item->Source.CompareNoCase(source) == 0
			&& item->SymbolName.Compare(symname) == 0 
			&& item->Syntax.Compare(syntax) == 0)
		{
			item->Line = line;
			return true;
		} /* if */
	} /* for */

	/* special case, ignore anonymous types */
	if (symname.CompareNoCase("t:anonymous") == 0)
		return false;
	/* also ignore any prefefind constant, these do not have a location */
	if (source.GetLength() == 0)
		return false;

	/* item does not exist, create & insert */
	item = new CSymbolEntry;
	if (!item)
		return false;

	item->XMLfile = xmlfile;
	item->SymbolName = symname;
	if (syntax.GetLength() == 0)
		item->Syntax = symname.Mid(2);
	else
		item->Syntax = syntax;
	item->Summary = summary;
	item->Source = source;
	item->Line = line;

	CSymbolEntry *root = this;
	while (root->Next && root->Next->SymbolName.Compare(item->SymbolName)<0)
		root = root->Next;
	item->Next = root->Next;
	root->Next = item;

	return true;
}

void CSymbolEntry::Remove(const CString &xmlfile)
{
	CSymbolEntry *item, *next;
	item = this;
	while (item->Next) {
		next = item->Next;
		if (xmlfile.IsEmpty() || next->XMLfile.CompareNoCase(xmlfile) == 0) {
			item->Next = next->Next;
			delete next;
		} else {
			item = next;
		} /* if */
	} /* while */
}

