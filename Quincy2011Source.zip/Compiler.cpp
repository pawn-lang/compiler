// ----- compiler.cpp
// $Id: Compiler.cpp 4258 2010-06-17 10:21:31Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "compiler.h"
#include "ErrorLogDialog.h"
#include "MainFrm.h"

Compiler* Compiler::pCompiler;

Compiler::Compiler()
{
	m_bFoundDef = false;
	m_bErrorCreated = false;
	m_bStopping = false;
	m_CompileAction = none;
	m_pdlgErrors = new CErrorLogDialog;
	m_pConsoleApp = 0;
	pCompiler = this;
}

Compiler::~Compiler()
{
	delete m_pdlgErrors;
	delete m_pConsoleApp;
	pCompiler = 0;
}

void Compiler::ClearArrays()
{
	m_SourceFiles.RemoveAll();
}

void Compiler::AddSourceFile(const CString& rstrSrc)
{
	m_SourceFiles.Add(rstrSrc);
}

void Compiler::BuildTarget(const CString& strTargetName, CompileAction action)
{
	m_bStopping = false;
	m_CompileAction = action;
	m_strTargetName = strTargetName;

	m_strObjFiles.Empty();
	m_strLibFiles.Empty();
	ExitCode = 0;
	CompileAllSources();
	if (ExitCode == 0 && (action == transfer || theApp.DoAutoTransfer()))
		TransferTarget();
	if (cmds.size() > 0)
		RunCompilerProgram(cmds.front().command);
}

void Compiler::CompileAllSources()
{
	m_bFoundDef = false;

	int nSize = m_SourceFiles.GetSize();
	// --- gather all source file names in a string
	CString strFiles = "";
	for (int n = 0; n < nSize; n++)	{
		if (m_SourceFiles[n].IsEmpty())
			break;
		if (strFiles.GetLength() > 0)
			strFiles += "&";
		strFiles += m_SourceFiles[n];
	}
	CompileOneSource(strFiles);
}

void Compiler::CompileOneSource(const CString& strFile)
{
	CString strCmd;

	// ---- make a copy of the first filename without the path
	CString strFirst;
	if (strFile.Find('&', 0) > 0)
		strFirst = strFile.Left(strFile.Find('&', 0));
	else
		strFirst = strFile;
	m_strFilename = theApp.GetFileName(strFirst);

	m_strOPath = theApp.GetTargetPath();
	int ndx = m_strTargetName.ReverseFind('\\');
	if (m_strOPath.IsEmpty()) {
		// ---- make a copy of the target file path without the filename
		if (ndx != -1) {
			m_strOPath = m_strTargetName.Left(ndx);
		} else {
			char path[MAX_PATH];
			_getcwd(path, MAX_PATH);
			m_strOPath = path;
		} /* if */
	} else {
		// ---- make a copy of the target filename without path
		m_strTargetName = m_strTargetName.Mid(ndx + 1);
	} /* if */
	if (m_strOPath.GetAt(m_strOPath.GetLength() - 1) == '\\')
		m_strOPath = m_strOPath.Left(m_strOPath.GetLength() - 1);

	if (m_strTargetName.IsEmpty())
		m_strTargetName = theApp.FixedExecName();

	// if the object file spec has no path info, add it
	if (!m_strTargetName.IsEmpty() && m_strTargetName.Find("\\") == -1)
		m_strTargetName = m_strOPath + "\\" + m_strTargetName;

	//remove(m_strOFile);
	if (BuildCompilerCommand(strCmd, strFile))
		ScheduleProgram(strCmd);
}

void Compiler::TransferTarget(const CString& strTargetName, BOOL transferonly)
{
	ExitCode = 0;
	if (!strTargetName.IsEmpty())
		m_strTargetName = strTargetName;
	CString strCmd;
	BuildTransferCommand(strCmd, transferonly);
	ScheduleProgram(strCmd);
	ASSERT(m_pdlgErrors != 0);
	if (m_bErrorCreated != true)	{
		m_pdlgErrors->Create(IDD_ERRORLOG);
		m_bErrorCreated = true;
		m_pdlgErrors->SuspendLogMonitor();
		m_pdlgErrors->ShowWindow(SW_SHOW);
		((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(m_pdlgErrors->m_hWnd);
	}
	m_pdlgErrors->SetWindowText(_T("Transfer"));
}

// --- schedules the execution of a compiler program (gcc, typically)
//     the programs are run in the order they are scheduled from the OnIdle function
//     if (depends) the scheduled program will not run if any prior program did not
//     complete successfully, and it will remove all subsequent programs from the
//     schedule.
void Compiler::ScheduleProgram(CString& strCmd, bool depends)
{
	ConsoleCmd cmd;
	cmd.command = strCmd;
	cmd.dependent = depends;
	cmds.push(cmd);
}


void Compiler::RunCompilerProgram(const CString& strCmd)
{
	CString tmpCmd = (strCmd.IsEmpty()) ? cmds.front().command : strCmd;

	if (theApp.ShowCmdLineInLog())
		AddLogEntry(tmpCmd);// creates the error log automatically
	else
		CreateErrorLog();	// error log dialog must be created by the main thread
	int ndx;
	if (tmpCmd[0] == '"')
		ndx = tmpCmd.Find('"', 1) + 1;
	else
		ndx = tmpCmd.Find(' ');
	ASSERT(ndx != -1);
	CString strExe = tmpCmd.Left(ndx);
	CString strArgs = tmpCmd.Right(tmpCmd.GetLength() - ndx);
	delete m_pConsoleApp;
	m_pConsoleApp = new ConsoleApp(strExe, &Notify, &Collect);
	m_pConsoleApp->Run(strArgs);
}

void Compiler::ClearErrorLog(bool Force)
{
	if (theApp.ClearBuildMsgOnCommand() || Force) {
		if (m_bErrorCreated) {
			ASSERT(m_pdlgErrors != 0);
			m_pdlgErrors->ClearBuildView();
		} /* if */
		MessageLog.clear();
	} /* if */
	if ((theApp.ClearLogMsgOnCommand() || Force) && m_bErrorCreated) {
		ASSERT(m_pdlgErrors != 0);
		m_pdlgErrors->ClearLogView();
	} /* if */
}

void Compiler::CloseErrorLog()
{
	ClearErrorLog();
	if (m_bErrorCreated)	{
		ASSERT(m_pdlgErrors != 0);
		m_pdlgErrors->ShowWindow(SW_HIDE);
		((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(0);
	} /* if */
}

void Compiler::CreateErrorLog()
{
	ASSERT(m_pdlgErrors != 0);
	if (m_bErrorCreated != true) {
		m_pdlgErrors->Create(IDD_ERRORLOG);
		m_bErrorCreated = true;
		((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(m_pdlgErrors->m_hWnd);
	} /* if */
	if (!m_pdlgErrors->IsWindowVisible()) {
		m_pdlgErrors->SetWindowText(_T("Build"));	/* set default caption */
		m_pdlgErrors->ShowWindow(SW_SHOW);
		((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(m_pdlgErrors->m_hWnd);
	} /* if */
}

void Compiler::AddLogEntry(const CString& str)
{
	CreateErrorLog();
	ASSERT(m_pdlgErrors != 0);
	m_pdlgErrors->AddBuildMessage(str);
	MessageLog.push_back(str);
}

// --- called from the console application thread when compile program completes
void Compiler::Notify()
{
	ASSERT(pCompiler != 0);
	pCompiler->NotifyTermination();
}

void Compiler::NotifyTermination()
{
	ASSERT(m_pConsoleApp != 0);
	if (!m_bStopping && m_pConsoleApp->SuccessfulRun())	{
		ExitCode |= m_pConsoleApp->Exitcode();
		cmds.pop();	// pop off the command that just completed
		if (cmds.size() > 0 && (ExitCode == 0 || cmds.front().dependent == false))	{
			RunCompilerProgram(cmds.front().command);
			return;
		} /* if */
		if (cmds.size() == 0 && ExitCode == 0)	{
			AddLogEntry("Completed");
			((CMainFrame*)theApp.m_pMainWnd)->UpdateSymBrowser(m_strTargetName);
			if (m_CompileAction != none)	{
				if (m_CompileAction == showreport) {
					ShellExecute(0, "open", m_strTargetName.Left(m_strTargetName.GetLength() - 3) + "xml", 0, 0, SW_SHOW);
				} else if (m_CompileAction == step) {
					theApp.DebugProgram(m_strTargetName, true);
				} else if (m_CompileAction == debug) {
					theApp.DebugProgram(m_strTargetName, false);
				} else if (m_CompileAction == transfer) {
					/* after a transfer, switch to log */
					CErrorLogDialog *dlg = GetErrorLog();
					if (dlg) {
						dlg->SwitchTab(1);
						CTime time = CTime::GetCurrentTime();
						dlg->AddLogMessage(time.Format("Transfer completed - %H:%M:%S\n"));
					} /* if */
				} else {
					theApp.StartProgram(m_strTargetName);
				} /* if */
				m_CompileAction = none;
			} /* if */
		} else {
			CString strError;
			if (cmds.size() > 0)
				strError.Format("return code %d (queued=%d)", ExitCode, cmds.size());
			else
				strError.Format("return code %d", ExitCode, cmds.size());
			AddLogEntry("Failure; " + strError);
		} /* if */
	}
	m_bStopping = false;
	while (cmds.size() > 0)
		cmds.pop();
}

// --- called from the console application thread while compiling is going on
void Compiler::Collect(DWORD bufct)
{
	ASSERT(pCompiler != 0);
	pCompiler->CollectErrorMessages(bufct);
}

void Compiler::CollectErrorMessages(DWORD bufct)
{
	char *buf = new char[bufct+1];
	ASSERT(m_pConsoleApp != 0);
	if (m_pConsoleApp->ReadConsole(buf, bufct) != 0)
		AddLogEntry(buf);
	delete buf;
}

void Compiler::Stop()
{
	AddLogEntry("Stopped by user");
	m_bStopping = true;
	if (m_pConsoleApp != 0)
		m_pConsoleApp->Stop();
}

bool Compiler::CompileRunning() const
{
	return m_pConsoleApp != 0 && m_pConsoleApp->IsRunning();
}


////////////////////////////////////////////////////////////////////////
//
// Specific compiler specializations of the abstract base Compiler class
//
////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
//
//                PawnCompiler member functions
//
///////////////////////////////////////////////////////////////

void PawnCompiler::CompileAllSources()
{
	m_strPrevLine.Empty();
	Compiler::CompileAllSources();
}

void PawnCompiler::CompileOneSource(const CString& strFile)
{
	Compiler::CompileOneSource(strFile);
}

bool PawnCompiler::BuildCompilerCommand(CString& strCmd, const CString& strFile)
{
	strCmd = theApp.Enquote(theApp.ToolsPath() + "pawncc.exe");
	if (theApp.TargetHost().GetLength() > 0)
		strCmd += " -T" + theApp.TargetHost() + ".cfg";
	if (theApp.GenerateOverlays())
		strCmd += " -V";
	if (theApp.DebugInfoLevel() >= 0) {	// if not the default debug level
		CString tmp;
		tmp.Format(" -d%d", theApp.DebugInfoLevel());
		strCmd += tmp;
	} /* if */
	if (theApp.OptimizeLevel() >= 0) {		// if not the default optimization level
		CString tmp;
		tmp.Format(" -O%d", theApp.OptimizeLevel());
		strCmd += tmp;
	} /* if */
	if (theApp.VerboseCompile() && theApp.DebugInfoLevel() < 2)
		strCmd += " -v2";
	if (theApp.MakeReport())
		strCmd += " -r";
	if (theApp.Tabstops() != 8) {
		CString tmp;
		tmp.Format(" -t%d", theApp.Tabstops());
		strCmd += tmp;
	} /* if */

	int i;
	for (i = 0; i < theApp.GetIncludeArray().GetSize(); i++)	{
		strCmd += " -i";
		strCmd += theApp.Enquote(theApp.GetIncludeArray()[i]);
	}

	for (i = 0; i < theApp.GetDefinesArray().GetSize(); i++)	{
		CString opt = theApp.GetDefinesArray()[i];
		if (opt.Find('=') < 0)
			opt += "=";
		strCmd += " " + opt;
	}

	if (!m_strTargetName.IsEmpty())	{
		// see if the output file is accessible, if not
		for ( ;; ) {
			if (!theApp.IsReadOnlyPath(m_strTargetName))
				break;
			CString altpath;
			int reply, length;
			CString msg;
			CString caption = "Quincy: no access to output path";
			if (m_strTargetName[1] == ':') {
				int length = strFile.Find('&');
				if (length > 0)
					altpath = strFile.Left(length);
				else
					altpath = strFile;
				length = altpath.ReverseFind('\\');
				if (length > 0 && !theApp.IsReadOnlyPath(altpath))
					altpath = altpath.Left(length);
				else
					altpath = theApp.GetTemporaryDirectory();
				msg.Format("File \"%s\" cannot be written.\n\nPlease choose one of the following:\n"
						   "Abort\tthis build\n"
						   "Retry\tafter inserting a medium in drive %c:\n"
						   "Ignore\tthe default path and build into directory \"%s\"",
						   m_strTargetName, toupper(m_strTargetName[0]), altpath);
				reply = theApp.m_pMainWnd->MessageBox(msg, caption, MB_ABORTRETRYIGNORE | MB_ICONEXCLAMATION);
			} else {
				msg.Format("File \"%s\" cannot be written.", m_strTargetName);
				theApp.m_pMainWnd->MessageBox(msg, caption, MB_OK | MB_ICONHAND);
				reply = IDCANCEL;
			} /* if */
			switch (reply) {
			case IDCANCEL:
			case IDABORT:
				return false;
			case IDIGNORE:
				length = m_strTargetName.ReverseFind('\\');
				if (length > 0)
					m_strTargetName = m_strTargetName.Right(m_strTargetName.GetLength() - length);
				m_strTargetName = altpath + "\\" + m_strTargetName;
				// theApp.SetTargetPath(altpath);
				break;
			} /* switch */
		} /* for */
		strCmd += " -o";
		strCmd += theApp.Enquote(m_strTargetName);
	}

	if (!theApp.CmdLineOptions().IsEmpty()) {
		strCmd += " ";
		strCmd += theApp.CmdLineOptions();
	} /* if */

	int start = 0, length;
	do {
		strCmd += " ";
		length = strFile.Find('&', start);
		if (length > 0)
			strCmd += theApp.Enquote(strFile.Mid(start, length));
		else
			strCmd += theApp.Enquote(strFile.Mid(start));
		start += length + 1;
	} while (length > 0);

	return true;
}

void PawnCompiler::BuildTransferCommand(CString& strCmd, BOOL transferonly)
{
	if (theApp.GetDebugPort() == 0) {
		strCmd = "";
	} else {
		CString strPort;
		strPort.Format("%d,%d", theApp.GetDebugPort(), theApp.GetDebugBaudrate());
		strCmd = theApp.Enquote(theApp.ToolsPath() + theApp.GetDebuggerName(DEBUG_REMOTE));
		strCmd += " " + theApp.Enquote(m_strTargetName) + " ";
		strCmd += "-rs232=" + strPort + " -transfer";
		if (transferonly)
			strCmd += " -quit";
	} /* if */
}

void PawnCompiler::BuildLinkerCommand(CString& strCmd)
{
	strCmd = theApp.Enquote(theApp.ToolsPath() + "pawncc.exe");

	strCmd += " -o ";
	strCmd += theApp.Enquote(m_strTargetName) + " ";
}

bool PawnCompiler::GetMessageData(int sel, CString& strFile, int& line)
{
	bool rtn = false;
	if (MessageLog.size() > sel)	{
		CString& msg = MessageLog[sel];
		const char* cp = msg.GetBuffer(0);
		for (int n = 0; n < msg.GetLength(); n++) {
			if (*(cp+n) == '(')	{
				if (isdigit(*(cp+n+1)) && *(cp+n-1) != ' ' && strchr(cp, ':') != NULL) {
					rtn = true;
					strFile = msg.Left(n);
					line = atoi(cp+n+1);
					break;
				} /* if */
			} /* if */
		} /* for */
	} /* if */
	return rtn;
}

