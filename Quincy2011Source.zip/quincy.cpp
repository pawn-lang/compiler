// Quincy.cpp : Defines the class behaviors for the application.
// $Id: quincy.cpp 4535 2011-07-07 09:15:22Z thiadmer $

#include "stdafx.h"
#include <shlobj.h>
#include <algorithm>
#include <process.h>
#include <ddeml.h>
#include <io.h>
#include "Quincy.h"
#include "AboutDlg.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "TextDocument.h"
#include "TextView.h"
#include "stabs.h"

#include "OptionsSheet.h"
#include "BuildDialog.h"
#include "EditorOptions.h"
#include "DebugOptions.h"
#include "SnippetsOptions.h"
#include "GeneralOptions.h"
#include "QuincyPrintDialog.h"
#include "snippets.h"

#include "CommandLineDialog.h"
#include "ErrorLogDialog.h"
#include "ExamineDialog.h"
#include "WatchDialog.h"
#include "debugger.h"
#include "TutDlg.h"
#include "compiler.h"
#include "grep.h"
#include "executor.h"

#include "MultiDocTemplateEx.h"
#include "ReaderWrapper.h"
#include "HelpIndex.h"
#include "DocFileSelect.h"
#include "FileVersionInfo.h"
#include "FontInstall.h"
#include "shellfolder.h"
#include "chkupdate.h"
#include "memmap.h"

#include "svnrev.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQuincyApp

BEGIN_MESSAGE_MAP(CQuincyApp, CWinApp)
	//{{AFX_MSG_MAP(CQuincyApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_STOPBUILD, OnStop)
	ON_UPDATE_COMMAND_UI(ID_STOPBUILD, OnUpdateStop)
	ON_COMMAND(ID_OPTIONS, OnOptions)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_CLEARBREAKPOINTS, OnUpdateDebugClearbreakpoints)
	ON_COMMAND(ID_DEBUG_CLEARBREAKPOINTS, OnDebugClearbreakpoints)
	ON_COMMAND(ID_DEBUG_STEPOVER, OnDebugStepover)
	ON_COMMAND(ID_DEBUG_WATCH, OnDebugWatch)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_STEPOVER, OnUpdateDebugStepover)
	ON_COMMAND(ID_HELP, OnHelp)
	ON_COMMAND(ID_GREP, OnGrep)
	ON_UPDATE_COMMAND_UI(ID_GREP, OnUpdateGrep)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_VIEW_GDBCONSOLE, OnViewGdbconsole)
	ON_COMMAND(ID_HELP1, OnHelp1)
	ON_COMMAND(ID_HELP2, OnHelp2)
	ON_COMMAND(ID_HELP3, OnHelp3)
	ON_COMMAND(ID_HELP4, OnHelp4)
	ON_COMMAND(ID_HELP5, OnHelp5)
	ON_COMMAND(ID_HELP6, OnHelp6)
	ON_COMMAND(ID_HELP7, OnHelp7)
	ON_COMMAND(ID_HELP8, OnHelp8)
	ON_COMMAND(ID_HELP9, OnHelp9)
	ON_COMMAND(ID_HELP10, OnHelp10)
	ON_COMMAND(ID_HELP11, OnHelp11)
	ON_COMMAND(ID_HELP12, OnHelp12)
	ON_COMMAND(ID_HELP13, OnHelp13)
	ON_COMMAND(ID_HELP14, OnHelp14)
	ON_COMMAND(ID_HELP15, OnHelp15)
	ON_UPDATE_COMMAND_UI(ID_HELP, OnUpdateHelp)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_WATCH, OnUpdateDebugWatch)
	ON_COMMAND_EX_RANGE(ID_FILE_MRU_FILE1, ID_FILE_MRU_FILE16, OnOpenRecentFile)
	ON_COMMAND(ID_LOADWORKSPACE, OnLoadworkspace)
	ON_COMMAND(ID_SAVEWORKSPACE, OnSaveworkspace)
	ON_UPDATE_COMMAND_UI(ID_CLOSEWORKSPACE, OnUpdateCloseworkspace)
	ON_COMMAND(ID_CLOSEWORKSPACE, OnCloseworkspace)
	ON_COMMAND(ID_LOGVIEW, OnLogView)
	ON_UPDATE_COMMAND_UI(ID_LOGVIEW, OnUpdateLogView)
	ON_UPDATE_COMMAND_UI(ID_SYMBOLBROWSER, OnUpdateSymbolBrowser)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_PRINT_SETUP, OnFilePrintSetup)
	// for double-clicking on a file in Explorer when Quicy is already open
	ON_COMMAND(ID_SHELLOPEN, OnShellFileOpen)
#ifdef TYCPP
	// Tutorial commands
	ON_COMMAND(ID_WRITETUTORIAL, OnWritetutorial)
	ON_COMMAND(ID_TYCPP, OnTycpp)
	ON_UPDATE_COMMAND_UI(ID_TYCPP, OnUpdateTycpp)
#endif
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQuincyApp construction

CQuincyApp::CQuincyApp(LPCTSTR lpszAppName) : CWinApp(lpszAppName)
{
	m_pEditorView = 0;
	m_pCompiler = 0;
	m_pGrep = 0;
	m_pExecutor = 0;
	m_bPrintLineNos = false;
	m_bCpp = false;
	m_bDoLink = false;
	m_pView = 0;
	m_nDebugLevel = 1;
	m_Verbose = false;
	m_Report = false;
	m_FixedName = BST_CHECKED;
	m_maxundos = 1024;
	m_style = 0;
	m_nOptimize = 1;
	m_bOverlays = false;
	m_nExitCode = 0;
	m_pdlgWatch = new CWatchDialog;
	m_pdlgExamine = new CExamineDialog;
	m_pdlgGdbConsole = new GdbConsole;
	m_mmf = new CMemMapFile;
	m_bBypassChangeTest = false;
	m_CommandLinePromptOption = 0;
	m_pDebugger = 0;
	m_ConsoleRect.SetRectEmpty();
	stepping = false;
#ifdef TYCPP
	m_bReadTutorial = false;
	m_bTutorialDisplayed = false;
	m_bIsTutorial = false;
	m_pCTutDlg = 0;
	m_bTutCreated = false;
#endif
	m_bGrepIsInstalled = false;
	m_bUncrustifyIsInstalled = false;
	m_bCompilerIsInstalled = false;
	m_bWatchCreated = false;
	m_bGdbConsoleCreated = false;

	m_bSyntaxColors   = false;
	m_bShowTabSpaces  = false;
	m_bRepeatBullet   = false;
	m_backgroundcolor = RGB(255,255,255);	// see also the default colours in EditorOptions.cpp
	m_normalcolor     = RGB(0,0,0);
	m_keywordcolor    = RGB(0,0,255);
	m_commentcolor    = RGB(128,128,0);
	m_operatorcolor   = RGB(0,128,0);
	m_stringcolor     = RGB(128,0,0);
	m_numbercolor     = RGB(255,0,128);
	m_activerowcolor  = RGB(255,255,240);
	m_fontheight      = 16;
	m_fontweight      = FW_NORMAL;
	m_fontface        = "Andante";

	m_PdfReader = NULL;
	m_HelpIndex = NULL;
}

CQuincyApp::~CQuincyApp()
{
	delete m_pdlgWatch;
	delete m_pdlgExamine;
	delete m_pDebugger;
	delete m_pdlgGdbConsole;
#ifdef TYCPP
	delete m_pCTutDlg;
#endif
	delete m_pCompiler;
	delete m_pGrep;
	delete m_pExecutor;
	delete m_mmf;

	if (m_HelpIndex)
		delete m_HelpIndex;
	if (m_PdfReader) {
		m_PdfReader->DocClose();
		delete m_PdfReader;
	} /* if */
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CQuincyApp object

CQuincyApp theApp("Quincy for Pawn");

/////////////////////////////////////////////////////////////////////////////
// CQuincyApp initialization

// Add a static BOOL that indicates whether the class was
// registered so that we can unregister it in ExitInstance
static BOOL bClassRegistered = FALSE;

BOOL CQuincyApp::InitInstance()
{
	// Create the object for interprocess communication (since we
	// are a single-instance application)
	if (!m_mmf->MapExistingMemory(_T("Quincy"), (MAX_PATH+1)*sizeof(TCHAR))
		&& !m_mmf->MapMemory(_T("MMFTEST"), (MAX_PATH+1)*sizeof(TCHAR)))
		MessageBox(NULL,_T("Failed to map shared memory"),NULL,MB_OK);

	// If a previous instance of the application is already running,
	// then activate it and return FALSE from InitInstance to
	// end the execution of this instance.
	if(!FirstInstance())
		return FALSE;

	// Register our unique class name that we wish to use
	WNDCLASS wndcls;

	memset(&wndcls, 0, sizeof(WNDCLASS));   // start with NULL
										  // defaults

	wndcls.style = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
	wndcls.lpfnWndProc = ::DefWindowProc;
	wndcls.hInstance = AfxGetInstanceHandle();
	wndcls.hIcon = LoadIcon(IDR_MAINFRAME); // or load a different
										  // icon
	wndcls.hCursor = LoadCursor( IDC_ARROW );
	wndcls.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
	wndcls.lpszMenuName = NULL;

	// Specify our own class name for using FindWindow later
	wndcls.lpszClassName = _T("QuincyAppClass");

	// Register new class and exit if it fails
	if(!AfxRegisterClass(&wndcls))
	{
		TRACE("Class Registration Failed\n");
		return FALSE;
	}
	bClassRegistered = TRUE;


	// Check the installation of Andante, a good monospaced editor font
	// (we do not care much when these fonts cannot be installed)
	CheckFontInstall("Andante","andante.fon");

	// Use INI files, old-fashioned, but solid and convenient. But use
	// local INI files, to avoid conflicts with multiple installations.
	TCHAR szBuff[_MAX_PATH];
	MkProfileName(szBuff, _T("quincy.ini"), _T("Pawn"), m_hInstance);
	BOOL bEnable = AfxEnableMemoryTracking(FALSE);
	m_pszProfileName = _tcsdup(szBuff);
	AfxEnableMemoryTracking(bEnable);

	osversion.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	GetVersionEx((OSVERSIONINFO*)&osversion);

	// --- need some paths for looking for compilers, tutorials, tools
	VERIFY(::GetModuleFileName(m_hInstance, szBuff, _MAX_PATH));
	m_strQuincyBinPath = szBuff;
	int nIndex = m_strQuincyBinPath.ReverseFind('\\');
	ASSERT(nIndex > 0);
	m_strQuincyBinPath = m_strQuincyBinPath.Left(nIndex);

	/* Deprecated in .NET 2003 */
#if 1
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif
#endif
	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// ---- erase a few sections if this is a new install (to avoid MFC crashes!)
	if (GetProfileInt("Quincy", "Build", 0) != SVN_REV) {
		WriteProfileString("Settings-Summary", NULL, NULL);
		WriteProfileString("Settings", NULL, NULL);
		WriteProfileString("Settings-Bar0", NULL, NULL);
		WriteProfileString("Settings-Bar1", NULL, NULL);
		WriteProfileString("Settings-Bar2", NULL, NULL);
		WriteProfileString("ErrorLog", NULL, NULL);
		WriteProfileString("TutorialDialog", NULL, NULL);
		WriteProfileString("GdbWindow", NULL, NULL);
		WriteProfileString("WatchWindow", NULL, NULL);
		WriteProfileInt("Quincy", "Build", SVN_REV);
	} /* if */

	// ---- load Quincy's INI options
	m_bAutoindent     = GetProfileInt("Editor", "AutoIndent", 1);
	m_taboption       = GetProfileInt("Editor", "HardTabs", 0);
	m_bSyntaxColors   = GetProfileInt("Editor", "SyntaxHighlight", 1);
	m_bShowTabSpaces  = GetProfileInt("Editor", "VisibleWhitespace", 0);
	m_tabstops        = GetProfileInt("Editor", "TabWidth", 4);
	m_maxundos        = GetProfileInt("Editor", "Max.Undos", 1024);
	m_bRepeatBullet   = GetProfileInt("Editor", "RepeatBullet", 1);

	m_fontheight	  = GetProfileInt("Editor",    "FontHeight", 16);
	m_fontweight	  = GetProfileInt("Editor",    "FontWeight", FW_NORMAL);
	m_fontface		  = GetProfileString("Editor", "FontFace", "Andante");

	m_backgroundcolor = GetProfileInt("Editor", "BackgroundColor",  RGB(255,255,255));
	m_normalcolor     = GetProfileInt("Editor", "NormalColor",      RGB(0,0,0));
	m_keywordcolor    = GetProfileInt("Editor", "KeywordColor",     RGB(0,0,255));
	m_operatorcolor   = GetProfileInt("Editor", "OperatorColor",    RGB(0,128,0));
	m_commentcolor    = GetProfileInt("Editor", "CommentColor",     RGB(128,128,0));
	m_stringcolor     = GetProfileInt("Editor", "StringColor",      RGB(128,0,0));
	m_numbercolor     = GetProfileInt("Editor", "NumberColor",      RGB(255,0,128));
	m_activerowcolor  = GetProfileInt("Editor", "ActiveRowColor",   RGB(255,255,240));

	m_strCompiler     = GetProfileString("Directories", "Compiler");
	m_strRuntimeDirectory = GetProfileString("Directories", "Runtime");

	m_style           = GetProfileInt("Options", "Style", 0);
	m_command		  = GetProfileString("Options", "Command");

	m_bPrintLineNos   = GetProfileInt("Options", "PrintLineNumbers", 0) != 0;
	m_CheckForUpdates = GetProfileInt("Options", "CheckForUpdates", 1);
	m_ShowCmdLine = GetProfileInt("Options", "ShowCmdLine", 0);
	m_ClearBuildMsg = GetProfileInt("Options", "ClearBuildMsg", 1);
	m_ClearLogMsg = GetProfileInt("Options", "ClearLogMsg", 1);

#ifdef TYCPP
	m_bTutorialDisplayed = GetProfileInt("Tutorial", "Displayed", 1);
#endif

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CMultiDocTemplateEx* pDocTemplate;

	pDocTemplate = new CMultiDocTemplateEx(
		IDR_PAWNTEMPLATE,
		RUNTIME_CLASS(CTextDocument),	// document class
		RUNTIME_CLASS(CChildFrame),		// frame class
		RUNTIME_CLASS(CTextView));		// view class
	AddDocTemplate(pDocTemplate);

	pDocTemplate = new CMultiDocTemplateEx(
		IDR_INCTEMPLATE,
		RUNTIME_CLASS(CTextDocument),	// document class
		RUNTIME_CLASS(CChildFrame),		// frame class
		RUNTIME_CLASS(CTextView));		// view class
	AddDocTemplate(pDocTemplate);

	pDocTemplate = new CMultiDocTemplateEx(
		IDR_EDITORTYPE,
		RUNTIME_CLASS(CTextDocument),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CTextView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	m_pMainWnd = pMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return false;

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	SetCompilerPaths();

	m_ProjectFile = GetProfileString("Options", "Project");
	LoadProjectSettings();
	LoadHostConfiguration();
	InfoTip_ReadList();
	RebuildHelpMenu();

	CString strBuffer = GetProfileString("Settings", "Console Position");
	if (!strBuffer.IsEmpty())
		_stscanf (strBuffer, "%i:%i:%i:%i",
			&m_ConsoleRect.left,
			&m_ConsoleRect.top,
			&m_ConsoleRect.right,
			&m_ConsoleRect.bottom);

	CWnd* pFocusWnd = 0;

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes();

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// ------- find path to TEMP disk space if any
	char* tempenv;
	if ((tempenv = getenv("TEMP")) != 0)	{
		m_strTempPath = tempenv;
		if (m_strTempPath.GetLength() && m_strTempPath[m_strTempPath.GetLength()-1] != '\\')
			m_strTempPath += "\\";
	}

#ifdef TYCPP
	LoadTutorials();

	bool bCmdFile = false;

	// --- suppress initial FileNew command on startup
	if (cmdInfo.m_nShellCommand != CCommandLineInfo::FileNew)	{
		if (cmdInfo.m_strFileName != "tutorial")
		{
			m_ProjectFile.Empty();	/* clear current project, if openening a file from the command line */
			WriteProfileString("Options", "Project", NULL);

			if (IsTutorial(cmdInfo.m_strFileName))
			{
				// --- reading a .tut file
				m_bReadTutorial = true;
				int nIndex = cmdInfo.m_strFileName.ReverseFind('\\');
				if (nIndex == -1)	{
					char path[MAX_PATH];
					getcwd(path, MAX_PATH);
					m_strTutorial = path;
					m_strTutorial += "\\";
				}
				m_strTutorial += cmdInfo.m_strFileName;
			}
			else if (IsWorkplaceFile(cmdInfo.m_strFileName))
				SwitchWorkspace(cmdInfo.m_strFileName);
			else if (!ProcessShellCommand(cmdInfo))
				return false;
			else
			{
				// ---- loading file from command line
				bCmdFile = true;
				CString strPath = GetFilePath(cmdInfo.m_strFileName);
				if (!strPath.IsEmpty())
					_chdir(strPath);
			}
		}
	}

	else if (!m_bIsTutorial || !m_bTutorialDisplayed)	{
		// ----- reload documents from the previous session
		pFocusWnd = RestoreOpenDocuments();
	} /* if */

	if (!bCmdFile)	{
		// ---- reload tutorial info from the previous session
		m_strTutorial = GetProfileString("Tutorial", "Current", 0);
		// ---- reload working directory from the previous session
		CString strPath = GetProfileString("Directories", "Current", 0);
		// ------ change to current working directory
		if (!strPath.IsEmpty())
			_chdir(strPath);
	}
#else
	bool bCmdFile = false;

	// --- suppress initial FileNew command on startup
	if (cmdInfo.m_nShellCommand != CCommandLineInfo::FileNew)	{
		m_ProjectFile.Empty();	/* clear current project, if openening a file from the command line */
		WriteProfileString("Options", "Project", NULL);

		if (IsWorkplaceFile(cmdInfo.m_strFileName))
			SwitchWorkspace(cmdInfo.m_strFileName);
		else if (!ProcessShellCommand(cmdInfo))
			return false;
		// ---- loading file from command line
		bCmdFile = true;
		CString strPath = GetFilePath(cmdInfo.m_strFileName);
		if (!strPath.IsEmpty())
			_chdir(strPath);
	}
	else	{
		// ----- reload documents from the previous session
		pFocusWnd = RestoreOpenDocuments();
	} /* if */

	if (!bCmdFile)	{
		// ---- reload working directory from the previous session
		CString strPath = GetProfileString("Directories", "Current", 0);
		// ------ change to current working directory
		if (!strPath.IsEmpty())
			_chdir(strPath);
	}

#endif

	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	if (pFocusWnd != 0) {
		ASSERT_KINDOF(CMDIChildWnd, pFocusWnd);
		pMainFrame->MDIActivate(pFocusWnd);
		pFocusWnd->SetFocus();
	} /* if */

	/* always create the symbol browser, because it is implicitly used in the
	 * "go to declaration" menu item
	 */
	int SymBrowserEnabled = GetProfileInt("Options", "SymbolBrowser", 0);
	if (SymBrowserEnabled)
		((CMainFrame*)m_pMainWnd)->CreateSymBrowser();
	((CMainFrame*)m_pMainWnd)->UpdateSymBrowser();

	ErrorTip_ReadList();

#ifdef TYCPP
	if (!bCmdFile && m_bIsTutorial && pFocusWnd == 0 && m_bTutorialDisplayed)	{
		OnTycpp();
		ASSERT(m_pCTutDlg != 0);
		m_pCTutDlg->LoadSelectedTutorial();
	}
	// --- disable tycpp command if tutorial not present
	if (!m_bIsTutorial)
		pMainFrame->HideTYCPPCommand();
#endif

	// --- check for updates
	if (m_CheckForUpdates)
		CheckUpdate(theApp.GetCompilerVersion(), CHK_BUILD, "Pawn", "PadURL", "LastVersionCheck", theApp.m_pszProfileName);

	return true;
}

void CQuincyApp::SetCompilerPaths()
{
	if (m_pCompiler)
		delete m_pCompiler;
	m_pCompiler = 0;

	// ---- set paths to find the compiler executables
	int nIndex = m_strQuincyBinPath.ReverseFind('\\');
	CString strQuincyInstallPath;
	if (nIndex > 0)
		strQuincyInstallPath = m_strQuincyBinPath.Left(nIndex);
	else
		strQuincyInstallPath = m_strQuincyBinPath;

	// poor man's constructor

	m_bCompilerIsInstalled = false;

	m_strInstallPath.Empty();
	m_strToolsPath.Empty();
	m_strIncludePath.Empty();
	m_strVersion.Empty();

	for (;;)	{

		// loops in case Quincy expects compiler on cd-rom and cd is not in drive
		// only comes back here if programmed compiler path cd and can't find compiler
		// and user does not Cancel the retry

		// looking for the Pawn compiler
		//
		// start from the programmed compiler location
		CString strCompiler = m_strCompiler;
		if (strCompiler.IsEmpty())
			// no programmed location, look for Pawn in the Quincy install directory
			strCompiler = strQuincyInstallPath;
		if ((nIndex = strCompiler.GetLength()) > 0 && strCompiler[nIndex - 1] != '\\')
			strCompiler += "\\";

		// --- scanning for the Pawn compiler
		// --- make sure that at least pawncc is in the directory
		CString strPawncc = strCompiler + "bin\\pawncc.exe";
		m_bCompilerIsInstalled = _access(strPawncc, 0) == 0;
		if (!m_bCompilerIsInstalled) {
			// strip off a trailing "bin\\" part
			if ((nIndex = strCompiler.GetLength()) > 4) {
				CString strSuffix = strCompiler.Right(4);
				if (strSuffix.CompareNoCase("bin\\" ) == 0) {
					strCompiler = strCompiler.Left(nIndex - 4);
					CString strPawncc = strCompiler + "bin\\pawncc.exe";
					m_bCompilerIsInstalled = _access(strPawncc, 0) == 0;
				} /* if */
			} /* if */
		} /* if */

		m_strToolsPath = strCompiler + "bin\\";
		m_strIncludePath = strCompiler + "include\\";
		m_strInstallPath = strCompiler;

		if (m_bCompilerIsInstalled)	{
			m_strCompiler = strCompiler;	// update the programmed compiler path
			m_pCompiler = new PawnCompiler();

			// --- get version from the "version resource" in the compiler
			CFileVersionInfo  fvi;
			if (fvi.Create(strPawncc))
				m_strVersion.Format("%d.%d.%d", fvi.GetProductVersion(3), fvi.GetProductVersion(2), fvi.GetProductVersion(1) /*, fvi.GetProductVersion(0)*/);
		}

		// --- also check the availability of the run-time
		CString strPawnRun = m_strToolsPath + "pawnrun.exe";
		m_bRunTimeIsInstalled = _access(strPawnRun, 0) == 0;
		m_bRunTimeEnabled = m_bRunTimeIsInstalled;	// by default, what is installed is enabled

		// --- set the debuggers for local and remote debugging to either the
		//     standard or the "dual terminal" version
		m_iDebuggerIsInstalled = 0;
		if (_access(m_strToolsPath + "pawndbgc.exe", 0) == 0)
			m_iDebuggerIsInstalled |= dbgDualTerminal;
		if (_access(m_strToolsPath + "pawndbg.exe", 0) == 0)
			m_iDebuggerIsInstalled |= dbgConsole;
		// for local debugging, prefer dual-terminal version
		if (m_iDebuggerIsInstalled & dbgDualTerminal) {
			m_strDebuggerLocal = "pawndbgc.exe";
			m_bDbgAutoHide = true;
			ASSERT(_access(m_strToolsPath + "pawndbgc.exe", 0) == 0);
		} else if (m_iDebuggerIsInstalled & dbgConsole) {
			m_strDebuggerLocal = "pawndbg.exe";
			m_bDbgAutoHide = false;
			ASSERT(_access(m_strToolsPath + "pawndbg.exe", 0) == 0);
		} else {
			m_strDebuggerLocal = "";
			ASSERT(m_iDebuggerIsInstalled == 0);
		} /* if */
		// for remote debugging, prefer console version
		if (m_iDebuggerIsInstalled & dbgConsole) {
			m_strDebuggerRemote = "pawndbg.exe";
			ASSERT(_access(m_strToolsPath + "pawndbg.exe", 0) == 0);
		} else if (m_iDebuggerIsInstalled & dbgDualTerminal) {
			m_strDebuggerRemote = "pawndbgc.exe";
			ASSERT(_access(m_strToolsPath + "pawndbgc.exe", 0) == 0);
		} else {
			m_strDebuggerRemote = "";
			ASSERT(m_iDebuggerIsInstalled == 0);
		} /* if */
		m_iDebuggerEnabled = 0;
		if (!m_strDebuggerLocal.IsEmpty())
			m_iDebuggerEnabled |= DEBUG_LOCAL;
		if (!m_strDebuggerRemote.IsEmpty())
			m_iDebuggerEnabled |= DEBUG_REMOTE;

		// --- set flags to disable compiler and tools menu items if executables are not installed
		CString strGrep = m_strToolsPath + "\\grep.exe";
		m_bGrepIsInstalled = _access(strGrep, 0) == 0;

		CString strUncrustify = m_strToolsPath + "\\uncrustify.exe";
		m_bUncrustifyIsInstalled = _access(strUncrustify, 0) == 0;

		if (!m_bCompilerIsInstalled)	{
			if (IsOnCDROM(m_strToolsPath))	{
				CString msg("Compiler files not found. Insert CD-ROM in ");
				char dr[3] = "x:";
				*dr = m_strToolsPath[0];
				msg += dr;
				if (AfxMessageBox(msg, MB_RETRYCANCEL) == IDRETRY)
					continue;	// start all over again at the for (;;) loop
			}
			else	{
				AfxMessageBox("Install Pawn and/or set the compiler's installation\n"
							  "path in the Tools/Options dialog's Build tab.", MB_ICONSTOP);
			}
		}
		else	{
			// --- set path so compiler can find its own tools
			char* penv = 0;
			penv = getenv("PATH");
			CString path("Path=" + m_strToolsPath + ";" + penv);
			_putenv(path.GetBuffer(0));
		}
		break;
	}

	Snippets.load();
}

CWnd* CQuincyApp::MaximizeDocument(const CString& strDocument)
{
	CMDIChildWnd* pWnd = GetMDIChild(strDocument);// pView->GetParent();
	ASSERT(pWnd);
	ASSERT_KINDOF(CMDIChildWnd, pWnd);
	((CMainFrame*)m_pMainWnd)->MDIMaximize(pWnd);
	return pWnd;
}

CDocument* CQuincyApp::OpenDocumentFile(LPCTSTR lpszFileName)
{
	CString strDocument(lpszFileName);

	// Get round assert if path was on moveable media and gone.
	CFileStatus status;
	if ( ! CFile::GetStatus( strDocument, status ))
		return NULL;

	CDocument* doc = CWinApp::OpenDocumentFile(lpszFileName);
	if (m_pCompiler != 0) {
		CErrorLogDialog *dlg = m_pCompiler->GetErrorLog();
		if (dlg != 0 && ::IsWindowVisible(dlg->m_hWnd))
			((CMainFrame*)m_pMainWnd)->SetLowPane(dlg->m_hWnd);
	} /* if */
	CSymBrowseDialog *symdlg = ((CMainFrame*)m_pMainWnd)->GetSymBrowser();
	if (symdlg != 0 && ::IsWindowVisible(symdlg->m_hWnd))
		((CMainFrame*)m_pMainWnd)->SetRightPane(symdlg->m_hWnd);

	return doc;
}

BOOL CQuincyApp::OnOpenRecentFile(UINT nID)
{
	BOOL maximize;
	ASSERT(m_pMainWnd);
	CMDIChildWnd* pActive = ((CMDIFrameWnd*)m_pMainWnd)->MDIGetActive(&maximize);
	if (pActive == 0)
		maximize = TRUE;

	int nIndex = nID - ID_FILE_MRU_FILE1;	/* save index in recent file list before OnOpenReecentFile() changes it */
	CString path = (*m_pRecentFileList)[nIndex];
	BOOL result = CWinApp::OnOpenRecentFile(nID);
	if (result && maximize)
		MaximizeDocument(path);

	return result;
}

void CQuincyApp::ChangeToRuntimeDirectory(CString& strCmd)
{
	// --- determine where the target program should write its file output (if any)
	// see if the options have a working directory programmed
	CString strWk = GetRuntimeDirectory();
	if (strWk.IsEmpty())	{
		// no options working directory programmed
		if (IsReadOnlyPath(strCmd))
			// use the TEMP directory, if TEMP is set. (If not, you're on your own)
			strWk = GetTemporaryDirectory();
		else	{
			// ----- change to the subdirectory where
			//       executable file is located
			int offset = strCmd.ReverseFind('\\');
			if (offset != -1)	{
				strWk = strCmd.Left(offset);
			}
		}
	}
	if (!strWk.IsEmpty())
		_chdir(strWk);
}

void CQuincyApp::StartProgram(CString& strCmd)
{
	ChangeToRuntimeDirectory(strCmd);
	CStab stabs(strCmd.GetBuffer(0));
	if (stabs.TestSymbols())
		DebugProgram(strCmd);
	else {
		CString strCmdQ = theApp.Enquote(theApp.ToolsPath() + "pawnrun.exe") + " " + Enquote(strCmd);
		CString strCmdline;
		GetCommandLine(strCmdline);

		delete m_pExecutor;
		m_pExecutor = new Executor(strCmdQ);
		m_pExecutor->Run(strCmdline.GetBuffer(0));
	}
}

void CQuincyApp::DebugProgram(CString strCmd, bool bStepping)
{
	// disable logging
	if (theApp.GetCompiler()) {
		CErrorLogDialog *dlg = theApp.GetCompiler()->GetErrorLog();
		if (dlg != 0)
			dlg->SuspendLogMonitor();
	} /* if */

	CStab stabs(strCmd.GetBuffer(0));
	if (stabs.TestSymbols())	{
		ChangeToRuntimeDirectory(strCmd);

		ASSERT(m_pDebugger == 0);
		m_pDebugger = new Debugger;

		strCmd = Enquote(strCmd);

		CString strCmdline;
		GetCommandLine(strCmdline);
		if (!strCmdline.IsEmpty())	{
			strCmd += " ";
			strCmd += strCmdline;
		}
		m_pDebugger->LoadDebugger(strCmd.GetBuffer(0));
		PostWatchList();
		std::set<Breakpoint>::iterator iter;
		for (iter=breakpoints.begin(); iter != breakpoints.end(); iter++)
			m_pDebugger->SetBreakpoint(*iter);

		// check for breakpoints, if none are set, stop at main()
		if (bStepping || breakpoints.size() == 0)
			m_pDebugger->StepIntoProgram();
		else
			m_pDebugger->StartProgram();
	}
	else if (AfxMessageBox("No debug information. Run anyway?", MB_YESNO | MB_ICONQUESTION) == IDYES)
		StartProgram(strCmd);
}

// --- called from the debugger to stop itself. Don't call this from anywhere else
void CQuincyApp::StopDebugger()
{
	delete m_pDebugger;
	m_pDebugger = 0;
}

void CQuincyApp::GetCommandLine(CString& strCmdLine)
{
	if (m_CommandLinePromptOption == 0)
		strCmdLine = "";
	else	{
		strCmdLine = m_strCommandLine;
		if (m_CommandLinePromptOption == 1)	{
			CCommandLineDialog dlgCmdLine;
			if (dlgCmdLine.DoModal() == IDOK)
				strCmdLine = dlgCmdLine.m_strCommandLine;
		}
	}
}

// ----  extract the path from a file specification
CString CQuincyApp::GetFilePath(const CString& rstrPath)
{
	int offset = rstrPath.ReverseFind('\\');
	if (offset == -1)
		offset = rstrPath.ReverseFind('/');
	return offset == -1 ? CString() : rstrPath.Left(offset);
}
// ----  extract the filename from a file specification
CString CQuincyApp::GetFileName(const CString& rstrPath)
{
	int offset = rstrPath.ReverseFind('\\');
	if (offset == -1)
		offset = rstrPath.ReverseFind('/');
	return offset == -1 ? rstrPath : rstrPath.Right(rstrPath.GetLength() - offset - 1);
}

// ----- compare the date/time stamps on two files
// @return -tive if strFile1 is older, +tive if strFile2 is older, 0 if same date
int CQuincyApp::CompareFileTimes(CString& strFile1, CString& strFile2)
{
	struct _stat buf1;
	char* path1 = strFile1.GetBuffer(0);
	int rtn1 = _stat(path1, &buf1);

	struct _stat buf2;
	char* path2 = strFile2.GetBuffer(0);
	int rtn2 = _stat(path2, &buf2);

	// --- a non-existing file is always older than one that exists
	if (rtn1 == -1 && rtn2 == -1)
		return 0;
	if (rtn1 == 0 && rtn2 == -1)
		return 1;
	if (rtn1 == -1 && rtn2 == 0)
		return -1;

	// ---- a zero-length file is always older than one with data
	if (buf1.st_size == 0 && buf2.st_size != 0)
		return -1;
	if (buf1.st_size != 0 && buf2.st_size == 0)
		return 1;

	return buf1.st_mtime - buf2.st_mtime;
}

void CQuincyApp::ParseFileSpec(CString& strFileSpec, CString& strCmdLine, int nIndex)
{
	int ndx = nIndex + 1;
	CString cmdLine(strCmdLine.Left(nIndex) + " ");

	strFileSpec.Empty();

	while (isspace(strCmdLine[ndx]))
		ndx++;
	while (ndx < strCmdLine.GetLength() && !isspace(strCmdLine[ndx])
				&& strCmdLine[ndx] != '<' && strCmdLine[ndx] != '>')
		strFileSpec += strCmdLine[ndx++];

	while (++ndx < strCmdLine.GetLength())
		cmdLine += strCmdLine[ndx];

	strCmdLine = cmdLine;
}

CTextDocument* CQuincyApp::GetTextDocument(int index)
{
	POSITION tpos = GetFirstDocTemplatePosition();
	while (tpos != 0)	{
		CDocTemplate* pTem = GetNextDocTemplate(tpos);
		ASSERT(pTem != 0);
		POSITION dpos = pTem->GetFirstDocPosition();
		while (dpos != 0)	{
			CTextDocument* pDoc = static_cast<CTextDocument*>(pTem->GetNextDoc(dpos));
			ASSERT(pDoc != 0);
			if (index-- == 0)
				return pDoc;
		}
	}
	return 0;
}

CTextDocument* CQuincyApp::GetTextDocument(CString pstrPath)
{
	POSITION tpos = GetFirstDocTemplatePosition();
	CString strArgFile = GetFileName(pstrPath);
	while (tpos != 0)	{
		CDocTemplate* pTem = GetNextDocTemplate(tpos);
		ASSERT(pTem != 0);
		POSITION dpos = pTem->GetFirstDocPosition();
		while (dpos != 0)	{
			CTextDocument* pDoc = static_cast<CTextDocument*>(pTem->GetNextDoc(dpos));
			ASSERT(pDoc != 0);
			CString strDocFile = GetFileName(pDoc->GetPathName());
			if (strArgFile.CompareNoCase(strDocFile) == 0)
				return pDoc;
		}
	}
	return 0;
}

// Return true if any file is open
bool CQuincyApp::IsFileOpen() const
{
	POSITION tpos = GetFirstDocTemplatePosition();
	while (tpos != 0)	{
		CDocTemplate* pTem = GetNextDocTemplate(tpos);
		ASSERT(pTem != 0);
		POSITION dpos = pTem->GetFirstDocPosition();
		if (dpos != 0)
			return true;
	}
	return false;
}

CMDIChildWnd* CQuincyApp::GetMDIChild(CString pstrPath)
{
	CTextView* pView = GetTextView(pstrPath);
	if (pView != 0)
		return (CMDIChildWnd*)pView->GetParent();
	return 0;
}

CMDIChildWnd* CQuincyApp::GetMDIChild()
{
	BOOL maximize;
	if (m_pMainWnd)
		return ((CMDIFrameWnd*)m_pMainWnd)->MDIGetActive(&maximize);
	return 0;
}

CTextView* CQuincyApp::GetTextView(CString pstrPath)
{
	CTextDocument* pDoc = GetTextDocument(pstrPath);
	if (pDoc != 0)	{
		POSITION vpos = pDoc->GetFirstViewPosition();
		ASSERT(vpos != 0);
		CTextView* pView = static_cast<CTextView*>(pDoc->GetNextView(vpos));
		ASSERT(pView != 0);
		return pView;
	}
	return 0;
}

void CQuincyApp::ShowLineColumn(int nLine, int nColumn)
{
	CMainFrame* pMainFrame = static_cast<CMainFrame*>(m_pMainWnd);
	pMainFrame->SetRowColumn(nLine, nColumn);
}


BOOL CQuincyApp::OnIdle(LONG lCount)
{
	if (stepping)	{
		stepping = false;
		if (m_pDebugger)
			m_pDebugger->SelectSteppingSourceLine();
	}
	CWinApp::OnIdle(lCount);


#ifdef TYCPP
	if (m_bReadTutorial)
		ReadTutorial();
#endif

	return false;
}

DWORD CQuincyApp::EditorScreenFont(CFont* font, LPCTSTR facename, int ht, int wt)
{
	font->CreateFont(
		ht,						// height
		0,						// width
		0,						// nEscapement
		0,						// nOrientation
		wt,						// nWeight
		0,						// bItalic
		0,						// bUnderline
		0,						// cStrikeOut
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_CHARACTER_PRECIS,
		DEFAULT_QUALITY,
		FIXED_PITCH | FF_DONTCARE,
		facename);

	/* check the size of the font */
	CWindowDC cdc(NULL);
	CFont *org = static_cast<CFont*>(cdc.SelectObject(font));
	CSize sz = cdc.GetTextExtent("X", 1);
	cdc.SelectObject(org);
	return MAKELONG(sz.cx, sz.cy);
}

void CQuincyApp::RetabAllTextDocuments(int newtabstops)
{
	POSITION tpos = GetFirstDocTemplatePosition();
	while (tpos != 0)	{
		CDocTemplate* pTem = GetNextDocTemplate(tpos);
		ASSERT(pTem != 0);
		POSITION dpos = pTem->GetFirstDocPosition();
		while (dpos != 0)	{
			CTextDocument* pDoc = static_cast<CTextDocument*>(pTem->GetNextDoc(dpos));
			ASSERT(pDoc != 0);
			CString strDocFile = GetFileName(pDoc->GetPathName());
			if (strDocFile.Right(4).CompareNoCase(".prj") != 0)
				pDoc->Retab(newtabstops);
		}
	}
}

void CQuincyApp::InvalidateAllViews(bool rebuildfont)
{
	POSITION tpos = GetFirstDocTemplatePosition();
	while (tpos != 0)	{
		CDocTemplate* pTem = GetNextDocTemplate(tpos);
		ASSERT(pTem != 0);
		POSITION dpos = pTem->GetFirstDocPosition();
		while (dpos != 0)	{
			CTextDocument* pDoc = dynamic_cast<CTextDocument*>(pTem->GetNextDoc(dpos)); // could be project file
			if (pDoc != 0)	{
				POSITION vpos = pDoc->GetFirstViewPosition();
				ASSERT(vpos != 0);
				CTextView* pView = static_cast<CTextView*>(pDoc->GetNextView(vpos));
				ASSERT(pView != 0);
				if (rebuildfont)
					pView->RebuildFont();
				pView->Invalidate(false);
				pView->BuildContextHighlightTable();
			}
		}
	}
}

bool CQuincyApp::TestProgramChanged()
{
	if (m_bBypassChangeTest)
		return false;

	POSITION tpos = GetFirstDocTemplatePosition();
	while (tpos != 0)	{
		CDocTemplate* pTem = GetNextDocTemplate(tpos);
		ASSERT(pTem != 0);
		POSITION dpos = pTem->GetFirstDocPosition();
		while (dpos != 0)	{
			CTextDocument* pDoc = static_cast<CTextDocument*>(pTem->GetNextDoc(dpos));
			ASSERT(pDoc != 0);
			CString strDocFile = GetFileName(pDoc->GetPathName());
			if (strDocFile.Right(4).CompareNoCase(".prj") != 0)	{
				if (pDoc->IsModified())	{
					if (AfxMessageBox("Program has changed. Continue?", MB_ICONQUESTION | MB_YESNO) == IDNO)	{
						OnStop();
						return true;
					}
					m_bBypassChangeTest = true;
					break;
				}
			}
		}
	}
	return false;
}

void CQuincyApp::OnStop()
{
	if (m_pCompiler && m_pCompiler->CompileRunning())
		m_pCompiler->Stop();
	else if (m_pDebugger != 0)
		m_pDebugger->Stop();
	else if (m_pGrep != 0)
		m_pGrep->Stop();
}

void CQuincyApp::OnGrep()
{
	if (m_pGrep == 0)
		m_pGrep = new Grep;
	m_pGrep->OnGrep();
}

void CQuincyApp::OnOptions()
{
	CBuildDialog dlgBuild;
	GetArray(dlgBuild.m_strDefine, m_Defines);
	GetArray(dlgBuild.m_strInclude, m_Includes);
	dlgBuild.m_strTargetHost = m_strTargetHost;
	dlgBuild.m_nDebugLevel = m_nDebugLevel;
	dlgBuild.m_nOptimize = m_nOptimize;
	dlgBuild.m_BuildOverlay = m_bOverlays;
	dlgBuild.m_iMaxOptimize = m_iMaxOptimize;
	dlgBuild.m_bOverlayEnabled = m_bOverlayEnabled;
	dlgBuild.m_Verbose = m_Verbose;
	dlgBuild.m_Report = m_Report;
	dlgBuild.m_strTargetPath = m_strTargetPath;
	dlgBuild.m_strCmdLineOptions = m_strCmdLineOptions;
	dlgBuild.m_strCompiler = m_strCompiler;
	dlgBuild.m_strRuntimeDirectory = m_strRuntimeDirectory;

	if (m_strFixedExecName.IsEmpty()) {
		dlgBuild.m_bFixedNameEnabled = FALSE;
		dlgBuild.m_FixedName = BST_UNCHECKED;
	} else {
		dlgBuild.m_bFixedNameEnabled = TRUE;
		dlgBuild.m_FixedName = m_FixedName;
	} /* if */

	CEditorOptions dlgEditor;
	dlgEditor.m_nTabstops = m_tabstops;
	dlgEditor.m_taboption = m_taboption;
	dlgEditor.m_nMaxundos = m_maxundos;
	dlgEditor.m_AutoIndent = m_bAutoindent;
	dlgEditor.m_AutoBullet = m_bRepeatBullet;
	dlgEditor.m_SyntaxColors = m_bSyntaxColors;
	dlgEditor.m_backgroundcolor = m_backgroundcolor;
	dlgEditor.m_normalcolor = m_normalcolor;
	dlgEditor.m_commentcolor = m_commentcolor;
	dlgEditor.m_stringcolor = m_stringcolor;
	dlgEditor.m_keywordcolor = m_keywordcolor;
	dlgEditor.m_operatorcolor = m_operatorcolor;
	dlgEditor.m_numbercolor = m_numbercolor;
	dlgEditor.m_activerowcolor = m_activerowcolor;

	CDebugOptions dlgDebug;
	dlgDebug.m_Local = (m_DebugPort <= 0) ? 0 : 1;
	dlgDebug.m_DebugPort = m_DebugPort;
	dlgDebug.m_DebugBaudrate = m_DebugBaudrate;
	dlgDebug.m_AutoTransfer = m_AutoTransfer;
	dlgDebug.m_EnableLog = m_EnableLog;

	CGeneralOptions dlgGeneral;
	dlgGeneral.m_CheckForUpdates = m_CheckForUpdates;
	dlgGeneral.m_ShowCmdLine = m_ShowCmdLine;
	dlgGeneral.m_ClearBuildMsg = m_ClearBuildMsg;
	dlgGeneral.m_ClearLogMsg = m_ClearLogMsg;

	CSnippetsOptions dlgSnippets;
	dlgSnippets.Snippets.clear();
	dlgSnippets.Snippets = Snippets;	/* copy the snippet list */

	static int activeindex = 0;

	COptionsSheet dlgOptions("Options", 0, activeindex);

	dlgOptions.m_psh.dwFlags |= PSH_NOAPPLYNOW;

	dlgOptions.AddPage(&dlgBuild);
	dlgOptions.AddPage(&dlgDebug);
	dlgOptions.AddPage(&dlgEditor);
	dlgOptions.AddPage(&dlgSnippets);
	dlgOptions.AddPage(&dlgGeneral);

	if (dlgOptions.DoModal() == IDOK)	{

		if (m_tabstops != dlgEditor.m_nTabstops)	{
			RetabAllTextDocuments(dlgEditor.m_nTabstops);
			m_tabstops = dlgEditor.m_nTabstops;
			InvalidateAllViews();
		}

		m_maxundos = dlgEditor.m_nMaxundos;

		if (m_bSyntaxColors != (bool) dlgEditor.m_SyntaxColors ||
				m_backgroundcolor != dlgEditor.m_backgroundcolor ||
					m_normalcolor != dlgEditor.m_normalcolor  ||
						m_commentcolor != dlgEditor.m_commentcolor ||
							m_stringcolor != dlgEditor.m_stringcolor  ||
								m_keywordcolor != dlgEditor.m_keywordcolor ||
									m_operatorcolor != dlgEditor.m_operatorcolor ||
										m_numbercolor != dlgEditor.m_numbercolor ||
											m_activerowcolor != dlgEditor.m_activerowcolor)	{
			m_bSyntaxColors   = dlgEditor.m_SyntaxColors;
			m_backgroundcolor = dlgEditor.m_backgroundcolor;
			m_normalcolor     = dlgEditor.m_normalcolor;
			m_commentcolor    = dlgEditor.m_commentcolor;
			m_stringcolor     = dlgEditor.m_stringcolor;
			m_keywordcolor    = dlgEditor.m_keywordcolor;
			m_operatorcolor   = dlgEditor.m_operatorcolor;
			m_numbercolor     = dlgEditor.m_numbercolor;
			m_activerowcolor  = dlgEditor.m_activerowcolor;
			InvalidateAllViews();
		}

		if (m_fontheight |= dlgEditor.m_SampleCode.m_fontheight)	{
			m_fontheight = dlgEditor.m_SampleCode.m_fontheight;
			SetFontFace(dlgEditor.m_SampleCode.m_fontname);
			InvalidateAllViews(true);
		}

		if (m_fontweight |= dlgEditor.m_SampleCode.m_fontweight)	{
			m_fontweight = dlgEditor.m_SampleCode.m_fontweight;
			InvalidateAllViews(true);
		}

		m_bAutoindent = dlgEditor.m_AutoIndent;
		m_taboption   = dlgEditor.m_taboption;
		m_bRepeatBullet = dlgEditor.m_AutoBullet;

		// save this flag now, reload the host file near the end of this function
		bool ReloadTargetHost = (m_strTargetHost.CompareNoCase(dlgBuild.m_strTargetHost) != 0);

		// ---- these are items saved with the workspace file
		m_strTargetHost = dlgBuild.m_strTargetHost;
		m_nOptimize = dlgBuild.m_nOptimize;
		m_bOverlays = dlgBuild.m_BuildOverlay;
		m_strCmdLineOptions = dlgBuild.m_strCmdLineOptions;
		m_strTargetPath = dlgBuild.m_strTargetPath;
		m_strRuntimeDirectory = dlgBuild.m_strRuntimeDirectory;
		if (!m_strRuntimeDirectory.IsEmpty() && m_strRuntimeDirectory[m_strRuntimeDirectory.GetLength()-1] != '\\')
			m_strRuntimeDirectory += '\\';

		m_nDebugLevel = dlgBuild.m_nDebugLevel;
		m_Report = dlgBuild.m_Report;
		m_Verbose = dlgBuild.m_Verbose;
		if (!m_strFixedExecName.IsEmpty())
			m_FixedName = dlgBuild.m_FixedName;

		if (dlgDebug.m_Local == 0)
			dlgDebug.m_DebugPort = 0;
		m_DebugPort = dlgDebug.m_DebugPort;
		m_DebugBaudrate = dlgDebug.m_DebugBaudrate;
		m_AutoTransfer = dlgDebug.m_AutoTransfer;
		m_EnableLog = dlgDebug.m_EnableLog;
		if (m_pCompiler != 0) {
			CErrorLogDialog *dlg = m_pCompiler->GetErrorLog();
			if (dlg != 0) {
				if (m_EnableLog)
					dlg->StartLogMonitor();
				else
					dlg->StopLogMonitor();
			} /* if */
		} /* if */

		m_CheckForUpdates = dlgGeneral.m_CheckForUpdates;
		m_ShowCmdLine = dlgGeneral.m_ShowCmdLine;
		m_ClearBuildMsg = dlgGeneral.m_ClearBuildMsg;
		m_ClearLogMsg = dlgGeneral.m_ClearLogMsg;

		LoadArray(m_Defines,  dlgBuild.m_strDefine);
		LoadArray(m_Includes, dlgBuild.m_strInclude);

		if (m_strCompiler != dlgBuild.m_strCompiler)	{
			m_strCompiler = dlgBuild.m_strCompiler;
			int len = m_strCompiler.GetLength();
			if (len && m_strCompiler[len-1] != '\\')
				m_strCompiler += '\\';
			SetCompilerPaths();
		}

		Snippets.clear();
		Snippets = dlgSnippets.Snippets;	/* copy the snippet list back */

		if (ReloadTargetHost) {
			LoadHostConfiguration();
			InfoTip_ReadList();
			RebuildHelpMenu();
			#ifdef TYCPP
				LoadTutorials();
			#endif
			/* after reloading the host configuration, check that all
			 * options are correct
			 */
			bool optmodif = false;
			if (m_nOptimize > m_iMaxOptimize) {
				m_nOptimize = m_iMaxOptimize;
				optmodif = true;
			} /* if */
			if (m_bOverlays && !m_bOverlayEnabled) {
				m_bOverlays = false;
				optmodif = true;
			} /* if */
			if (optmodif)
				AfxMessageBox("Some options have been adjusted, to match the\ncapabilities of the selected target host.", MB_ICONINFORMATION);
		} /* if */
	}
	activeindex = dlgOptions.m_activeindex;
}

// load an array of option strings from an option string ("option1;option2;...)
void CQuincyApp::LoadArray(CStringArray& array, const CString& rstr)
{
	int len = rstr.GetLength();
	char ch = ' ';
	CString str;
	array.RemoveAll();	// start with an empty array
	for (int i = 0; i < len; i++)	{	// skip leading spaces
		if (rstr[i] == ' ')
			continue;
		while (i < len)	{	// iterate the input string
			ch = rstr[i];					// one char at a time
			// --- option terminates with ';' or at end of string
			if (ch == ';' || i == len-1)	{
				if (ch != ';')
					str += ch;
				if (!str.IsEmpty())	{
					array.Add(str);
					str.Empty();
				}
				break;
			}
			else
				str += ch;	// build option string
			i++;
		}
	}
}

// make an options string ("option1;option2;...) from an array of option strings
void CQuincyApp::GetArray(CString& atr, const CStringArray& array) const
{
	int len = array.GetSize();
	atr = "";
	for (int i = 0; i < len; i++)	{
		atr += array[i];
		if (i < len-1)
			atr += ";";
	}
}

BOOL CQuincyApp::FirstInstance()
{
	CWnd *pWndPrev, *pWndChild;

	// Determine if another window with our class name exists...
	if (pWndPrev = CWnd::FindWindow(_T("QuincyAppClass"),NULL)) {
		// if so, does it have any popups?
		pWndChild = pWndPrev->GetLastActivePopup();

		// If iconic, restore the main window
		if (pWndPrev->IsIconic())
			pWndPrev->ShowWindow(SW_RESTORE);

		// Bring the main window or its popup to the foreground
		pWndChild->SetForegroundWindow();

		// Parse the commend line for this re-launch, in order to
		// load additional files
		CCommandLineInfo cmdInfo;
		ParseCommandLine(cmdInfo);
		if (cmdInfo.m_nShellCommand == CCommandLineInfo::FileOpen) {
			LPTSTR lpData = (LPTSTR)m_mmf->Open();
			if (lpData)
				_tcscpy(lpData, cmdInfo.m_strFileName);
			m_mmf->Close();
			pWndPrev->PostMessage(WM_COMMAND, ID_SHELLOPEN, 0);
		} /* if */

		// and we are done activating the previous one.
		return FALSE;
	}
	// First instance. Proceed as normal.
	else
		return TRUE;
}


int CQuincyApp::ExitInstance()
{
	m_bWatchCreated = false;
	WriteProfileInt("Editor", "AutoIndent",        m_bAutoindent);
	WriteProfileInt("Editor", "SyntaxHighlight",   m_bSyntaxColors);
	WriteProfileInt("Editor", "VisibleWhitespace", m_bShowTabSpaces);
	WriteProfileInt("Editor", "RepeatBullet",      m_bRepeatBullet);
	WriteProfileInt("Editor", "TabWidth",          m_tabstops);
	WriteProfileInt("Editor", "HardTabs",          m_taboption);
	WriteProfileInt("Editor", "Max.Undos",         m_maxundos);

	WriteProfileInt("Editor", "FontHeight",        m_fontheight);
	WriteProfileInt("Editor", "FontWeight",        m_fontweight);
	WriteProfileString("Editor", "FontFace",       m_fontface);

	WriteProfileInt("Editor", "BackgroundColor",   m_backgroundcolor);
	WriteProfileInt("Editor", "NormalColor",       m_normalcolor);
	WriteProfileInt("Editor", "KeywordColor",      m_keywordcolor);
	WriteProfileInt("Editor", "OperatorColor",     m_operatorcolor);
	WriteProfileInt("Editor", "CommentColor",      m_commentcolor);
	WriteProfileInt("Editor", "StringColor",       m_stringcolor);
	WriteProfileInt("Editor", "NumberColor",       m_numbercolor);
	WriteProfileInt("Editor", "ActiveRowColor",    m_activerowcolor);

	WriteProfileInt("Options", "PrintLineNumbers", m_bPrintLineNos);
	WriteProfileInt("Options", "CheckForUpdates", m_CheckForUpdates);
	WriteProfileInt("Options", "ShowCmdLine",	m_ShowCmdLine);
	WriteProfileInt("Options", "ClearBuildMsg",	m_ClearBuildMsg);
	WriteProfileInt("Options", "ClearLogMsg",	m_ClearLogMsg);

	WriteProfileInt("Options",    "Style",		m_style);
	WriteProfileString("Options", "Command",	m_command);

	WriteProfileString("Options", "Project",	m_ProjectFile);
	SaveProjectSettings();
	Snippets.save();

#ifdef TYCPP
	WriteProfileInt("Tutorial",    "Displayed", m_bTutorialDisplayed );
	WriteProfileString("Tutorial", "Current", m_strTutorial);
#endif
	WriteProfileString("Directories", "Runtime",	  m_strRuntimeDirectory);
	WriteProfileString("Directories", "Compiler",     m_strCompiler);

	CString strBuffer;
	strBuffer.Format ("%i:%i:%i:%i",
			m_ConsoleRect.left,
			m_ConsoleRect.top,
			m_ConsoleRect.right,
			m_ConsoleRect.bottom);

	AfxGetApp()->WriteProfileString ("Settings", "Console Position", strBuffer);


	char path[MAX_PATH];
	_getcwd(path, MAX_PATH);
	WriteProfileString("Directories", "Current", path);

    if(bClassRegistered)
		::UnregisterClass(_T("QuincyAppClass"),AfxGetInstanceHandle());
 	return CWinApp::ExitInstance();
}

bool CQuincyApp::SelectFileAndLine(const CString& strFile, int nline, bool activate, const char *symbolname)
{
	if (!strFile.IsEmpty())	{
		CDocument* pDoc = OpenDocumentFile(strFile);
		if (pDoc != 0)	{	// (user could delete the source code file before reading it)
			/* show document and (optionally) change the focus to it */
			POSITION dpos = pDoc->GetFirstViewPosition();
			ASSERT(dpos != 0);
			CEditorView* pView = static_cast<CEditorView*>(pDoc->GetNextView(dpos));
			ASSERT(pView != 0);
			pView->HideInfoTip();
			pView->UpdateWindow();
			pView->Invalidate();
			if (activate)
				pView->SetFocus();
			if (symbolname) {
				/* search upwards and downwards for the first occurence of the name */
				int row = nline - 1;	/* nline is "1-based", but text line indexing is "0-based" */
				int toprow = row;
				CEditorDoc *pEdit = pView->GetDocument();
				ASSERT(pEdit != 0);
				while (toprow >= 0)  {
					const std::string& line = pEdit->textline(toprow);
					if (strstr(line.c_str(), symbolname) != 0)
						break;
					toprow--;
                } /* while */
				int botrow = row;
				while (botrow < pEdit->linecount())  {
					const std::string& line = pEdit->textline(botrow);
					if (strstr(line.c_str(), symbolname) != 0)
						break;
					botrow++;
                } /* while */
				if (toprow >= 0 && ((row - toprow) < (botrow - row)) || botrow >= pEdit->linecount())
					row = toprow;	
				else if (botrow < pEdit->linecount() && ((nline - toprow) >= (botrow - nline)) || toprow < 0)
					row = botrow;
				nline = row + 1;	/* nline is "1-based", but text line indexing is "0-based" */
		    } /* if */
			if (nline > 0)	{
				// ---- position text so that the specified line is current
				pView->SetLineColumn(nline, 1);
				ShowLineColumn(nline, 1);
			}
			return true;
		}
	}
	return false;
}

void CQuincyApp::SelectErrorLine(int nsel, bool activate)
{
	if (nsel != -1 && m_pCompiler != 0)	{
		CString strFile;
		int line;
		if (m_pCompiler->GetMessageData(nsel, strFile, line))
			SelectFileAndLine(strFile, line, activate);
	}
}

void CQuincyApp::SelectGrepLine(int nsel)
{
	if (m_pGrep != 0) {
		m_pGrep->SelectGrepLine(nsel);
		// if a new file is loaded by the above function, we must re-display the error log
		if (m_pCompiler) {
			m_pCompiler->CreateErrorLog();
			CErrorLogDialog* dlg = m_pCompiler->GetErrorLog();
			if (dlg) {
				dlg->SwitchTab(2);
				int maximize;
				ASSERT(m_pMainWnd);
				CMDIChildWnd* pActive = ((CMDIFrameWnd*)m_pMainWnd)->MDIGetActive(&maximize);
				if (pActive)
					pActive->SetFocus();
			} /* if */
		} /* if */
	} /* if */
}

void CQuincyApp::OnUpdateStop(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(
			CompileRunning() ||
			(m_pGrep != 0 && m_pGrep->IsRunning()) ||
			(m_pDebugger != 0) // && m_pDebugger->CanStop())
			);
}

bool CQuincyApp::IsWorkplaceFile(LPCTSTR filename) const
{
	CString tmpstr = CString(filename);
	return (tmpstr.Find(".qws") > 0);
}

void CQuincyApp::OnShellFileOpen()
{
	LPTSTR lpData = (LPTSTR)m_mmf->Open();
	if (lpData) {
		if (IsWorkplaceFile(lpData))
			SwitchWorkspace(lpData);
		else
			OpenDocumentFile(lpData);
	} /* if */
	m_mmf->Close();
};

void CQuincyApp::SaveAllDocuments(bool prompt)
{
	POSITION tpos = GetFirstDocTemplatePosition();
	while (tpos != 0)	{
		CDocTemplate* pTem = GetNextDocTemplate(tpos);
		ASSERT(pTem != 0);
		POSITION dpos = pTem->GetFirstDocPosition();
		while (dpos != 0)	{
			CDocument* pDoc = pTem->GetNextDoc(dpos);
			ASSERT(pDoc != 0);
			if (pDoc->IsModified())	{
				const CString& strPath = pDoc->GetPathName();
				if (!strPath.IsEmpty())	{
					if (prompt)	{
						CString msg("Save ");
						msg += GetFileName(strPath) + "?";
						if (AfxMessageBox(msg, MB_YESNO | MB_ICONQUESTION) != IDYES)
							continue;
					}
					pDoc->OnSaveDocument(strPath);
					pDoc->SetModifiedFlag(false);
				}
			}
		}
	}
}

void CQuincyApp::SaveOpenDocuments()
{
	const char *pszCurProfile = m_pszProfileName;	/* save original profile name (restored at the end of this function) */
	if (!m_ProjectFile.IsEmpty())
		m_pszProfileName = m_ProjectFile;

	/* erase the complete section before writing new entries */
	WriteProfileString("Documents", NULL, NULL);

	POSITION tpos = GetFirstDocTemplatePosition();
	int nDocno = 0;
	CString strKey;
	while (tpos != 0)	{
		CDocTemplate* pTem = GetNextDocTemplate(tpos);
		ASSERT(pTem != 0);
		POSITION dpos = pTem->GetFirstDocPosition();
		while (dpos != 0)	{
			CEditorDoc* pDoc = static_cast<CEditorDoc*>(pTem->GetNextDoc(dpos));
			ASSERT(pDoc != 0);
			CString strPath = pDoc->GetPathName();
			strKey.Format("Document%d", ++nDocno);
			WriteProfileString("Documents", strKey, strPath);

			CTextView* pView = GetTextView(strPath);
			ASSERT(pView != 0);
			CWnd* pWnd = pView->GetParent();
			ASSERT(pWnd != 0);
			WINDOWPLACEMENT wndpl = { sizeof(WINDOWPLACEMENT) };
			if (pWnd->GetWindowPlacement(&wndpl))	{
				strKey.Format("Document%d Maximized", nDocno);
				WriteProfileInt("Documents", strKey, wndpl.showCmd == SW_SHOWMAXIMIZED);
			} /* if */
		} /* while */
	} /* while */

	if (!m_ProjectFile.IsEmpty())
		m_pszProfileName = pszCurProfile;
}

CWnd* CQuincyApp::RestoreOpenDocuments()
{
	const char *pszCurProfile = m_pszProfileName;	/* save original profile name (restored at the end of this function) */
	if (!m_ProjectFile.IsEmpty())
		m_pszProfileName = m_ProjectFile;

	CWnd* pFocusWnd = 0;
	int nDocno = 0;
	CString strKey;
	for ( ;; )	{
		strKey.Format("Document%d", nDocno+1);
		CString strDocument = GetProfileString("Documents", strKey, 0);
		if (strDocument.IsEmpty())
			break;

		if (OpenDocumentFile(strDocument))	{
			// --- check whether this is a Pawn script
			int pos = strDocument.ReverseFind('.');
			if (pos >= 0 && strDocument.Find('\\', pos) < 0) {
				CString ext = strDocument.Mid(pos);
				if (ext.CollateNoCase(".p") == 0 || ext.CollateNoCase(".pawn") == 0 || ext.CollateNoCase(".pwn") == 0) {
					pFocusWnd = GetMDIChild(strDocument);
					ASSERT(pFocusWnd != NULL);
				} /* if */
			} /* if */
			// --- if the document was maximized on exit, maximize it now
			strKey.Format("Document%d Maximized", nDocno+1);
			bool bIsMax = GetProfileInt("Documents", strKey, 0);
			if (bIsMax) {
				CWnd *pWnd = MaximizeDocument(strDocument);
				if (pFocusWnd == NULL)
					 pFocusWnd = pWnd;
			} /* if */
		} /* if */
		nDocno++;
	} /* for */

	if (!m_ProjectFile.IsEmpty())
		m_pszProfileName = pszCurProfile;

	return pFocusWnd;
}

void CQuincyApp::SaveDialogWindowPosition(const CString& strWindow, CWnd* pWnd)
{
	WINDOWPLACEMENT wndpl = { sizeof(WINDOWPLACEMENT) };
	if (pWnd->m_hWnd != 0 && pWnd->GetWindowPlacement(&wndpl))	{
		RECT rc = wndpl.rcNormalPosition;
		WriteProfileInt(strWindow, "Left", rc.left);
		WriteProfileInt(strWindow, "Top",  rc.top);
		WriteProfileInt(strWindow, "Width",  rc.right - rc.left);
		WriteProfileInt(strWindow, "Height",  rc.bottom - rc.top);
	}
}

void CQuincyApp::RestoreDialogWindowPosition(const CString& strWindow, CWnd* pWnd)
{
	WINDOWPLACEMENT wndpl = { sizeof(WINDOWPLACEMENT) };
	if (pWnd->m_hWnd != 0)	{
		pWnd->GetWindowPlacement(&wndpl);
		int wd = wndpl.rcNormalPosition.right - wndpl.rcNormalPosition.left;
		int ht = wndpl.rcNormalPosition.bottom - wndpl.rcNormalPosition.top;
		wd = GetProfileInt(strWindow, "Width", wd);
		ht = GetProfileInt(strWindow, "Height", ht);
		wndpl.rcNormalPosition.left = GetProfileInt(strWindow, "Left", wndpl.rcNormalPosition.left);
		wndpl.rcNormalPosition.top = GetProfileInt(strWindow, "Top", wndpl.rcNormalPosition.top);
		wndpl.rcNormalPosition.right = wndpl.rcNormalPosition.left + wd;
		wndpl.rcNormalPosition.bottom = wndpl.rcNormalPosition.top + ht;
		pWnd->SetWindowPlacement(&wndpl);
	}
}

void CQuincyApp::CloseBuildPanel()
{
	if (theApp.GetCompiler()) {
		CErrorLogDialog *dlg = GetCompiler()->GetErrorLog();
		if (dlg != 0) {
			if (::IsWindowVisible(dlg->m_hWnd)) {
				dlg->ShowWindow(SW_HIDE);
				((CMainFrame*)m_pMainWnd)->SetLowPane(0);
			} /* if */
		} /* if */
	} /* if */
}

void CQuincyApp::CloseSymBrowser()
{
	CSymBrowseDialog *dlg = ((CMainFrame*)m_pMainWnd)->GetSymBrowser();
	if (dlg != 0 && ::IsWindowVisible(dlg->m_hWnd)) {
		dlg->ShowWindow(SW_HIDE);
		((CMainFrame*)m_pMainWnd)->SetRightPane(0);
	} /* if */
}

// ------- permit clearing all the breakpoints
void CQuincyApp::OnUpdateDebugClearbreakpoints(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(breakpoints.size() > 0);
}

// ------- clear all the breakpoints
void CQuincyApp::OnDebugClearbreakpoints()
{
	breakpoints.clear();
	if (m_pDebugger)
		m_pDebugger->ClearBreakpoint();
	InvalidateAllViews();
}

void CQuincyApp::BringToTop()
{
	ASSERT(m_pMainWnd != 0);
	m_pMainWnd->SetForegroundWindow();
}
// ----- the run command
bool CQuincyApp::ExecuteRunningProgram()
{
	if (m_pDebugger != 0)
		return m_pDebugger->ExecuteRunningProgram();
	return false;
}
// ------- the step command
bool CQuincyApp::StepProgram()
{
	if (m_pDebugger != 0)
		return m_pDebugger->StepProgram();
	return false;
}

bool CQuincyApp::StepTo(const CString& strFile, int nLineNo)
{
	if (m_pDebugger != 0)
		return m_pDebugger->StepTo(strFile, nLineNo);
	return false;
}

// ------- the step out command
void CQuincyApp::StepOut()
{
	if (m_pDebugger != 0)
		m_pDebugger->StepOut();
}
// ----- the step over command
void CQuincyApp::OnDebugStepover()
{
	if (m_pDebugger == 0 || m_pDebugger->StepOver() == false)
		m_pMainWnd->PostMessage(WM_COMMAND, ID_DEBUG_STEP);
}
// ------ disable stepping over if no document is open
void CQuincyApp::OnUpdateDebugStepover(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(false);
}
// ------ disable watches window if no document is open
void CQuincyApp::OnUpdateDebugWatch(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(false);
}
// ------- get the value of a variable: used by watch and examine processes
void CQuincyApp::GetVariableValue(const CString& strVarName, CWnd* wnd)
{
	if (m_pDebugger != 0)
		m_pDebugger->GetVariableValue(strVarName, wnd->m_hWnd);
}
void CQuincyApp::SetVariableValue(const CString& strVarName, const CString& strVarValue)
{
	if (m_pDebugger != 0)
		m_pDebugger->SetVariableValue(strVarName, strVarValue);
}

void CQuincyApp::CreateWatchWindow()
{
	ASSERT(m_pdlgWatch != 0);
	if (m_bWatchCreated != true)	{
		m_pdlgWatch->Create(IDD_WATCH);
		m_bWatchCreated = true;
	}
}

void CQuincyApp::PostWatchList()
{
	if (m_pDebugger && m_pdlgWatch && m_bWatchCreated)	{
		int ct = m_pdlgWatch->GetWatchCount();
		CString* wnames = m_pdlgWatch->GetWatchNames();
		m_pDebugger->SetWatchExpressions(wnames, ct);
	}
}

bool CQuincyApp::IsOnCDROM(const CString& strFileSpec)
{
	if (strFileSpec.GetLength() < 3)
		return false;
	int i;
	char root[4];
	for (i = 0; i < 3; i++)
		root[i] = strFileSpec[i];
	root[i] = '\0';
	return GetDriveType(root) == DRIVE_CDROM;
}

bool CQuincyApp::IsReadOnlyPath(const CString& strFileSpec)
{
	ASSERT(strFileSpec.GetLength() > 0);
	if (IsOnCDROM(strFileSpec))
		return true;

	// see whether this is a file or a directory
	CString path = strFileSpec;
	if (path.Right(1) == '\\')
		path = path.Left(path.GetLength() - 1);	// erase trailing '\\' (likely a path)
	DWORD status = GetFileAttributes(path);
	if (status == 0xffffffff) {
		// this may be a name for a file that does not exist yet (drop
		// through and try to create it)
	} else if ((status & 0x10) != 0) {
		// this is a directory, try to create a file inside this directory
		// (with a temporary name)
		path += "\\$quincy.tmp";
	} else {
		// this is an existing file, return the file attibute
		return (status & 0x01) != 0;
	} /* if */

	// try to write a file to the path
	FILE *fp = fopen(path, "w");
	if (fp != NULL) {
		fclose(fp);
		remove(path);
		return false;
	} /* if */

	return true;
}

///////////////// breakpoint methods //////////////////////////

// ------ adjust breakpoints when user inserts or deletes lines
void CQuincyApp::AdjustTextLine(const CString& strFile, int nLineno, int nAdjust)
{
	std::vector<Breakpoint> dels;
	std::vector<Breakpoint> inss;

	CString strFileName = GetFileName(strFile);

	std::set<Breakpoint>::iterator iter;
	// --- if deleting a line with a breakpoint, delete the breakpoint
	if (nAdjust < 0)	{
		Breakpoint fr(strFileName, nLineno+1);
		iter = breakpoints.find(fr);
		if (iter != breakpoints.end())
			breakpoints.erase(iter);
	}
	// --- find the breakpoints for this file greater than the current line
	Breakpoint fr(strFileName, nLineno);
	iter = std::lower_bound(breakpoints.begin(), breakpoints.end(), fr);
	while (iter != breakpoints.end() &&
			(*iter).m_strFile.CompareNoCase(strFileName) == 0)	{
		Breakpoint fr = *iter;
		dels.push_back(fr);
		fr.m_nLineNo += nAdjust;
		inss.push_back(fr);
		iter++;
	}
	std::vector<Breakpoint>::iterator vfr;
	for (vfr = dels.begin(); vfr != dels.end(); vfr++)	{
		iter = breakpoints.find(*vfr);
		if (iter != breakpoints.end())
			breakpoints.erase(iter);
	}
	for (vfr = inss.begin(); vfr != inss.end(); vfr++)
		breakpoints.insert(*vfr);
}

int CQuincyApp::FindBreakpoint(const CString& strFile, int nLineno, int nSearchDirection)
{
	CString strFileName = GetFileName(strFile);
	Breakpoint fr(strFileName, nLineno + nSearchDirection);
	std::set<Breakpoint>::iterator iter;
	iter = std::upper_bound(breakpoints.begin(), breakpoints.end(), fr);
	if (nSearchDirection < 0) {
		if (iter == breakpoints.begin())
			return -1;
		iter--;
	} /* if */
	if (iter != breakpoints.end() && (*iter).m_strFile.CompareNoCase(strFileName) == 0)
		return iter->m_nLineNo;
	return -1;
}

// --- set or clear a breakpoint
void CQuincyApp::ToggleBreakpoint(const CString& strFile, int nLineNo)
{
	Breakpoint fr(GetFileName(strFile), nLineNo);
	std::set<Breakpoint>::iterator iter = breakpoints.find(fr);
	if (iter == breakpoints.end()) {
		breakpoints.insert(fr);
		if (m_pDebugger != 0)
			m_pDebugger->SetBreakpoint(fr);
	} else {
		breakpoints.erase(iter);
		if (m_pDebugger != 0)
			m_pDebugger->ClearBreakpoint(fr);
	}
}

void CQuincyApp::AddBreakpoint(const CString& strFile, int nLineNo)
{
	Breakpoint fr(GetFileName(strFile), nLineNo);
	std::set<Breakpoint>::iterator iter = breakpoints.find(fr);
	if (iter == breakpoints.end())
		breakpoints.insert(fr);
}

// ------ test for a breakpoint set in a file at a line number
bool CQuincyApp::IsBreakpoint(const CString& strFile, int nLineno)
{
	Breakpoint fr(strFile, nLineno);
	std::set<Breakpoint>::iterator iter = breakpoints.find(fr);
	bool bBrk = iter != breakpoints.end();
	return bBrk;
}


void CQuincyApp::OnDebugWatch()
{
	CreateWatchWindow();
	m_pdlgWatch->ShowWindow(SW_SHOW);
	m_pdlgWatch->SetFocus();
	if (m_pdlgWatch->GetWatchCount() == 0)	{
		if (GetEditorView() != 0)	{
			std::string str = GetEditorView()->SelectedText();
			m_pdlgWatch->AddSelectedWatch(str);
		}
		else
			m_pdlgWatch->AddWatch();
	}
}

bool CQuincyApp::StopDebugging()
{
	if (m_pDebugger != 0)	{
		if (AfxMessageBox("This stops the debugger. Continue?", MB_ICONQUESTION | MB_YESNO) == IDYES)
			m_pDebugger->Stop();
		else
			return false;
	}
	return true;
}

void CQuincyApp::OnLogView()
{
	if (m_pCompiler) {
		bool justcreated = false;
		CErrorLogDialog* dlg = m_pCompiler->GetErrorLog();
		if (!dlg) {
			m_pCompiler->CreateErrorLog();
			justcreated = true;
			dlg = m_pCompiler->GetErrorLog();
		} /* if */
		if (dlg) {
			if (dlg->IsWindowVisible() && !justcreated) {
				dlg->ShowWindow(SW_HIDE);
				((CMainFrame*)m_pMainWnd)->SetLowPane(0);
			} else {
				((CMainFrame*)m_pMainWnd)->SetLowPane(dlg->m_hWnd);
				dlg->SwitchTab(1);		/* add empty log message, to switch to that panel */
				int maximize;
				ASSERT(m_pMainWnd);
				CMDIChildWnd* pActive = ((CMDIFrameWnd*)m_pMainWnd)->MDIGetActive(&maximize);
				if (pActive)
					pActive->SetFocus();
			} /* if */
		} /* if */
	} /* if */
}

void CQuincyApp::OnUpdateLogView(CCmdUI* pCmdUI)
{
	if (GetCompiler()) {
		CErrorLogDialog *dlg = GetCompiler()->GetErrorLog();
		if (dlg != 0)
			pCmdUI->SetCheck(::IsWindowVisible(dlg->m_hWnd));
	} /* if */
}

void CQuincyApp::OnUpdateSymbolBrowser(CCmdUI* pCmdUI)
{
	CSymBrowseDialog *dlg = ((CMainFrame*)m_pMainWnd)->GetSymBrowser();
	if (dlg != 0)
		pCmdUI->SetCheck(::IsWindowVisible(dlg->m_hWnd));
}

void CQuincyApp::OnAppAbout()
{
	CAboutDlg aboutDlg;

	// --- display compiler version in about dialog
	if (m_bCompilerIsInstalled)
		aboutDlg.m_strCompilerVersion = "Pawn version " + m_strVersion;

	// --- display operating version in about dialog
	CString version;
	switch (osversion.dwPlatformId)
	{
	case VER_PLATFORM_WIN32_NT:
		if ( osversion.dwMajorVersion == 6 ) {
			if (osversion.dwMinorVersion == 1) {
				if (osversion.wProductType == VER_NT_WORKSTATION)
					version = "7";
				else
					version = "Server 2008 R2";
			} else {
				if (osversion.wProductType == VER_NT_WORKSTATION)
					version = "Vista";
				else
					version = "Server 2008";
			} /* if */
		} else if ( osversion.dwMajorVersion == 5 )	{
			if ( osversion.dwMinorVersion == 2 )
				version = "Server 2003";
			else if ( osversion.dwMinorVersion == 1 )
				version = "XP";
			else if ( osversion.dwMinorVersion == 0 )
				version = "2000";
			else
				version.Format("ID: %ld-%d.%d", osversion.dwPlatformId,
										        osversion.dwMajorVersion,
												osversion.dwMinorVersion);

		}
		else if ( osversion.dwMajorVersion <= 4 )
			version = "NT";
		else
			version.Format("ID: %ld-%d.%d", osversion.dwPlatformId,
									        osversion.dwMajorVersion,
											osversion.dwMinorVersion);
	break;
	case VER_PLATFORM_WIN32_WINDOWS:
         if (osversion.dwMajorVersion == 4)
		 {
			if ( osversion.dwMinorVersion == 0)
				version = "95";
			else if ( osversion.dwMinorVersion == 10)
				version = "98";
			else if ( osversion.dwMinorVersion == 90)
				version = "ME";
			else
				version.Format("ID: %ld-%d.%d", osversion.dwPlatformId,
			                            osversion.dwMajorVersion,
										osversion.dwMinorVersion);
		 }
    break;
	default:
		version.Format("ID: %ld-%d.%d", osversion.dwPlatformId,
			                            osversion.dwMajorVersion,
										osversion.dwMinorVersion);
	break;
	}
	aboutDlg.m_strOSVersion.Format("Windows %s", version);

	aboutDlg.DoModal();
}

void CQuincyApp::OnUpdateGrep(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_bGrepIsInstalled);
}

#ifdef TYCPP
void CQuincyApp::OnUpdateTycpp(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_bIsTutorial);
}
#endif

void CQuincyApp::OnHelp()
{
	/* if there is a selection, get it */
	if (GetEditorView() != 0)	{
		std::string str = GetEditorView()->SelectedText();
		if (str.size() > 0) {
			OpenHelp(str.c_str());
			return;
		} /* if */
	} /* if */
	OpenHelp(ID_HELP);
}

void CQuincyApp::OnUpdateHelp(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_HelpIndex->LookUp(ID_HELP) != NULL);
}

void CQuincyApp::OnHelp1() { OpenHelp(ID_HELP1); }
void CQuincyApp::OnHelp2() { OpenHelp(ID_HELP2); }
void CQuincyApp::OnHelp3() { OpenHelp(ID_HELP3); }
void CQuincyApp::OnHelp4() { OpenHelp(ID_HELP4); }
void CQuincyApp::OnHelp5() { OpenHelp(ID_HELP5); }
void CQuincyApp::OnHelp6() { OpenHelp(ID_HELP6); }
void CQuincyApp::OnHelp7() { OpenHelp(ID_HELP7); }
void CQuincyApp::OnHelp8() { OpenHelp(ID_HELP8); }
void CQuincyApp::OnHelp9() { OpenHelp(ID_HELP9); }
void CQuincyApp::OnHelp10() { OpenHelp(ID_HELP10); }
void CQuincyApp::OnHelp11() { OpenHelp(ID_HELP11); }
void CQuincyApp::OnHelp12() { OpenHelp(ID_HELP12); }
void CQuincyApp::OnHelp13() { OpenHelp(ID_HELP13); }
void CQuincyApp::OnHelp14() { OpenHelp(ID_HELP14); }
void CQuincyApp::OnHelp15() { OpenHelp(ID_HELP15); }


// read project-dependent settings
// if projectfile is NULL, the name of the project file must
// already have been set in class member m_pszProfileName
void CQuincyApp::LoadProjectSettings()
{
	const char *pszCurProfile = m_pszProfileName;	/* save original profile name (restored at the end of this function) */
	if (!m_ProjectFile.IsEmpty())
		m_pszProfileName = m_ProjectFile;

	/* load settings */
	m_nDebugLevel = GetProfileInt("Options", "Debugging", m_nDefaultDebugLevel);
	m_DebugPort = GetProfileInt("Options", "DebugPort", 0);
	m_DebugBaudrate = GetProfileInt("Options", "DebugBaudrate", 0);
	m_AutoTransfer = GetProfileInt("Options", "AutoTransfer", 0);
	m_EnableLog = GetProfileInt("Options", "EnableLog", 1);
	m_Verbose = GetProfileInt("Options", "Verbose", 0);
	m_Report = GetProfileInt("Options", "Report", 0);
	m_FixedName = GetProfileInt("Options", "FixedName", BST_CHECKED);
	m_strCommandLine = GetProfileString("Options", "Command Line");
	m_strCmdLineOptions = GetProfileString("Options", "Compiler Command Line Options");
	m_CommandLinePromptOption = GetProfileInt("Options", "Command Line Prompt", 0);
	m_strTargetHost = GetProfileString("Options", "TargetHost");
	m_nOptimize = GetProfileInt("Options", "Optimize", m_nDefaultOptimize);
	m_bOverlays = GetProfileInt("Options", "Overlays", 0);

	CString strArray;
	strArray = GetProfileString("Options", "Defines");
	LoadArray(m_Defines, strArray);
	strArray = GetProfileString("Options", "Includes");
	LoadArray(m_Includes, strArray);

	m_strTargetPath = GetProfileString("Directories", "TargetPath");

	if (!m_ProjectFile.IsEmpty())
		m_pszProfileName = pszCurProfile;
}

void CQuincyApp::SaveProjectSettings()
{
	const char *pszCurProfile = m_pszProfileName;	/* save original profile name (restored at the end of this function) */
	if (!m_ProjectFile.IsEmpty())
		m_pszProfileName = m_ProjectFile;

	/* save settings */
	WriteProfileInt("Options", "Debugging", m_nDebugLevel);
	WriteProfileInt("Options", "DebugPort", m_DebugPort);
	WriteProfileInt("Options", "DebugBaudrate", m_DebugBaudrate);
	WriteProfileInt("Options", "AutoTransfer", m_AutoTransfer);
	WriteProfileInt("Options", "EnableLog", m_EnableLog);
	WriteProfileInt("Options", "Verbose", m_Verbose);
	WriteProfileInt("Options", "Report", m_Report);
	WriteProfileInt("Options", "FixedName", m_FixedName);
	WriteProfileInt("Options", "Command Line Prompt", m_CommandLinePromptOption);
	WriteProfileInt("Options", "Optimize", m_nOptimize);
	WriteProfileInt("Options", "Overlays", m_bOverlays);
	WriteProfileString("Options", "TargetHost", m_strTargetHost);
	WriteProfileString("Options", "Command Line", m_strCommandLine);
	WriteProfileString("Options", "Compiler Command Line Options", m_strCmdLineOptions);

	CString strArray;
	GetArray(strArray, m_Defines);
	WriteProfileString("Options", "Defines", strArray);
	GetArray(strArray, m_Includes);
	WriteProfileString("Options", "Includes", strArray);

	WriteProfileString("Directories", "TargetPath", m_strTargetPath);

	if (!m_ProjectFile.IsEmpty())
		m_pszProfileName = pszCurProfile;
}

void CQuincyApp::LoadHostConfiguration()
{
#define START_OPTION(ptr,base)	((ptr)!=NULL && ((ptr)==(base) || *((ptr)-1) == ' '))
	// preset with compiler defaults
	m_strFixedExecName.Empty();
	m_nDefaultOptimize = 1;
	m_nDefaultDebugLevel = 1;

	m_bRunTimeEnabled = m_bRunTimeIsInstalled;	// by default, what is installed is enabled
	m_iDebuggerEnabled = 0;
	if (!m_strDebuggerLocal.IsEmpty())
		m_iDebuggerEnabled |= DEBUG_LOCAL;
	if (!m_strDebuggerRemote.IsEmpty())
		m_iDebuggerEnabled |= DEBUG_REMOTE;
	m_iMaxOptimize = 3;
	m_bOverlayEnabled = true;

	CString CfgPath;
	if (m_strTargetHost.IsEmpty())
		CfgPath = "pawn";
	else
		CfgPath = m_strTargetHost;
	CfgPath = m_strToolsPath + CfgPath + ".cfg";
	// parse through the pawn.cfg file to find an optional required output name
	std::ifstream ifile(CfgPath.GetBuffer(MAX_PATH));
	if (!ifile.fail())	{
		char options[300];
		char *ptr;
		while (ifile.getline(options, sizeof options)) {
			/* fixed output file */
			ptr = strstr(options, "-o:");
			if (START_OPTION(ptr, options)) {
				CString name = ptr+3;	// strip off "-o:"
				int idx;
				for (idx = 0; idx < name.GetLength() && name[idx] > ' '; idx++)
					/* nothing */;
				name = name.Left(idx);
				idx = name.ReverseFind('.');
				if (idx >= 0)
					m_strFixedExecName = name.Left(idx);
			} /* if */
			/* default optimization */
			ptr = strstr(options, "-O:");
			if (START_OPTION(ptr, options))
				m_nDefaultOptimize = atoi(ptr+3);
			/* default debugging level */
			ptr = strstr(options, "-d:");
			if (START_OPTION(ptr, options))
				m_nDefaultDebugLevel = atoi(ptr+3);
			/* Quincy: run-time enabled */
			if ((ptr = strstr(options, "#runtime:")) != NULL)
				m_bRunTimeEnabled = m_bRunTimeEnabled && atoi(ptr+9);
			/* Quincy: debug enabled */
			if ((ptr = strstr(options, "#debug:")) != NULL)
				m_iDebuggerEnabled = m_iDebuggerEnabled & atoi(ptr+7);
			/* Quincy: max. optimization level supported */
			if ((ptr = strstr(options, "#optlevel:")) != NULL)
				m_iMaxOptimize = atoi(ptr+10);
			/* Quincy: overlays allowed */
			if ((ptr = strstr(options, "#overlay:")) != NULL)
				m_bOverlayEnabled = atoi(ptr+9);
		} /* while */
		ifile.close();
	} /* if */
}

bool CQuincyApp::SwitchWorkspace(LPCTSTR projectfile)
{
	/* close all current files (query for save) */
	SaveAllDocuments(true);
	if (m_ProjectFile.Compare(projectfile) != 0)
		SaveOpenDocuments();
	CloseAllDocuments(false);
	SaveProjectSettings();

	/* load workspace */
	m_ProjectFile = projectfile;
	CWnd* pWndFocus = RestoreOpenDocuments();
	if (pWndFocus != 0) {
		ASSERT_KINDOF(CMDIChildWnd, pWndFocus);
		CMainFrame* pMainFrame = static_cast<CMainFrame*>(m_pMainWnd);
		pMainFrame->MDIActivate(pWndFocus);
		pWndFocus->SetFocus();
	} /* if */

	((CMainFrame*)m_pMainWnd)->UpdateSymBrowser();

	/* change to the subdirectory where project file is located */
	int offset = m_ProjectFile.ReverseFind('\\');
	if (offset != -1)	{
		CString strPath = m_ProjectFile.Left(offset);
		_chdir(strPath);
	} /* if */

	/* load settings (with the project name set in m_ProjectFile) */
	LoadProjectSettings();
	LoadHostConfiguration();	/* also load the new configuration (if any) */
	InfoTip_ReadList();
	RebuildHelpMenu();
	#ifdef TYCPP
		LoadTutorials();
	#endif

	/* save the name of the current project */
	WriteProfileString("Options", "Project", m_ProjectFile);

	return true;
}

void CQuincyApp::OnFileOpen()
{
	static char BASED_CODE szFilter[] =
			"Pawn files (*.p, *.pawn, *.inc)"
			"|*.p; *.pawn; *.pwn; *.inc|"
			"All files (*.*)"
			"|*.*|"
			"|";

	CFileDialog dlg(true,
					0,
					0,
					OFN_HIDEREADONLY			|
					OFN_FILEMUSTEXIST			|
					OFN_ALLOWMULTISELECT	|
					OFN_NOCHANGEDIR				|
					OFN_ENABLESIZING			|
					OFN_PATHMUSTEXIST,
					szFilter,
					m_pMainWnd
					);

	// set the default directory to that of the currently active file
	CString strPath;
	BOOL maximize;
	CMDIChildWnd* pActive = GetMDIChild();	// without parameter -> returns active MDI child
	if (pActive) {
		CView* pActiveView = pActive->GetActiveView();
		ASSERT(pActiveView != 0);
		CDocument* pDoc = pActiveView->GetDocument();
		ASSERT(pDoc != 0);
		strPath = GetFilePath(pDoc->GetPathName());
		dlg.m_ofn.lpstrInitialDir = strPath;
	} /* if */

	// Provide space for a list with a max of at least 50 file names.
	CString fnameBuffer;
	const int bufSize = 50 *(_MAX_PATH + 1) + 1;
	dlg.m_ofn.nMaxFile = bufSize;
	dlg.m_ofn.lpstrFile = fnameBuffer.GetBuffer(bufSize);

	if (dlg.DoModal() == IDOK) {
		// check whether there exists an active window, always maximize the
		// view after loading the very first file
		if (pActive == 0)
			maximize = TRUE;

		// open the new window(s)
		CString filename;
		POSITION pos ( dlg.GetStartPosition() );
		while (pos) {
			filename = dlg.GetNextPathName(pos);
			OpenDocumentFile(filename);
		} /* while */

		if (maximize)
			MaximizeDocument(filename);	/* maximize last filename */
	} /* if */
}

void CQuincyApp::OnLoadworkspace()
{
	static char BASED_CODE szFilter[] =
			"Workspace files (*.qws)"
			"|*.qws|"
			"|";

	CFileDialog dlg(true,
					0,
					0,
					OFN_HIDEREADONLY	|
					OFN_FILEMUSTEXIST	|
					OFN_NOCHANGEDIR		|
					OFN_ENABLESIZING	|
					OFN_PATHMUSTEXIST,
					szFilter,
					m_pMainWnd
					);

	if (dlg.DoModal() == IDOK)
		SwitchWorkspace(dlg.GetPathName());
}

void CQuincyApp::OnSaveworkspace()
{
	static char BASED_CODE szFilter[] =
			"Workspace files (*.qws)"
			"|*.qws|"
			"|";

	CFileDialog dlg(false,
					0,
					0,
					OFN_NOCHANGEDIR		|
					OFN_PATHMUSTEXIST	|
					OFN_ENABLESIZING	|
					OFN_OVERWRITEPROMPT,
					szFilter,
					m_pMainWnd
					);

	if (dlg.DoModal() == IDOK) {
		m_ProjectFile = dlg.GetPathName();
		int idx;
		if ((idx = m_ProjectFile.ReverseFind('.')) < 0 || m_ProjectFile.Find('\\', idx) >= 0)
			m_ProjectFile += ".qws";

		WriteProfileString("Options", "Project", m_ProjectFile);
		SaveOpenDocuments();
		SaveProjectSettings();
	} /* if */
}

void CQuincyApp::OnCloseworkspace()
{
	/* close all current files (query for save) */
	SaveAllDocuments(true);
	SaveOpenDocuments();
	CloseAllDocuments(false);
	SaveProjectSettings();

	m_ProjectFile.Empty();
	WriteProfileString("Options", "Project", NULL);

	/* load workspace */
	CWnd* pWndFocus = RestoreOpenDocuments();
	if (pWndFocus != 0) {
		ASSERT_KINDOF(CMDIChildWnd, pWndFocus);
		CMainFrame* pMainFrame = static_cast<CMainFrame*>(m_pMainWnd);
		pMainFrame->MDIActivate(pWndFocus);
		pWndFocus->SetFocus();
	} /* if */

	((CMainFrame*)m_pMainWnd)->UpdateSymBrowser();

	/* load global settings */
	LoadProjectSettings();
	LoadHostConfiguration();
	InfoTip_ReadList();
	RebuildHelpMenu();
	#ifdef TYCPP
		LoadTutorials();
	#endif
}

void CQuincyApp::OnUpdateCloseworkspace(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsProjectActive());
}


void CQuincyApp::SetMenuCommand(int id)
{
	CMenu* pCMenu = ((CMainFrame*)(m_pMainWnd))->GetMenu();
	pCMenu->CheckMenuItem(id, MF_CHECKED);
}
void CQuincyApp::ResetMenuCommand(int id)
{
	CMenu* pCMenu = ((CMainFrame*)(m_pMainWnd))->GetMenu();
	pCMenu->CheckMenuItem(id, MF_UNCHECKED);
}

void CQuincyApp::OnFilePrintSetup()
{
	CQuincyPrintDialog pd(true);
	pd.printlinenumbers = m_bPrintLineNos;
	if (DoPrintDialog(&pd) == IDOK)
		m_bPrintLineNos = pd.printlinenumbers;
}

bool CQuincyApp::CompileRunning() const
{
	return m_pCompiler == 0 ? false : m_pCompiler->CompileRunning();
}

void CQuincyApp::CreateGdbConsole(BOOL Show, BOOL AutoClose)
{
	ASSERT(m_pdlgGdbConsole != 0);
	if (m_bGdbConsoleCreated != true)	{
		m_pdlgGdbConsole->Create(IDD_GDBCONSOLE);
		m_bGdbConsoleCreated = true;
	}
	if (Show)
		m_pdlgGdbConsole->ShowWindow(SW_SHOW);
	m_pdlgGdbConsole->SetAutoClose(AutoClose);
}

void CQuincyApp::OnViewGdbconsole()
{
	CreateGdbConsole(TRUE, FALSE);
	m_pdlgGdbConsole->SetFocus();
}

void CQuincyApp::DisplayGdbText(char* txt)
{
	if (m_pdlgGdbConsole != 0)	{
		if (m_bGdbConsoleCreated)	{
			char* cp = txt;
			while (*cp)	{
				if (*cp == '\t')
					*cp = ' ';
				cp++;
			}
			if (!appendnexttext)
				m_pdlgGdbConsole->AddString(txt);
			else	{
				m_pdlgGdbConsole->AppendString(" ");
				m_pdlgGdbConsole->AppendString(txt);
				appendnexttext = false;
			}
		}
	}
}

void CQuincyApp::ClearGdbConsole()
{
	if (m_pdlgGdbConsole != 0)
		if (m_bGdbConsoleCreated)
			m_pdlgGdbConsole->ClearConsole();
}

// --- put quotes around a file specification that has one or more spaces
//     so the file specification can be used on a command line
CString CQuincyApp::Enquote(const CString& str) const
{
	if (str[0] == '"' || str.Find(' ') == -1)
		return str;		// file spec is already quoted or has no spaces
	CString qstr("\"" + str);
	// if the spec ends with backslash, add another backslash
	if (qstr[qstr.GetLength()-1] == '\\')
		qstr += "\\";
	qstr += "\"";
	return qstr;
}

bool CQuincyApp::SelectFolder(const char* title, CString* strpath)
{
	bool rtn = false;
	std::string ttl("Select Folder for ");
	ttl += title;
	BROWSEINFO info = {
		0,
		0,
		0,
		ttl.c_str(),
		BIF_EDITBOX,
		0,
		0
	};
	LPITEMIDLIST idlist;
	idlist = SHBrowseForFolder(&info);
	if (idlist != 0)	{
		char path[MAX_PATH];
		if (SHGetPathFromIDList(idlist, path))	{
			*strpath = path;
			rtn = true;
		}
	}
	IMalloc* im = 0;
	if (SUCCEEDED(SHGetMalloc(&im)))	{
		im->Free(idlist);
		im->Release();
	}
	return rtn;
}

void CQuincyApp::RebuildHelpMenu()
{
	CMenu* pMenu = ((CMainFrame*)m_pMainWnd)->GetMenu();
	ASSERT(pMenu != 0);
	ASSERT(::IsMenu(pMenu->GetSafeHmenu()));

	/* create or re-create the index */
	if (m_HelpIndex)
		delete m_HelpIndex;
	m_HelpIndex = new CHelpIndex;

	/* see whether we can find the main help file */
	CString strPath = m_strInstallPath + "doc\\*.aux";
	WIN32_FIND_DATA ffd;
	HANDLE hFind = FindFirstFile(strPath, &ffd);
	int idx;
	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			/* get the name of the file, without extension */
			CString strHlpIndex = CString(ffd.cFileName);
			idx = strHlpIndex.Find('.');
			if (idx >= 0)
				strHlpIndex = strHlpIndex.Left(idx);
			CString strHelpFile = m_strInstallPath + "doc\\" + strHlpIndex + ".pdf";
			/* verify whether the associated PDF file exists */
			if (access(strHelpFile, 0) != 0)
				continue;	// not found, skip this file
			/* top menu should be general help on Quincy (this has menu ID ID_HELP) */
			CString tmpString = strHlpIndex;
			tmpString.MakeLower();
			if (tmpString.Find("quincy") < 0)
				continue;	// not the main help file, skip it
			/* process the index */
			m_HelpIndex->ScanFile(m_strInstallPath + "doc\\" + CString(ffd.cFileName), ID_HELP, strHelpFile);
			strHlpIndex.Replace('_', ' ');
			/* set this in the menu */
			pMenu->ModifyMenu(ID_HELP, MF_BYCOMMAND, ID_HELP, strHlpIndex);
			pMenu->EnableMenuItem(ID_HELP, MF_ENABLED | MF_BYCOMMAND);
			break;	// once found, no need to search further
		} while (FindNextFile(hFind, &ffd));
		FindClose(hFind);
	} /* if */

	/* delete all menu items for additional help files, these will be created 
	 * again while browsing through the files 
	 */
	int count;
	for (count = 0; count < 15; count++)
		pMenu->DeleteMenu(ID_HELP1 + count, MF_BYCOMMAND);

	// Look for "Help" menu.
	count = pMenu->GetMenuItemCount();
    CString ItemName;
	for (idx = 0; idx < count; idx++)
      if (pMenu->GetMenuString(idx, ItemName, MF_BYPOSITION) && stricmp(ItemName, "&help") == 0)
         break;
	ASSERT(idx < count);
	CMenu *submenu = pMenu->GetSubMenu(idx);

	CString HostDocPath = m_strInstallPath + "doc\\";
	if (!m_strTargetHost.IsEmpty())
		HostDocPath += m_strTargetHost + "\\";
	strPath = HostDocPath + "*.aux";
	hFind = FindFirstFile(strPath, &ffd);
	count = 0;
	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			/* get the name of the file, without extension */
			CString strHlpIndex = CString(ffd.cFileName);
			idx = strHlpIndex.Find('.');
			if (idx >= 0)
				strHlpIndex = strHlpIndex.Left(idx);
			CString strHelpFile = HostDocPath + strHlpIndex + ".pdf";
			/* verify whether the associated PDF file exists */
			if (access(strHelpFile, 0) != 0)
				continue;	// not found, skip this file
			/* top menu should be general help on Quincy (this has menu ID ID_HELP) */
			CString tmpString = strHlpIndex;
			tmpString.MakeLower();
			int id;
			if (tmpString.Find("quincy") >= 0)
				continue;	// already handled in the previous loop
			/* process the index */
			m_HelpIndex->ScanFile(HostDocPath + CString(ffd.cFileName), ID_HELP1 + count, strHelpFile);
			strHlpIndex.Replace('_', ' ');
			/* set this in the menu */
			submenu->InsertMenu(count + 1, MF_BYPOSITION | MF_STRING | MF_ENABLED, ID_HELP1 + count, strHlpIndex);
			count += 1;
		} while (FindNextFile(hFind, &ffd));
		FindClose(hFind);
	} /* if */
}

void CQuincyApp::OpenHelp(const char* bookmark)
{
	std::map<const char*,int> *filenames = NULL;

	/* find all document files that contain the bookmark */
	ASSERT(m_HelpIndex);
	if (bookmark && !isdigit(*bookmark)) {
		filenames = m_HelpIndex->LookUp(bookmark);
		if (filenames->size() == 0 && strchr(bookmark,'@') != NULL) {
			/* try after replacing @ */
			CString cooked = bookmark;
			cooked.Replace("@", "at");
			filenames = m_HelpIndex->LookUp(cooked);
		} /* if */
	} /* if */
	/* - if there are zero matches, open the default help file
	 * - if there is one match, use that
	 * - if there are more than one matches, pop up a selection dialog
	 */
	std::string filename;
	int page = 0;
	if (filenames == NULL || filenames->size() == 0) {
		filename = m_HelpIndex->LookUp(ID_HELP);
	} else if (filenames->size() == 1) {
		std::map<const char*,int>::iterator p = filenames->begin();
		filename = p->first;
		page = p->second;
	} else {
		// pop up a dialog, to have the user select the document
		CDocFileSelect *DocFile = new CDocFileSelect;
		DocFile->SetFilemap(filenames);
		if (DocFile->DoModal() == IDOK) {
			filename = DocFile->GetDocumentFile(&page);
		} /* if */
		delete DocFile;
	} /* if */
	if (filenames) {
		filenames->clear();
		delete filenames;
	} /* if */
	if (filename.empty())
		return;	/* no file, quit */

	if (!m_PdfReader)
		m_PdfReader = new CReaderWrapper(filename.c_str());
	ASSERT(m_PdfReader);
	m_PdfReader->SetAutoClose(TRUE);
	m_PdfReader->DocOpen(filename.c_str());

	if (page > 0)
		m_PdfReader->GoToPage(page);
}

void CQuincyApp::OpenHelp(int menu_id)
{
	const char *filename = m_HelpIndex->LookUp(menu_id);
	if (!filename)
		return;	/* no file, quit */

	if (!m_PdfReader)
		m_PdfReader = new CReaderWrapper(filename);
	ASSERT(m_PdfReader);
	m_PdfReader->SetAutoClose(TRUE);
	m_PdfReader->DocOpen(filename);
}

void CQuincyApp::CloseErrorLog()
{
	if (m_pCompiler != 0)
		m_pCompiler->CloseErrorLog();
}

bool CQuincyApp::IsRGBmode() const
{
	HDC hdc=::GetDC(0);
	int bits=::GetDeviceCaps(hdc,BITSPIXEL);
	int planes=::GetDeviceCaps(hdc,PLANES);
	::ReleaseDC(0,hdc);
	bits *= planes;       /* bits == flat number of bits per pixel */
	return bits > 8;
}

void CQuincyApp::NoticeChangedFile(const CString &path)
{
	if (theApp.GetCompiler()) {
		CErrorLogDialog *dlg = theApp.GetCompiler()->GetErrorLog();
		if (dlg != 0) {
			CString str = path;
			// retain only filename of the path
			int skip = str.ReverseFind('\\');
			if (skip >= 0)
				str.Delete(0, skip + 1);
			CString msg;
			msg.Format("Notice: source file \"%s\" was modified since last compile", str);
			dlg->AddBuildMessage(msg);
		} /* if */
	} /* if */
}

// --- info tips
void CQuincyApp::InfoTip_ReadList()
{
	InfoTipList.clear();	/* delete any current contents */

	std::string pathname;
	pathname = m_strInstallPath + "doc\\";
	if (!m_strTargetHost.IsEmpty())
		pathname += m_strTargetHost + "\\";
	pathname += "infotips.lst";
	std::ifstream flst;
	flst.open(pathname.c_str());
	if (!flst)
		return;

	std::string line;
	while (std::getline(flst, line)) {
		while (line[0] != '\0' && line[0] <= ' ')
			line.erase(0, 1);
		int eol = line.find('\n', 0);
		if (eol != std::string::npos)
			line.erase(eol);
		if (line.length() != 0 && line[0] != '#') {
			/* get the keyword from the line */
			int paren;
			if (line[0] == '@') {
				paren = line.find(')', 0);	/* use complete function definition for public functions */
				if (paren != std::string::npos)
					paren++;
			} else {
				paren = line.find('(', 0);	/* use only the function name */
			} /* if */
			if (paren == std::string::npos) {
				paren = line.find(' ', 0);
				if (paren != std::string::npos && paren > 0 && line[paren - 1] == ':')
					paren = line.find(' ', paren + 1);
			} /* if */
			if (paren != std::string::npos) {
				/* extract the function name from the line */
				std::string keyword;
				int skip = line.find(':', 0);
				if (skip != std::string::npos && skip < paren) {
					while (line[++skip] == ' ')
						/* nothing */;
				} else {
					skip = 0;
				} /* if */
				keyword = line.substr(skip, paren - skip);
				/* reformat the line somewhat */
				if (line[paren] == '(')
					paren = line.find(')', paren);
				if (paren != std::string::npos) {
					if (line[paren] == ')')
						paren++;
					while (line[paren] != '\0' && line[paren] <= ' ')
						line.erase(paren, 1);
					line.insert(paren, "</b><br>");
					line.insert(0, "<b>");
				} /* if */
				/* add it to the list */
				InfoTipList.insert(std::make_pair(keyword, line));
			} /* if */
		} /* if */
    } /* while */
	flst.close();
}

/* Find only an exact match (after removing the parameter list for public functions).
 * Look through the special "info" files (for native function libraries) and
 * generated XML report files.
 */
const std::string CQuincyApp::InfoTip_Lookup(const std::string keyword)
{
	std::map<std::string,std::string>::iterator iter = InfoTipList.begin();
	while (iter != InfoTipList.end()) {
		std::string key = iter->first;
		if (key[0] == '@') {
			int paren = key.find('(', 0);
			if (paren != std::string::npos)
				key = key.substr(0, paren);
		} /* if */
		if (key.compare(keyword) == 0)
			return iter->second;
		iter++;
	} /* while */
	
	/* not found in the "info" files, see whether the symbol browser has it */
	CString symbol = keyword.c_str();
	CString syntax;
	CString summary;
	int result = ((CMainFrame*)m_pMainWnd)->LookupSymbol(symbol, NULL, NULL, &syntax, &summary);
	if (result > 0) {
		std::string str = syntax.GetBuffer();
		str = "<b>" + str + "</b>";
		if (summary.GetLength() > 0)
			str = str + "<br>" + summary.GetBuffer();
		return str;
	} /* if */

	return std::string("");
}

/* find a partial match */
const std::vector<std::string> CQuincyApp::InfoTip_Match(const std::string keyword)
{
	std::vector<std::string> result;
	result.clear();

	int length = keyword.length();
	std::map<std::string,std::string>::iterator iter = InfoTipList.begin();
	while (iter != InfoTipList.end()) {
		std::string key = iter->first;
		if (key.length() > length && key.compare(0, length, keyword) == 0)
			result.push_back(iter->first);
		iter++;
	} /* while */
	std::sort(result.begin(), result.end());
	return result;
}

// --- info tips
void CQuincyApp::ErrorTip_ReadList()
{
	ErrorTipList.clear();	/* delete any current contents */

	std::string pathname;
	pathname = m_strInstallPath + "doc\\";
	if (!m_strTargetHost.IsEmpty())
		pathname += m_strTargetHost + "\\";
	pathname += "messages.lst";
	std::ifstream flst;
	flst.open(pathname.c_str());
	if (!flst)
		return;

	int error = 0;
	std::string line;
	std::string fulltext = "";
	while (std::getline(flst, line)) {
		while (line[0] != '\0' && line[0] <= ' ')
			line.erase(0, 1);
		int eol = line.find('\n', 0);
		if (eol != std::string::npos)
			line.erase(eol);
		if (line.length() > 1 && line[0] == '#') {
			if (error > 0)
				ErrorTipList.insert(std::make_pair(error, fulltext));
			fulltext = "";
			error = strtol(line.c_str() + 1, NULL, 10);
			ASSERT(error > 0);
		} else {
			if (fulltext.length() > 0 && line.length() > 0)
				fulltext += " ";
			fulltext += line;
		} /* if */
    } /* while */
	/* add last item */
	if (error > 0)
		ErrorTipList.insert(std::make_pair(error, fulltext));
	flst.close();
}

/* Find only an exact match (after removing the parameter list for public functions) */
const std::string CQuincyApp::ErrorTip_Lookup(int error)
{
	std::map<int,std::string>::iterator iter = ErrorTipList.begin();
	while (iter != ErrorTipList.end()) {
		if (iter->first == error)
			return iter->second;
		iter++;
	} /* while */
	return std::string("");
}
