// SnippetsOptions.cpp : implementation file
// $Id: SnippetsOptions.cpp 3982 2008-07-18 10:34:09Z thiadmer $

#include "stdafx.h"
#include "quincy.h"
#include "SnippetsOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSnippetsOptions dialog


CSnippetsOptions::CSnippetsOptions(CWnd* pParent /*=NULL*/)
	: CPropertyPage(CSnippetsOptions::IDD)
{
	//{{AFX_DATA_INIT(CSnippetsOptions)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSnippetsOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSnippetsOptions)
	DDX_Control(pDX, IDC_SNIPPETLIST, m_List);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSnippetsOptions, CPropertyPage)
	//{{AFX_MSG_MAP(CSnippetsOptions)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_SNIPPETLIST, OnItemchangedSnippetlist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSnippetsOptions message handlers

BOOL CSnippetsOptions::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_InitDone = false;

	// set the columns in the list view
	CRect rect;
	m_List.GetClientRect(&rect);
	int width = rect.right / 4;
	m_List.InsertColumn(0, _T("Shorthand"), LVCFMT_LEFT, width);
	m_List.InsertColumn(1, _T("Replacement"), LVCFMT_LEFT, rect.right - width - 16);
	
	// insert the snippet items
	m_List.DeleteAllItems();
	std::map<std::string,std::string>::iterator iter;
	for (iter = Snippets.List.begin(); iter != Snippets.List.end(); iter++) {
		int index = m_List.InsertItem(m_List.GetItemCount(), iter->first.c_str());
		CString repl = iter->second.c_str();
		Snippets.translatespecials(repl, false);
		m_List.SetItemText(index, 1, repl);
	} /* for */

	/* add one more item for adding snippets */
	m_List.InsertItem(m_List.GetItemCount(), "");

	m_List.SetGridLines(TRUE);
	m_List.SetEditable(TRUE);
	m_List.SetSortSeparator("");	// to keep the empty entry at the bottom

	m_InitDone = true;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSnippetsOptions::OnItemchangedSnippetlist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	if (m_InitDone) {
		// see whether the bottom item was filled in, if so, add another (empty) item
		bool additem = true;
		int count = m_List.GetItemCount();
		if (count > 0) {
			CString keyword = m_List.GetItemText(count - 1, 0);
			if (keyword.GetLength() == 0)
				additem = false;
		} /* if */

		if (additem)
			m_List.InsertItem(count, "");
	} /* if */

	*pResult = 0;
}

void CSnippetsOptions::OnOK() 
{
	m_List.EndEdit(TRUE);	/* make sure last edit is saved */

	/* copy the listview items back into the structure */
	Snippets.clear();
	int count = m_List.GetItemCount();
	for (int idx = 0; idx < count; idx++) {
		CString keyword = m_List.GetItemText(idx, 0);
		if (keyword.GetLength() > 0) {
			CString repl = m_List.GetItemText(idx, 1);
			Snippets.insert(keyword, repl, true);
		} /* if */
	} /* for */

	CPropertyPage::OnOK();
}
