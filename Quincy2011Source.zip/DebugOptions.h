#if !defined(AFX_DEBUGOPTIONS_H__55B7264A_5F49_4779_BB38_A8D58B77B728__INCLUDED_)
#define AFX_DEBUGOPTIONS_H__55B7264A_5F49_4779_BB38_A8D58B77B728__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DebugOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDebugOptions dialog

class CDebugOptions : public CPropertyPage
{
// Construction
public:
	CDebugOptions(CWnd* pParent = 0);  // standard constructor

// Dialog Data
	//{{AFX_DATA(CDebugOptions)
	enum { IDD = IDD_DEBUG_PROPERTIES };
	BOOL	m_AutoTransfer;
	int		m_DebugBaudrate;
	int		m_Local;
	BOOL	m_EnableLog;
	//}}AFX_DATA
	int		m_DebugPort;


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDebugOptions)
	public:
	virtual BOOL OnSetActive();
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDebugOptions)
	afx_msg void OnDbgLocal();
	afx_msg void OnDbgSerial();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEBUGOPTIONS_H__55B7264A_5F49_4779_BB38_A8D58B77B728__INCLUDED_)
