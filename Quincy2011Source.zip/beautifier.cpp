// Beautifer.cpp : implementation file
// $Id: beautifier.cpp 4063 2009-01-26 12:14:22Z thiadmer $

#include "stdafx.h"
#include "quincy.h"
#include "Beautifier.h"
#include "EditorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CBeautifier* CBeautifier::pBeautifier;

/////////////////////////////////////////////////////////////////////////////
// CBeautifier dialog


CBeautifier::CBeautifier(CWnd* pParent /*=NULL*/)
	: CDialog(CBeautifier::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBeautifier)
	//}}AFX_DATA_INIT
	m_configfile = _T("");
	m_style = 0;
	font = new CFont;
	theApp.EditorScreenFont(font);
	m_pConsoleApp = 0;
}

CBeautifier::~CBeautifier()
{
	delete font;
}

void CBeautifier::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBeautifier)
	DDX_Control(pDX, IDC_BEAUTIFYSTYLE, m_BeautifyStyle);
	DDX_Control(pDX, IDC_SAMPLECODE, m_samplecode);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CBeautifier, CDialog)
	//{{AFX_MSG_MAP(CBeautifier)
	ON_BN_CLICKED(IDC_TESTSTYLE, OnStyle)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_CBN_SELCHANGE(IDC_BEAUTIFYSTYLE, OnSelchangeBeautifystyle)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CBeautifier::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_samplecode.SetFont(font, FALSE);
	UpdateData(false);

	// find all target configuration files (keep in an array)
	configfiles.clear();
	CFileFind finder;
	CString path = theApp.ToolsPath();
	BOOL bWorking = finder.FindFile(path + "uncrustify*.cfg");
	while (bWorking) {
		bWorking = finder.FindNextFile();
		CString name = finder.GetFileName();	// base name
		CString filename = path + name;			// full path
		configfiles.push_back(filename);
		// strip off the initial part "uncrustify"
		ASSERT(name.Left(10).CompareNoCase("uncrustify") == 0);
		name = name.Mid(10);
		if (name[0] == '_' || name[0] == '-')
			name = name.Mid(1);
		// strip the extension
		int pos = name.Find(".cfg");
		ASSERT(pos >= 0);						// must be found, we searched for this extension
		name = name.Left(pos);
		// replace underscores with spaces
		while ((pos = name.Find('_')) >= 0)
			name = name.Left(pos) + " " + name.Mid(pos + 1);
		int idx = m_BeautifyStyle.AddString(name);
	} /* while */
	m_BeautifyStyle.SetCurSel(m_style);

	OnStyle();
	return TRUE;
}

static char* style[] = {
	"sort2(&item1, &item2)",
	"{",
	"\tnew tmp",
	"\tif (item1 > item2) {",
	"\t\ttmp = item1",
	"\t\titem1 = item2",
	"\t\titem2 = tmp",
	"\t}",
	"}",
	0
};

/////////////////////////////////////////////////////////////////////////////
// CBeautifier message handlers

void CBeautifier::OnSelchangeBeautifystyle() 
{
	m_style = m_BeautifyStyle.GetCurSel();
	OnStyle();
}

void CBeautifier::OnStyle() 
{
	UpdateData();

	if (m_style < 0 || m_style >= configfiles.size())
		m_style = 0;

	pBeautifier = this;
	beautifiedtext.clear();
	CString strExe = theApp.Enquote(theApp.QuincyBinPath() + "\\uncrustify.exe ");

	CString strArgs;
	ASSERT(m_style < configfiles.size());
	m_configfile = configfiles[m_style];
	strArgs.Format("-l PAWN -q -c \"%s\"", m_configfile);

	delete m_pConsoleApp;
	m_pConsoleApp = new ConsoleApp(strExe, &Notify, &Collect);
	try	{
		m_pConsoleApp->Run(strArgs);

		int lines = sizeof style / sizeof(char*) - 1;
		if (lines != 0) {
			for (int i = 0; i < lines; i++) {
				std::string str = style[i];
				m_pConsoleApp->WriteConsole(str.c_str());
				TRACE("\nOUT: %s", str.c_str());
			}
		}
		char ctrlz[2] = {26,0};
		m_pConsoleApp->WriteConsole(ctrlz);
	}
	catch(...)	{
		AfxMessageBox("\nCannot execute the beautifier \"Uncrustify\".", MB_ICONSTOP);
	}
}

void CBeautifier::OnHelp() 
{
	ShellExecute(0, "open", (theApp.ToolsInstallPath() + "doc\\uncrustify.html").GetBuffer(0), 0, 0, SW_SHOW);
}

// --- called from the console application thread while beautifying is going on
void CBeautifier::Collect(DWORD bufct)
{
	ASSERT(pBeautifier != 0);
	pBeautifier->CollectSourceLines(bufct);
}

void CBeautifier::CollectSourceLines(DWORD bufct)
{
	char *line = new char[bufct+1];
	ASSERT(m_pConsoleApp);
	if (m_pConsoleApp->ReadConsole(line, bufct) != 0)	{
		TRACE("\nIN:  %s", line);
		std::string str(line);
		beautifiedtext.push_back(str);
	}
	delete [] line;
}

void CBeautifier::Notify()
{
	ASSERT(pBeautifier != 0);
	pBeautifier->NotifyTermination();
}

void CBeautifier::NotifyTermination()
{
	TRACE("\n---done---\n");
	beautifiedtext.push_back(std::string());

	int tabs = theApp.Tabstops();
	char text[800];
	int n = 0;
	std::vector<std::string>::iterator iter;
	for (iter = beautifiedtext.begin(); iter != beautifiedtext.end(); iter++)	{
		int x = 0;
		const char* cp;
		for (cp = (*iter).c_str(); *cp; cp++)	{
			if (*cp == '\t')	{
				do
					text[n++] = ' ';
				while (++x % tabs);
			}
			else	{
				text[n++] = *cp;
				x++;
			}
		}
		text[n++] = '\n';
	}
	text[n] = '\0';
	m_samplecode.SetWindowText(text);
	beautifiedtext.clear();

	delete m_pConsoleApp;
	m_pConsoleApp = 0;
	pBeautifier = 0;
}

