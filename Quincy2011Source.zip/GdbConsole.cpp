// GdbConsole.cpp : implementation file
// $Id: GdbConsole.cpp 3787 2007-07-04 10:27:06Z thiadmer $

#include "stdafx.h"
#include "quincy.h"
#include "GdbConsole.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GdbConsole dialog


GdbConsole::GdbConsole(CWnd* pParent)
	: CDialog(GdbConsole::IDD, pParent)
{
	//{{AFX_DATA_INIT(GdbConsole)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	AutoClose = FALSE;

	fntMono.CreateFont(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, 
						ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
						DEFAULT_QUALITY, FIXED_PITCH | FF_DONTCARE, "Andante");
}


void GdbConsole::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GdbConsole)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

	CListBox* pList = static_cast<CListBox*>(GetDlgItem(IDC_GDBSTDIO));
	pList->SetFont(&fntMono);

}


BEGIN_MESSAGE_MAP(GdbConsole, CDialog)
	//{{AFX_MSG_MAP(GdbConsole)
		// NOTE: the ClassWizard will add message map macros here
	ON_WM_DESTROY()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void GdbConsole::scroll(CListBox* pList)
{
	pList->SetTopIndex(pList->GetCount() - 10);
}

/////////////////////////////////////////////////////////////////////////////
// GdbConsole message handlers

void GdbConsole::AddString(const char* str)
{
	CListBox* pList = static_cast<CListBox*>(GetDlgItem(IDC_GDBSTDIO));
	pList->AddString(str);
	scroll(pList);
}

void GdbConsole::AppendString(const char* str)
{
	CListBox* pList = static_cast<CListBox*>(GetDlgItem(IDC_GDBSTDIO));
	ASSERT(pList != 0);
	int count = pList->GetCount();
	if (count == 0)
		pList->AddString(str);
	else	{
		CString txt;
		pList->GetText(--count, txt);
		pList->DeleteString(count);
		txt += str;
		pList->AddString(txt);
	}
	scroll(pList);
}

void GdbConsole::OnDestroy()
{
	theApp.SaveDialogWindowPosition("GdbWindow", this);
	AutoClose = FALSE;
	CDialog::OnDestroy();
}

int GdbConsole::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	theApp.RestoreDialogWindowPosition("GdbWindow", this);
	return 0;
}

void GdbConsole::ClearConsole()
{
	CListBox* pList = static_cast<CListBox*>(GetDlgItem(IDC_GDBSTDIO));
	pList->ResetContent();
}
