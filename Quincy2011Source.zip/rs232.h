/* RS-232 class
 *
 * Written by ITB CompuPhase, 2009
 */
#ifndef RS232_H
#define RS232_H

#if !defined sizearray
# define sizearray(e)     (sizeof(e) / sizeof((e)[0]))
#endif


class RS232 {
public:
  RS232() { handlePort=INVALID_HANDLE_VALUE; }

  BOOL Open(int port=0,int baud=0,int databits=8,int stopbits=1,int parity=0,int flowctrl=Flow_None);
  BOOL Close();
  size_t PutData(const unsigned char *buffer, size_t length);
  size_t GetData(unsigned char *buffer, size_t maxlength);
  void EscapeCommFunction(int command);

  int GetPort()       const { return Port; }
  int GetBaud()       const { return Baud; }
  int GetDataBits()   const { return Data; }
  int GetStop()       const { return Stop; }
  int GetParity()     const { return Parity; }
  int GetHandshake()  const { return FlowCtrl; }
  BOOL IsOpen()       const { return handlePort != INVALID_HANDLE_VALUE; }

  enum {
    Flow_None,
    Flow_RtsCts,
    Flow_DtrDsr,
    Flow_XonXoff,
    /* ----- */
    Flow_Count
  };

private:
  int Port;
  int Baud;
  int Data;
  int Stop;
  int Parity;
  int FlowCtrl;
  HANDLE handlePort;

  HANDLE InternalOpen();
};

#endif /* RS232_H */
