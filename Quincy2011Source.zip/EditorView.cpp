// EditorView.cpp : implementation of the CEditorView class
// $Id: EditorView.cpp 4535 2011-07-07 09:15:22Z thiadmer $

#include "stdafx.h"
#include <string>
#include <cassert>
#include <algorithm>
#include "Quincy.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "EditorDoc.h"
#include "EditorView.h"
#include "QuincyPrintDialog.h"
#include "Beautifier.h"
#include "Debugger.h"
#include "GotoLineDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define PRINTMARGIN 2

static HighlightPosition MatchingBraceParen;
bool CEditorView::InfoTipAutoRemove = false;
bool CEditorView::InfoTipEnable = true;


/////////////////////////////////////////////////////////////////////////////
// EditorSelection

EditorSelection::EditorSelection(CEditorView& view)
                    : sel::Selection<ViewIndex, CEditorView>(view)
{
}

/////////////////////////////////////////////////////////////////////////////
// ViewIndex

ViewIndex& ViewIndex::operator=(const ViewIndex& view)
{
    if (this != &view)  {
        pView = view.pView;
        row = view.row;
        column = view.column;
    }
    return *this;
}
bool ViewIndex::operator==(const ViewIndex& view) const
{
    return pView == view.pView && row == view.row && column == view.column;
}
bool ViewIndex::operator<(const ViewIndex& view) const
{
    if (pView == 0 && view.pView != 0)
        return true;
    if (pView != 0 && view.pView == 0)
        return false;
    if (row == view.row)
        return column < view.column;
    return row < view.row;
}


/////////////////////////////////////////////////////////////////////////////
// CEditorView

CFindReplaceDialog* CEditorView::m_pFindDlg;
std::string CEditorView::m_findtext;
std::string CEditorView::m_replacetext;
int CEditorView::m_nfrflags;
CEditorView* CEditorView::pEditor;

bool CEditorView::CodeElement::operator<(const struct CodeElement& ce) const
{
    if (line == ce.line)
        return (charpos < ce.charpos);
    return line < ce.line;
}


IMPLEMENT_DYNCREATE(CEditorView, CView)

static UINT WM_FINDREPLACE = ::RegisterWindowMessage(FINDMSGSTRING);

BEGIN_MESSAGE_MAP(CEditorView, CView)
    //{{AFX_MSG_MAP(CEditorView)
    ON_WM_VSCROLL()
    ON_WM_HSCROLL()
    ON_WM_KILLFOCUS()
    ON_WM_SETFOCUS()
    ON_WM_LBUTTONDOWN()
    ON_WM_LBUTTONDBLCLK()
    ON_WM_KEYDOWN()
    ON_WM_KEYUP()
    ON_WM_CHAR()
    ON_WM_LBUTTONUP()
    ON_WM_MOUSEMOVE()
    ON_WM_MOUSEWHEEL()
    ON_WM_TIMER()
    ON_WM_SYSKEYDOWN()
    ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
    ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
    ON_COMMAND(ID_EDIT_CUT, OnEditCut)
    ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
    ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
    ON_UPDATE_COMMAND_UI(ID_EDIT_CLEAR, OnUpdateEditClear)
    ON_COMMAND(ID_EDIT_CLEAR, OnEditClear)
    ON_COMMAND(ID_EDIT_SELECT_ALL, OnEditSelectAll)
    ON_COMMAND(ID_EDIT_FIND, OnEditFind)
    ON_COMMAND(ID_EDIT_REPLACE, OnEditReplace)
    ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
    ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
    ON_COMMAND(ID_RECORD, OnRecord)
    ON_COMMAND(ID_STOPRECORD, OnStopRecord)
    ON_WM_SETCURSOR()
    ON_UPDATE_COMMAND_UI(ID_PLAYBACK, OnUpdatePlayback)
    ON_UPDATE_COMMAND_UI(ID_RECORD, OnUpdateRecord)
    ON_UPDATE_COMMAND_UI(ID_STOPRECORD, OnUpdateStopRecord)
    ON_COMMAND(ID_PLAYBACK, OnPlayback)
    ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
    ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
    ON_UPDATE_COMMAND_UI(ID_EDIT_FIND_NEXT, OnUpdateEditFindNext)
    ON_COMMAND(ID_EDIT_FIND_NEXT, OnEditFindNext)
    ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_ALL, OnUpdateFileSaveAll)
    ON_UPDATE_COMMAND_UI(ID_BRACEMATCH, OnUpdateBracematch)
    ON_COMMAND(ID_BRACEMATCH, OnBracematch)
    ON_UPDATE_COMMAND_UI(ID_ASTYLE, OnUpdateBeautify)
    ON_COMMAND(ID_ASTYLE, OnBeautify)
    ON_COMMAND(ID_HELP, OnHelp)
    ON_COMMAND(ID_FILE_PRINT_PREVIEW, OnFilePrintPreview)
    ON_COMMAND(IDC_GOTOLINE, OnGotoline)
    ON_COMMAND(ID_GOTOSYMBOL, OnGotoSymbol)
    ON_COMMAND(ID_AUTOCOMPLETE, OnAutocomplete)
    ON_COMMAND(IDM_TAB2SPACE, OnTab2Space)
    ON_COMMAND(IDM_INDENTTABS, OnIndentTabs)
    ON_COMMAND(IDM_SPACE2TAB, OnSpace2Tab)
    //}}AFX_MSG_MAP
    // Standard printing commands
    ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
    ON_REGISTERED_MESSAGE(WM_FINDREPLACE, OnFindReplace)
END_MESSAGE_MAP()

#if 0
// C/C++ keywords
std::string CEditorView::ckeys[] = {
        "#define",
        "#elif",
        "#else",
        "#endif",
        "#error",
        "#if",
        "#ifdef",
        "#ifndef",
        "#include",
        "#line",
        "#pragma",
        "#undef",
        "asm",
        "auto",
        "bool",
        "break",
        "case",
        "char",
        "const",
        "continue",
        "default",
        "do",
        "double",
        "else",
        "enum",
        "extern",
        "float",
        "for",
        "goto",
        "if",
        "int",
        "long",
        "register",
        "return",
        "short",
        "signed",
        "sizeof",
        "static",
        "struct",
        "switch",
        "typedef",
        "union",
        "unsigned",
        "void",
        "volatile",
        "while"
};
// C++ keywords
std::string CEditorView::cppkeys[] = {
        "and",
        "and_eq",
        "bitand",
        "bitor",
        "catch",
        "class",
        "compl",
        "const_cast",
        "delete",
        "dynamic_cast",
        "explicit",
        "false",
        "friend",
        "inline",
        "mutable",
        "namespace",
        "new",
        "not",
        "not_eq",
        "operator",
        "or",
        "or_eq",
        "private",
        "protected",
        "public",
        "reinterpret_cast",
        "static_cast",
        "template",
        "this",
        "throw",
        "true",
        "try",
        "typeid",
        "typename",
        "using",
        "virtual",
        "wchar_t",
        "xor",
        "xor_e"
};
#else
// Pawn keywords
std::string CEditorView::pawnkeywords[] = {
        "assert",
        "break",
        "case",
        "char",
        "const",
        "bitor",
        "continue",
        "default",
        "defined",
        "do",
        "else",
        "enum",
        "exit",
        "for",
        "forward",
        "goto",
        "if",
        "native",
        "new",
        "operator",
        "public",
        "return",
        "sizeof",
        "sleep",
        "state",
        "static",
        "stock",
        "switch",
        "tagof",
        "while",
};
// Pawn directives
std::string CEditorView::pawndirectives[] = {
        "#assert",
        "#define",
        "#else",
        "#elseif",
        "#endif",
        "#endinput",
        "#endscript",
        "#error",
        "#file",
        "#if",
        "#include",
        "#line",
        "#pragma",
        "#section",
        "#tryinclude",
        "#undef",
};

// Pawn operators
char CEditorView::pawnoperators[] = "+-*/|&^!=<>~%?:[]{},";

#endif

bool CEditorView::is_keyword(const char *ptr, int len)
{
    int i;
    for (i = 0; i < sizeof(pawnkeywords) / sizeof(std::string); i++)
        if (strlen(pawnkeywords[i].c_str())==len && strncmp(ptr,pawnkeywords[i].c_str(),len)==0)
            return true;
    for (i = 0; i < sizeof(pawndirectives) / sizeof(std::string); i++)
        if (strlen(pawndirectives[i].c_str())==len && strncmp(ptr,pawndirectives[i].c_str(),len)==0)
            return true;
    return false;
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView construction/destruction

CEditorView::CEditorView()
{
    m_pscreenfont = 0;
    m_pConsoleApp = 0;
    m_pClearBrush = 0;
    m_pMarginBrush = 0;
    m_crClear = RGB(255,255,255);
    m_pFindDlg = 0;
    m_fontheight = theApp.FontHeight();
    m_fontweight = theApp.FontWeight();
    m_leftcolumn = 0;
    m_toprow = 0;
    m_bottomrow = 0;
    m_windowrows = 0;
    m_windowcolumns = 0;
    m_currentrow = 0;
    m_currentcolumn = 0;
    m_margin = theApp.GetMargin() * 8;// m_fontwidth;
    m_ctrldown = false;
    m_shiftdown = false;
    m_pEditorSelection = new EditorSelection(*this);
    m_mousemarking = false;
    m_dragging = false;
    m_recording = false;
    m_selectionmarked = false;
    ((CMainFrame*)theApp.m_pMainWnd)->SetRowColumn(1, 1);
    m_hOldCursor = 0;
    m_hMoveCursor = theApp.LoadCursor(IDC_POINTER_MOVE);
    m_hCopyCursor = theApp.LoadCursor(IDC_POINTER_COPY);
    m_hRecordCursor = theApp.LoadCursor(IDC_POINTER_RECORD);
    m_hArrowCursor  = theApp.LoadStandardCursor(IDC_ARROW);
    m_nfrflags = FR_DOWN | FR_MATCHCASE;
    m_buildcomments = true;
    m_linelength = 0;
    m_linecount = 0;
    m_linescount = 0;
    m_charcount = 0;
    m_inccomment = false;
    m_incppcomment = false;
    m_instringliteral = false;
    m_incharliteral = false;
    m_found = false;
    m_wasfound = false;
    m_bchanged = false;
}

CEditorView::~CEditorView()
{
    delete m_pConsoleApp;
    delete m_pClearBrush;
    delete m_pMarginBrush;
    delete m_pEditorSelection;
    delete m_pFindDlg;
    delete m_pscreenfont;
    DeleteMacros();
}

BOOL CEditorView::PreCreateWindow(CREATESTRUCT& cs)
{
    cs.style |= WS_HSCROLL | WS_VSCROLL;
    return CView::PreCreateWindow(cs);
}

void CEditorView::RebuildFont()
{
    DWORD size;
    delete m_pscreenfont;
    m_pscreenfont = new CFont;
    m_fontweight = theApp.FontWeight();
    size = theApp.EditorScreenFont(m_pscreenfont, theApp.FontFace(), theApp.FontHeight(), m_fontweight);
    m_fontwidth = LOWORD(size);
    m_fontheight = HIWORD(size);
    theApp.SetFontHeight(m_fontheight);
    theApp.SetFontWeight(m_fontweight);
    CreateSolidCaret(2, m_fontheight);
    SetScrollPosition(SB_VERT, m_toprow);
    SetCaretPosition();
    AdjustScroll();
}

BOOL CEditorView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
    bool rtn = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

    // --- register with parent frame class
    CChildFrame* pParent = (CChildFrame*)GetParentFrame();
    ASSERT(pParent != 0);
    pParent->RegisterView(this);

    m_crClear = RGB(255,255,255);
    m_pClearBrush = new CBrush(m_crClear);
    m_pMarginBrush = new CBrush(RGB(192,192,192));

    RebuildFont();
    InfoTip.CreateTipWnd(this);
    InfoTip.SetCallback(InfoCallback, this);
	InfoTipEnable = true;

    return rtn;
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView drawing

void CEditorView::AddColorToTable(int line, int charpos, COLORREF clr)
{
    CodeElement ce = {line, charpos, clr};

    std::set<CodeElement>::iterator it = m_contexttable.find(ce);
    if (it != m_contexttable.end())
        m_contexttable.erase(it);
    m_contexttable.insert(ce);
    m_prevcolor = clr;
}

int CEditorView::GetNextSourceChar()
{
    if (m_charcount >= m_linelength)    {
        // --- end of line
        KeywordSearch(false);
        NumberSearch(false);
        if (m_incppcomment) {
            // --- end of C++ comment is at end of line
            m_incppcomment = false;
            m_prevcolor = theApp.NormalColor();
        }
        m_incharliteral = false;
        m_charcount = 0;
        if (m_linecount >= m_linescount)
            return -1;
        AddColorToTable(m_linecount, 0, m_prevcolor);
        m_linestr = GetDocument()->textline(m_linecount++);
        m_linelength = m_linestr.length();
    }
    return m_linestr[m_charcount++];
}

void CEditorView::KeywordSearch(bool decrement)
{
    if (kword.length() > 0) {
        if (keywords.find(kword) != keywords.end()) {
            int ln = m_linecount-1;
            int col = m_charcount - (int)decrement;
            AddColorToTable(ln, col-kword.length(), theApp.KeywordColor());
            AddColorToTable(ln, col, theApp.NormalColor());
        }
        kword.erase();
    }
}

void CEditorView::NumberSearch(bool decrement)
{
    if (nword.length() > 0) {
        ASSERT(isdigit(nword[0]));
        bool valid = true;
        int stripdigits = 0;
        unsigned thousandsep = UINT_MAX;
        if (nword[1] == 'x') {
            valid = (nword[0] == '0');
            for (int i = 2; valid && i < nword.length(); i++) {
                if (nword[i] == '\'') {
                    valid = (thousandsep == 0 || thousandsep > INT_MAX);
                    thousandsep = 4;
                } else {
                    valid = isdigit(nword[i]) || 'A' <= nword[i] && nword[i] <= 'F' || 'a' <= nword[i] && nword[i] <= 'f';
                } /* if */
            } /* for */
            if (valid && thousandsep < INT_MAX && thousandsep != 0)
                stripdigits = (4 + 1) - thousandsep;
        } else if (nword[1] == 'b') {
            valid = (nword[0] == '0');
            for (int i = 2; valid && i < nword.length(); i++) {
                if (nword[i] == '\'') {
                    valid = (thousandsep == 0 || thousandsep > INT_MAX);
                    thousandsep = 8;
                } else {
                    valid = '0' <= nword[i] && nword[i] <= '1';
                } /* if */
            } /* for */
            if (valid && thousandsep < INT_MAX && thousandsep != 0)
                stripdigits = (8 + 1) - thousandsep;
        } else {
            int dotcount = 0;
            for (int i = 1; valid && i < nword.length(); i++) {
                if (nword[i] == '.') {
                    valid = (dotcount++ == 0);
                } else if (nword[i] == '\'') {
                    valid = dotcount == 0 && (thousandsep == 0 || thousandsep > INT_MAX);
                    thousandsep = 3;
                } else {
                    valid = isdigit(nword[i]) && (thousandsep-- > 0 || dotcount == 1);
                } /* if */
            } /* for */
            if (valid && thousandsep < INT_MAX && thousandsep != 0)
                stripdigits = (3 + 1) - thousandsep;
        } /* if */
        if (valid) {
            int ln = m_linecount-1;
            int col = m_charcount - (int)decrement;
            AddColorToTable(ln, col - nword.length(), theApp.NumberColor());
            AddColorToTable(ln, col - stripdigits, theApp.NormalColor());
        }
        nword.erase();
    }
}

void CEditorView::BuildContextHighlightTable()
{
    m_linecount = 0;
    m_linescount = GetDocument()->linecount();
    m_charcount = 0;

    m_linestr.erase();

    m_linelength = 0;
    m_contexttable.clear();

    m_inccomment = false;
    m_incppcomment = false;
    m_instringliteral = false;
    m_incharliteral = false;

    m_prevcolor = theApp.NormalColor();
    bool last_operator = false;

    char ch;
    while ((ch = GetNextSourceChar()) != -1)    {
        if (m_incppcomment)
            // --- in a C++ comment, scan until end of line
            continue;
        if (!m_inccomment && !m_instringliteral && !m_incharliteral)    {
            // --- not currently in C comment, string literal, or char literal
            if (ch == '"')  {
                // --- start of a string literal
                KeywordSearch();
                NumberSearch();
                m_instringliteral = true;
                AddColorToTable(m_linecount-1, m_charcount-1, theApp.StringColor());
            }
            else if (ch == '\'' && nword.length() == 0) {
                // --- start of a character literal
                m_incharliteral = true;
                AddColorToTable(m_linecount-1, m_charcount-1, theApp.NumberColor());
            }
            else if (ch == '/') {
                // --- possible start of a comment
                KeywordSearch();
                NumberSearch();
                if ((ch = GetNextSourceChar()) == -1)
                    break;
                if (m_charcount < 2)
                    // --- ch is the first character of a line
                    continue;
                if (ch == '/')
                    // --- start of a C++ comment
                    m_incppcomment = true;
                if (ch == '*')
                    // --- begin token ( /* ) of a C comment
                    m_inccomment = true;
                if (m_incppcomment || m_inccomment)
                    // --- save the starting position of the comment
                    AddColorToTable(m_linecount-1, m_charcount-2, theApp.CommentColor());
                else {
                    // '/' is an operator
                    AddColorToTable(m_linecount-1, m_charcount-2, theApp.OperatorColor());
                    if (ch != '\0' && strchr(pawnoperators, ch) != NULL)
                        last_operator = true;
                    else
                        AddColorToTable(m_linecount-1, m_charcount-1, theApp.NormalColor());
                }
            }
            else if (ch != '\0' && strchr(pawnoperators, ch) != NULL && (nword.length() == 0 || ch != ',')) {
                // operator
                KeywordSearch();
                NumberSearch();
                AddColorToTable(m_linecount-1, m_charcount-1, theApp.OperatorColor());
                last_operator = true;
            }
            else    {
                // --- potential keyword or number
                if (last_operator) {
                    AddColorToTable(m_linecount-1, m_charcount-1, theApp.NormalColor());
                    last_operator = false;
                }
                if (IsCharAlpha(ch) || ch == '_'
                    || (kword.length() == 0 && (ch == '#' || ch == '@'))
                    || (kword.length() > 0 && (kword[0] == '#' || kword[0] == '@' || kword[0] == '_' || IsCharAlpha(kword[0])) && isdigit((unsigned char)ch)))
                    kword += ch;    // collect a word
                else
                    KeywordSearch();
                if (kword.length() == 0 && isdigit((unsigned char)ch)
                    || (nword.length() >= 1 && isdigit(nword[0]) && (ch == '.' || ch == '\''))
                    || (nword.length() == 1 && nword[0] == '0' && (ch == 'x' || ch == 'b'))
                    || (nword.length() >= 2 && nword[1] == 'x' && (isdigit((unsigned char)ch) || 'A' <= ch && ch <= 'F' || 'a' <= ch && ch <= 'f'))
                    || (nword.length() >= 2 && nword[1] == 'b' && (ch == '0' || ch == '1')))
                    nword += ch;    // collect a word
                else
                    NumberSearch();
            }
            continue;
        }
        if (m_instringliteral)  {
            // --- parsing a string literal
            if (ch == '\\') {
                // --- bypass escape sequences
                if ((ch = GetNextSourceChar()) == -1)
                    break;
                continue;
            }
            if (ch == '"')  {
                // --- end of string literal
                m_instringliteral = false;
                AddColorToTable(m_linecount-1, m_charcount, theApp.NormalColor());
            }
        }
        else if (m_incharliteral)   {
            // --- parsing a character literal
            if (ch == '\\') {
                // --- bypass escape sequences
                if ((ch = GetNextSourceChar()) == -1)
                    break;
                continue;
            }
            if (ch == '\'') {
                // --- end of character literal
                m_incharliteral = false;
                AddColorToTable(m_linecount-1, m_charcount, theApp.NormalColor());
            }
        }
        else if (m_inccomment)  {
            while (ch == '*')   {
                if ((ch = GetNextSourceChar()) == -1)
                    break;
                if (m_charcount > 1 && ch == '/')   {
                    // --- end token ( * / ) of a C comment
                    m_inccomment = false;
                    AddColorToTable(m_linecount-1, m_charcount, theApp.NormalColor());
                    break;
                }
            }
            if (ch == -1)
                break;
        }
    }
#ifdef _DEBUG
//  DumpContextTable();
#endif
}

void CEditorView::DisplayText(CDC* pDC, int beg, int len, int line, COLORREF color)
{
    std::string str = GetDocument()->textline(line).substr(beg, len);
    CRect rc;
    GetClientRect(&rc);
    rc.left = m_margin;

    int length = str.length();
    if (theApp.ShowTabSpaces()) {
        // ---- hide TAB alignment spaces (HARDSPACE), translate TAB and space characters
        for (int i = 0; i < length; i++)
            if (str[i] == HARDSPACE)
                str[i] = ' ';
            else if (str[i] == '\t')
                str[i] = '\xbb';  // guillement to the right
            else if (str[i] == ' ')
                str[i] = '\xb7';  // middle dot
    } else {
        // ---- hide the TAB characters in the text line
        for (int i = 0; i < length; i++)
            if (str[i] == '\t' || str[i] == HARDSPACE)
                str[i] = ' ';
    } /* if */

    pDC->SetBkColor(m_crClear);
    pDC->SetTextColor(color);

    int x = m_margin + beg * m_fontwidth - m_leftcolumn;
    int top = line * m_fontheight - m_toprow;
    pDC->ExtTextOut(x, top, ETO_CLIPPED, &rc, str.c_str(), len, 0);
}


void CEditorView::DisplaySourceText(CDC* pDC, int line)
{
    const std::string& str = GetDocument()->textline(line);

    if (theApp.SyntaxColorsOption() && IsSourceCodeFile())  {
        CodeElement ce;
        ce.line = line;
        ce.charpos = 0;
        std::set<CodeElement>::const_iterator it = m_contexttable.find(ce);
        ASSERT(it != m_contexttable.end()); // must be an entry for char 0 of every line
        do  {
            COLORREF clr = (*it).color;
            int beg = ce.charpos;
            int end = str.length();
            if (++it != m_contexttable.end())   {
                ce = *it;
                if (ce.line == line)
                    end = ce.charpos;
            }
            DisplayText(pDC, beg, end-beg, line, clr);
        } while (ce.line == line && it != m_contexttable.end());
    }
    else
        // --- not a source code file or syntax color option not selected
        DisplayText(pDC, 0, str.length(), line, theApp.NormalColor());
}

void CEditorView::InsertLineIntoScreen(CDC* pDC, unsigned int line)
{
    HideCaret();

    if (m_buildcomments)    {
        if (theApp.SyntaxColorsOption() && IsSourceCodeFile())
            BuildContextHighlightTable();
        m_buildcomments = false;
    }

    const std::string& str = GetDocument()->textline(line);
    int len = str.length();

    // --- display the text on the line
    CFont* pOldFont = pDC->SelectObject(m_pscreenfont);

    DisplaySourceText(pDC, line);

    int top = line * m_fontheight - m_toprow;

    // --- pad the line with spaces
    len -= m_leftcolumn / m_fontwidth;
    CRect rc(m_margin, top, m_windowcolumns, top + m_fontheight);
    rc.left += len * m_fontwidth;
    pDC->FillRect(&rc, m_pClearBrush);
    pDC->SelectObject(pOldFont);

    // draw brace/parenthesis match
    if (MatchingBraceParen.IsValid() && MatchingBraceParen.Row() == line) {
        int left = m_margin - m_leftcolumn + MatchingBraceParen.Column() * m_fontwidth;
        pDC->SelectStockObject(NULL_BRUSH);
        pDC->Rectangle(left, top, left + m_fontwidth, top + m_fontheight);
    } /* if */

    if (m_selectionmarked && line >= m_start.row && line <= m_stop.row) {
        // ---- this line is in the selection, need to do some inverting in the bitmap
        int left = m_margin - m_leftcolumn;
        if (line == m_start.row)
            left += m_start.column * m_fontwidth;
        int right = m_margin + (line < m_stop.row ? len : m_stop.column) * m_fontwidth;
        int wd = right - left;
        if (wd)
            pDC->PatBlt(left, top, wd, m_fontheight, DSTINVERT);
    }
    ShowCaret();
    UpdateTitle(GetDocument());
}

bool CEditorView::IsSourceFile(const CString& ext)
{
    CDocument* pDoc = GetDocument();
    if (pDoc != 0)  {
        CString strPath = pDoc->GetPathName();
        return strPath.Right(ext.GetLength()).CompareNoCase(ext) == 0;
    }
    return false;
}

void CEditorView::OnDraw(CDC* pDC)
{
    if (GetDocument() == 0)
        return;
    delete m_pClearBrush;
    m_crClear = theApp.BackgroundColor();
    m_pClearBrush = new CBrush(m_crClear);
    if (keywords.empty())   {
        int i;
        bool isc = IsPawnFile();
        bool ish = IsIncFile();
        if (isc || ish)
            for (i = 0; i < sizeof(pawnkeywords) / sizeof(std::string); i++)
                keywords.insert(pawnkeywords[i]);
        if (isc || ish)
            for (i = 0; i < sizeof(pawndirectives) / sizeof(std::string); i++)
                keywords.insert(pawndirectives[i]);
    }
    HideCaret();
    CRect rc;
    GetClientRect(&rc);
    m_windowrows = rc.bottom;
    m_windowcolumns = rc.right;

    unsigned int linecount = GetDocument()->linecount();

    m_bottomrow = linecount * m_fontheight;
    m_linewidth = GetDocument()->linewidth() * m_fontwidth;

    SCROLLINFO sivert = {
        sizeof (SCROLLINFO),
        SIF_RANGE | SIF_PAGE,
        0, m_bottomrow,
        vpagesize(),
    };
    SCROLLINFO sihorz = {
        sizeof (SCROLLINFO),
        SIF_RANGE | SIF_PAGE,
        0, m_linewidth,
        hpagesize(),
    };

    SetScrollInfo(SB_VERT, &sivert);
    SetScrollInfo(SB_HORZ, &sihorz);

    unsigned int line = m_toprow / m_fontheight;
    unsigned int windowlines = (m_toprow + m_windowrows + m_fontheight) / m_fontheight;
    linecount = min(linecount, windowlines);

    if ((m_selectionmarked = IsSelectionMarked()) == true)
        m_pEditorSelection->GetSelectionMarkers(m_start, m_stop);
    while (line < linecount) {
        if (line == m_currentrow) {
            m_crClear = theApp.ActiveRowColor();
            delete m_pClearBrush;
            m_pClearBrush = new CBrush(m_crClear);
        } /* if */
        InsertLineIntoScreen(pDC, line);
        if (line == m_currentrow) {
            m_crClear = theApp.BackgroundColor();
            delete m_pClearBrush;
            m_pClearBrush = new CBrush(m_crClear);
        } /* if */
        line++;
    } /* while */

    unsigned int lastrow = line * m_fontheight - m_toprow;  // last window row drawn
    if (lastrow < m_windowrows) {
        // --- pad to the bottom of the window with spaces
        CRect crc(rc);
        crc.left = m_margin;
        crc.top = lastrow;
        pDC->FillRect(&crc, m_pClearBrush);
    }
    delete m_pClearBrush;
    m_pClearBrush = 0;
    PadMargin();
}

void CEditorView::PadMargin()
{
    // ----- pad the left margin with a gray tone
    CDC* pDC = GetDC(); // to pad the whole margin to avoid having to erase margin characters
    if (pDC != NULL) {      // Check this first as GetDC() occasionally fails ??
        CRect rc;
        GetClientRect(&rc);
        rc.right = m_margin;
        pDC->FillRect(&rc, m_pMarginBrush);
        ShowCaret();
    } /* if */
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView printing

BOOL CEditorView::OnPreparePrinting(CPrintInfo* pInfo)
{
    delete pInfo->m_pPD;                    // framework has one built on heap
    pInfo->m_pPD = new CQuincyPrintDialog;  // framework will delete this object
    static_cast<CQuincyPrintDialog*>(pInfo->m_pPD)->printlinenumbers = theApp.PrintLineNumbers();
    return DoPreparePrinting(pInfo);
}

void CEditorView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
    printlinenos = static_cast<CQuincyPrintDialog*>(pInfo->m_pPD)->printlinenumbers;

    int nHeight = -((pDC->GetDeviceCaps(LOGPIXELSY) * 10) / 72);

    m_printerfont.CreateFont(nHeight, 0, 0, 0, FW_NORMAL, 0, 0, 0,
        DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Courier");

    TEXTMETRIC tm;
    CFont* pOldFont = pDC->SelectObject(&m_printerfont);
    pDC->GetTextMetrics(&tm);
    m_cyPrinter = tm.tmHeight + tm.tmExternalLeading;
    pDC->SelectObject(pOldFont);

    m_nLinesPerPage =(pDC->GetDeviceCaps(VERTRES) -
       (m_cyPrinter * (3 + (2 * PRINTMARGIN)))) / m_cyPrinter;
    m_nMaxPage = max(1, (GetDocument()->linecount() + (m_nLinesPerPage - 1)) /
        m_nLinesPerPage);
    pInfo->SetMaxPage(m_nMaxPage);
}

void CEditorView::OnPrint(CDC* pDC, CPrintInfo* pInfo)
{
    PrintPageHeader(pDC, pInfo->m_nCurPage);
    PrintPage(pDC, pInfo->m_nCurPage);
}

void CEditorView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* pInfo)
{
    m_printerfont.DeleteObject();
    bool plno = static_cast<CQuincyPrintDialog*>(pInfo->m_pPD)->printlinenumbers;
    theApp.SetPrintLineNumbers(plno);
}

void CEditorView::PrintPageHeader(CDC* pDC, UINT nPageNumber)
{
	UINT width = pDC->GetDeviceCaps(HORZRES);
    UINT y = m_cyPrinter * PRINTMARGIN;

	CFont* pOldFont = pDC->SelectObject(&m_printerfont);

	CString strHeader = GetDocument()->GetTitle();
    pDC->TextOut(0, y, strHeader);

    CString strPageNumber;
    strPageNumber.Format("page %d of %d", nPageNumber, m_nMaxPage);
	CSize sz = pDC->GetTextExtent(strPageNumber);
	pDC->TextOut(width - sz.cx - 1, y, strPageNumber);

	pDC->SelectObject(pOldFont);

	y += m_cyPrinter + m_cyPrinter / 5;
	pDC->MoveTo(0, y);
	pDC->LineTo(width, y);
}

void CEditorView::PrintPage(CDC* pDC, UINT nPageNumber)
{
    int lines = GetDocument()->linecount();
    if (GetDocument()->linecount() != 0) {
        UINT nStart = (nPageNumber - 1) * m_nLinesPerPage;
        UINT nEnd = min(lines - 1, nStart + m_nLinesPerPage - 1);

        CFont* pOldFont = pDC->SelectObject(&m_printerfont);

        for (int i = nStart; i <= nEnd; i++) {
            std::string str = GetDocument()->textline(i);
            for (int j = 0; j < str.length(); j++)
                if (str[j] == '\t' || str[j] == HARDSPACE)
                    str[j] = ' ';
            int y = ((i - nStart) + PRINTMARGIN + 3) * m_cyPrinter;
            CString line;
            if (printlinenos)
				line.Format("%4d: ", i + 1);
            line += str.c_str();
            pDC->TextOut(0, y, line);
        }
        pDC->SelectObject(pOldFont);
    }
}

void CEditorView::OnFilePrintPreview()
{
    // hide tab bar before entering preview mode, so that MFC calculates
    // the window size correctly
    CMDITabFrameWnd *frame = (CMDITabFrameWnd *)theApp.m_pMainWnd;
    CTabBar *tab = frame->GetMdiClient().m_pWndTabs;
    tab->ShowWindow(SW_HIDE);
    CView::OnFilePrintPreview();
    // now we can re-display the tab bar, because the preview is on top of it
    tab->ShowWindow(SW_SHOWNA);
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView diagnostics

#ifdef _DEBUG
void CEditorView::AssertValid() const
{
    CView::AssertValid();
}

void CEditorView::Dump(CDumpContext& dc) const
{
    CView::Dump(dc);
}

CEditorDoc* CEditorView::GetDocument() // non-debug version is inline
{
    ASSERT(m_pDocument == 0 || m_pDocument->IsKindOf(RUNTIME_CLASS(CEditorDoc)));
    return (CEditorDoc*)m_pDocument;
}
#endif //_DEBUG

void CEditorView::SetCurrentRow(int row)
{
    bool redraw = (row != m_currentrow
                    && theApp.SyntaxColorsOption()
                    && IsSourceCodeFile());
    if (redraw) {
        if (m_currentrow >= 0)
            InvalidateRow(m_currentrow);/* to remove "active line" background */
        if (row >= 0)
            InvalidateRow(row);         /* to set "active line" background */
    } /* if */
    m_currentrow = row;
}

////////////////// scrolling and paging functions

void CEditorView::SetScrollPosition(int nBar, UINT nPos)
{
    SCROLLINFO si = {
        sizeof(SCROLLINFO),
        SIF_POS,
        0,0,0,
        nPos
    };
    SetScrollInfo(nBar, &si);
}

void CEditorView::VScrollTo(UINT nPos)
{
    if (m_toprow != nPos)   {
        m_toprow = nPos;
        SetScrollPosition(SB_VERT, nPos);
        SetCaretPosition();
        Invalidate(false);
    }
}
void CEditorView::HScrollTo(UINT nPos)
{
    if (m_leftcolumn != nPos)   {
        m_leftcolumn = nPos;
        SetScrollPosition(SB_HORZ, nPos);
        SetCaretPosition();
        Invalidate(false);
    }
}
void CEditorView::ScrollDown(short Lines)
{
    if (m_toprow > 0)   {
        InfoTip.Hide();
        InfoTipActiveIndex = -1;
        int offs = Lines * vscrollsize();
        int nsize = m_toprow < offs ? m_toprow : offs;
        CRect rc;
        GetClientRect(&rc);
        rc.left += m_margin;
        ScrollWindow(0, nsize, &rc, &rc);
        m_toprow -= nsize;
        UpdateWindow();
        SetScrollPosition(SB_VERT, m_toprow);
        SetCaretPosition();
    }
}
void CEditorView::ScrollUp(short Lines)
{
    int offs = Lines * vscrollsize();
    if (GetScrollPos(SB_VERT) < m_toprow + offs)    {
        InfoTip.Hide();
        InfoTipActiveIndex = -1;
        CRect rc;
        GetClientRect(&rc);
        rc.left += m_margin;
        ScrollWindow(0, -offs, &rc, &rc);
        m_toprow += offs;
        UpdateWindow();
        SetScrollPosition(SB_VERT, m_toprow);
        SetCaretPosition();
    }
}
void CEditorView::ScrollLeft()
{
    if (m_leftcolumn > 0)   {
        InfoTip.Hide();
        InfoTipActiveIndex = -1;
        int nsize = m_leftcolumn < hscrollsize() ? m_leftcolumn : hscrollsize();
        CRect rc;
        GetClientRect(&rc);
        rc.left += m_margin;
        ScrollWindow(nsize, 0, 0, &rc);
        m_leftcolumn -= nsize;
        UpdateWindow();
        SetScrollPosition(SB_HORZ, m_leftcolumn);
        SetCaretPosition();
    }
}
void CEditorView::ScrollRight()
{
    if (GetScrollPos(SB_HORZ) < m_leftcolumn + hscrollsize())   {
        InfoTip.Hide();
        InfoTipActiveIndex = -1;
        CRect rc;
        GetClientRect(&rc);
        rc.left += m_margin;
        ScrollWindow(-hscrollsize(), 0, 0, &rc);
        m_leftcolumn += hscrollsize();
        UpdateWindow();
        SetScrollPosition(SB_HORZ, m_leftcolumn);
        SetCaretPosition();
    }
}
void CEditorView::PageLeft()
{
    if (m_leftcolumn > 0)   {
        InfoTip.Hide();
        InfoTipActiveIndex = -1;
        m_leftcolumn -= hpagesize();
        if (m_leftcolumn < 0)
            m_leftcolumn = 0;
        CRect rc;
        GetClientRect(&rc);
        rc.left += m_margin;
        SetScrollPosition(SB_HORZ, m_leftcolumn);
        ScrollWindow(hpagesize(), 0, &rc, &rc);
        SetCaretPosition(false, true);
    }
}
void CEditorView::PageRight()
{
    if (GetScrollPos(SB_HORZ) < m_leftcolumn + hpagesize()) {
        InfoTip.Hide();
        InfoTipActiveIndex = -1;
        m_leftcolumn += hpagesize();
        CRect rc;
        GetClientRect(&rc);
        rc.left += m_margin;
        ScrollWindow(-hpagesize(), 0, &rc, &rc);
        SetScrollPosition(SB_HORZ, m_leftcolumn);
        SetCaretPosition(false, true);
    }
}
void CEditorView::PageHome()
{
    VScrollTo(0);
    HScrollTo(0);
    SetCurrentRow(0);
    m_currentcolumn = 0;
    SetCaretPosition(false, true);
}
void CEditorView::PageEnd()
{
    int nto = m_bottomrow - vpagesize();
    VScrollTo(nto > 0 ? nto : 0);
    HScrollTo(0);
    SetCurrentRow(GetDocument()->linecount());
    m_currentcolumn = 0;
    SetCaretPosition(false, true);
}
void CEditorView::PageUp()
{
    if (m_toprow > 0)   {
        m_toprow -= vpagesize();
        if (m_toprow < 0)
            m_toprow = 0;
        Invalidate(false);
        SetScrollPosition(SB_VERT, m_toprow);
        SetCaretPosition(false, true);
    }
}
void CEditorView::PageDown()
{
    if (m_toprow + vpagesize() < m_bottomrow)   {
        m_toprow += vpagesize();
        Invalidate(false);
        SetScrollPosition(SB_VERT, m_toprow);
        SetCaretPosition(false, true);
    }
}

////////////////////////////////////////////////
// Functions for getting current position into view

void CEditorView::AdjustScroll()
{
    int col = m_currentcolumn * m_fontwidth;
    while (col > m_windowcolumns + m_leftcolumn - m_fontwidth)
        PageRight();
    while (col < m_leftcolumn)
        PageLeft();
    int row = m_currentrow * m_fontheight;
    while (row > m_windowrows + m_toprow - m_fontheight)
        ScrollUp();
    while (row < m_toprow)
        ScrollDown();
}

void CEditorView::AdjustScrollQuietly()
{
    int col = m_currentcolumn * m_fontwidth;
    while (col > m_windowcolumns + m_leftcolumn - m_fontwidth)  {
        if (GetScrollPos(SB_HORZ) < m_leftcolumn + hpagesize())
            m_leftcolumn += hpagesize();
    }
    while (col < m_leftcolumn)  {
        if (m_leftcolumn > 0)   {
            m_leftcolumn -= hpagesize();
            if (m_leftcolumn < 0)
                m_leftcolumn = 0;
        }
    }
    CurrentLineIntoView();
}

void CEditorView::CurrentLineIntoView()
{
    int current_toprow = m_toprow;
    int row = m_currentrow * m_fontheight;
    if (row > m_windowrows + m_toprow - m_fontheight)
        while (row > m_windowrows/2 + m_toprow - m_fontheight)
            m_toprow += vscrollsize();
    if (row < m_toprow) {
        while (row < m_toprow + m_windowrows/2) {
            int nsize = m_toprow < vscrollsize() ? m_toprow : vscrollsize();
            m_toprow -= nsize;
            if (m_toprow <= 0)  {
                m_toprow = 0;
                break;
            }
        }
    }
    SetCaretPosition();
    if (m_toprow != current_toprow) {
        SetScrollPosition(SB_VERT, m_toprow);
        Invalidate(false);
    } /* if */
}

////////////////////////////////////////////////
// caret movement functions

void CEditorView::CaretDown()
{
    if (m_currentrow + 1 < GetDocument()->linecount())  {
        SetCurrentRow(m_currentrow + 1);
        AdjustScroll();
        SetCaretPosition(false, true);
    }
}
void CEditorView::CaretUp()
{
    if (m_currentrow > 0)   {
        SetCurrentRow(m_currentrow - 1);
        AdjustScroll();
        SetCaretPosition(false, true);
    }
}

void CEditorView::CaretRight()
{
    const std::string& str = GetDocument()->textline(m_currentrow);
    if (m_currentcolumn == str.length() && m_currentrow + 1 < GetDocument()->linecount())   {
        m_currentcolumn = 0;
        SetCurrentRow(m_currentrow + 1);
        if (m_leftcolumn != 0)
            HScrollTo(0);
    }
    else
        m_currentcolumn++;
    AdjustScroll();
    SetCaretPosition(true, true);
}
void CEditorView::CaretLeft()
{
    if (m_currentcolumn == 0)   {
        if (m_currentrow == 0)
            return;
        SetCurrentRow(m_currentrow - 1);
        const std::string& str = GetDocument()->textline(m_currentrow);
        m_currentcolumn = str.length();
    }
    else
        --m_currentcolumn;
    AdjustScroll();
    SetCaretPosition(false, true);
}

static bool iswordchar(char ch)
{
    return IsCharAlpha(ch) || isdigit((unsigned char)ch) || ch == '_' || ch == '@';
}

void CEditorView::WordRight()
{
    int linect = GetDocument()->linecount();
    if (m_currentrow == linect)
        return;
    const std::string* str = &GetDocument()->textline(m_currentrow);
    if (str->empty())   {
        // --- sitting on a blank line
        CaretRight();
        return;
    }
    // --- move to the next word
    while (!str->empty() && (isspace((*str)[m_currentcolumn]) || (*str)[m_currentcolumn] == HARDSPACE)) {
        CaretRight();
        if (m_currentcolumn == 0)   {
            if (m_currentrow == linect)
                return;
            str = &GetDocument()->textline(m_currentrow);
        }
    }
    // --- move to the end of the current word
    bool testwdch = iswordchar((*str)[m_currentcolumn]);
    while (!(isspace((*str)[m_currentcolumn]) || (*str)[m_currentcolumn] == HARDSPACE) &&
            iswordchar((*str)[m_currentcolumn]) == testwdch)    {
        if (m_currentrow == linect-1 && m_currentcolumn == str->length())
            return;     // at end of file
        CaretRight();
        if (m_currentcolumn == 0)   {
            if (m_currentrow == linect)
                return;
            str = &GetDocument()->textline(m_currentrow);
            break;
        }
    }
}
void CEditorView::WordLeft()
{
    CaretLeft();
    if (m_currentrow == 0 && m_currentcolumn == 0)
        return;
    const std::string* str = &GetDocument()->textline(m_currentrow);
    if (str->empty())
        return;
    // --- move back out of spaces to previous word
    while ((isspace((*str)[m_currentcolumn]) || (*str)[m_currentcolumn] == HARDSPACE)) {
        if (m_currentcolumn == 0)
            return;
        CaretLeft();
    }

    bool testwdch = iswordchar((*str)[m_currentcolumn]);
    while (iswordchar((*str)[m_currentcolumn]) == testwdch &&
            !(isspace((*str)[m_currentcolumn]) || (*str)[m_currentcolumn] == HARDSPACE)) {
        if (m_currentcolumn == 0)
                return;
        CaretLeft();
    }
    CaretRight();
}
void CEditorView::LineEnd()
{
    const std::string& str = GetDocument()->textline(m_currentrow);
    m_currentcolumn = str.length();
    AdjustScroll();
    SetCaretPosition(false, true);
}
void CEditorView::LineHome()
{

    int lno = CurrentLineNumber();
    const std::string& line = GetDocument()->textline(lno-1);
    int len = line.length();
    int i;
    for (i = 0; i < len; i++)
        if (line[i] != '\t' && line[i] != HARDSPACE && line[i] != ' ')
            break;
    m_currentcolumn = (i < len && m_currentcolumn > i) ? i : 0;
    if (m_leftcolumn > m_currentcolumn * m_fontwidth)
        HScrollTo(0);
    SetCaretPosition(false, true);
}

/////////////////////////////////////////////////////////////////////////
// Editing functions

void CEditorView::DeleteWord()
{
    m_buildcomments = true;
    if (IsSelectionMarked())
        DeleteSelection();
    CEditorDoc* pDoc = GetDocument();
    ASSERT(pDoc != 0);
    const std::string line = pDoc->textline(m_currentrow);

    int len = line.length();

    bool blankline = len == 0 && pDoc->linecount() < m_windowrows / m_fontheight;

    bool endofline = m_currentcolumn == len;

    if (blankline || endofline) {
        DeleteCharacter();
        return;
    }

    int i = m_currentcolumn;
    if (isspace(line[i]) || line[i] == HARDSPACE) {
        while (i < len && (isspace(line[i])|| line[i] == HARDSPACE)) {
            pDoc->deletechar(m_currentrow, m_currentcolumn, i == m_currentcolumn);
            i++;
        }
    }
    else if (!IsCharAlpha(line[i]) && line[i] != '_')
        pDoc->deletechar(m_currentrow, m_currentcolumn);
    else    {
        do  {
            pDoc->deletechar(m_currentrow, m_currentcolumn, i == m_currentcolumn);
            i++;
        } while (i < len && (IsCharAlpha(line[i]) || line[i] == '_'));
        while (i < len && (isspace(line[i]) || line[i] == HARDSPACE))   {
            pDoc->deletechar(m_currentrow, m_currentcolumn, false);
            i++;
        }
    }
    UpdateTextLine();
}

void CEditorView::DeleteCharacter()
{
    if (InfoTipAutoRemove || InfoTipCheckRemove()) {
        InfoTip.Hide();
        InfoTipActiveIndex = -1;
    } else {
        InfoTip.PostponeTimeout();
    } /* if */
    m_buildcomments = true;
    if (IsSelectionMarked())    {
        DeleteSelection();
        return;
    }

    CEditorDoc* pDoc = GetDocument();
    ASSERT(pDoc != 0);

    bool blankline = pDoc->textline(m_currentrow).length() == 0 &&
                pDoc->linecount() < m_windowrows / m_fontheight;

    if (pDoc->deletechar(m_currentrow, m_currentcolumn) && !blankline)
        UpdateTextLine();
    else
        Invalidate(false);
}
void CEditorView::SplitLine()
{
    m_buildcomments = true;
    bool bsel = IsSelectionMarked();
    if (bsel)
        DeleteSelection();
    // --- Enter key, split the current string in two
    GetDocument()->insertchar('\r', m_currentrow, m_currentcolumn, !bsel);
    HScrollTo(0);
    Invalidate(false);
}

void CEditorView::InsertTab()
{
    m_buildcomments = true;
    CEditorDoc* pDoc = GetDocument();
    ASSERT(pDoc != 0);
    int tabs = theApp.Tabstops();
    std::string blankstr(tabs, ' ');
    bool bt = theApp.TabOption() == 0;

    if (IsSelectionMarked())    {
        ViewIndex begin, end;
        m_pEditorSelection->GetSelectionMarkers(begin, end);
        if (end.column > 0)
            end.row++;
        m_pEditorSelection->SaveSelection();
        m_pEditorSelection->UnmarkSelection();
        m_currentcolumn = 0;
        bool bterminate = true;
        if (m_shiftdown)    {
            for (int row = begin.row; row < end.row; row++) {
                if (pDoc->textline(row)[0] == '\t') {
                    pDoc->deletechar(row, 0, bterminate);
                    bterminate = false;
                }
                else    {
                    int t = tabs;
                    if (pDoc->textline(row).substr(0,tabs) == blankstr) {
                        while (t--) {
                            pDoc->deletechar(row, 0, bterminate);
                            bterminate = false;
                        }
                    }
                }
                SetCurrentRow(end.row);
                UpdateTextLine();
            }
        }
        else    {
            for (int row = begin.row; row < end.row; row++) {
                if (bt) {
                    pDoc->insertchar('\t', row, 0, bterminate);
                    bterminate = false;
                }
                else    {
                    int t = tabs;
                    while (t--) {
                        pDoc->insertchar(' ', row, 0, bterminate);
                        bterminate = false;
                    }
                }
                SetCurrentRow(end.row);
                UpdateTextLine();
            }
        }
        m_pEditorSelection->RestoreSelection();
        UpdateWindow();
    }
    else    {
        pDoc->insertchar(bt ? '\t' : ' ', m_currentrow, m_currentcolumn);
        while (++m_currentcolumn % tabs)
            if (!bt)
                pDoc->insertchar(' ', m_currentrow, m_currentcolumn);
        UpdateTextLine();
        AdjustScroll();
    }
    SetCaretPosition(false, true);
}

void CEditorView::RevertTab()
{
    int count = (theApp.TabOption() == 0) ? 1 : theApp.Tabstops();
    while (count-- > 0) {
        if (m_currentcolumn) {
            CaretLeft();
            DeleteCharacter();
        } /* if */
    } /* while */
}

void CEditorView::InsertCharacter(char ch, bool bterminate)
{
    if (InfoTipAutoRemove || InfoTipCheckRemove()) {
        InfoTip.Hide();
        InfoTipActiveIndex = -1;
    } else {
        InfoTip.PostponeTimeout();
    } /* if */
    m_buildcomments = true;
    bool bsel = IsSelectionMarked();
    if (bsel)
        DeleteSelection();
    GetDocument()->insertchar(ch, m_currentrow, m_currentcolumn, (!bsel) && bterminate);
    if (ch == '/' || ch == '*' || ch == '"')
        Invalidate(false);
    else
        UpdateTextLine();
}

void CEditorView::UpdateTextLine()
{
    m_buildcomments = true;
    if ((m_selectionmarked = IsSelectionMarked()) == true)
        m_pEditorSelection->GetSelectionMarkers(m_start, m_stop);
    CClientDC dc(this);
    m_crClear = theApp.ActiveRowColor();
    delete m_pClearBrush;
    m_pClearBrush = new CBrush(m_crClear);
    InsertLineIntoScreen(&dc, m_currentrow);
    delete m_pClearBrush;
    m_pClearBrush = 0;
}

void CEditorView::DeleteSelection(bool changecaret, bool bterminate)
{
    m_buildcomments = true;
    ViewIndex begin, end;
    m_pEditorSelection->GetSelectionMarkers(begin, end);
    m_pEditorSelection->UnmarkSelection();
    const std::string& str = GetDocument()->textline(begin.row);
    std::string newstr = str.substr(0, begin.column);
    if (begin.row == end.row)
        // --- the selection is all on one line
        newstr += str.substr(end.column, str.length() - end.column);
    else    {
        while (begin.row != end.row)    {
            GetDocument()->deleteline(begin.row, bterminate);
            if (!changecaret && begin.row < m_currentrow)
                SetCurrentRow(m_currentrow - 1);
            bterminate = false;
            --end.row;
        }
        if (begin.row < GetDocument()->linecount() - 1) {
            const std::string& str = GetDocument()->textline(begin.row);
            newstr += str.substr(end.column, str.length() - end.column);
        }
    }
    GetDocument()->replaceline(end.row, newstr, bterminate);
    Invalidate(false);

    if (changecaret)    {
        SetCurrentRow(begin.row);
        m_currentcolumn = begin.column;
    }
    else if (end.row == m_currentrow && end.column < m_currentcolumn)
        m_currentcolumn -= m_currentcolumn - end.column;
    AdjustScrollQuietly();
    SetCaretPosition();
}

/////////////////////////////////////////////////////////////////////////////
// marked selection functions
void CEditorView::InvertDisplayItems(ViewIndex begin, ViewIndex end)
{
    CRect rc;
    rc.top = begin.row * m_fontheight;
    rc.bottom = end.row * m_fontheight + m_fontheight;
    rc.left = 0;
    rc.right = m_windowcolumns;
    do  {
        int len;
        if (begin.row < end.row)    {
            len = GetDocument()->textline(begin.row).length();
            // --- if its an empty line, make it look like one space character
            if (len == 0)
                len = 1;
        }
        else
            len = end.column;
        InvertDisplayRow(begin.row, begin.column, len);
        begin.column = 0;
    } while (begin.row++ < end.row);
}

void CEditorView::InvertDisplayRow(unsigned int row, unsigned int begincol, unsigned int endcol)
{
    CRect rc;
    rc.left = begincol * m_fontwidth - m_leftcolumn + m_margin;
    rc.top = row * m_fontheight - m_toprow;
    rc.right = endcol * m_fontwidth - m_leftcolumn + m_margin;
    rc.bottom = rc.top + m_fontheight;
    CClientDC dc(this);
    dc.PatBlt(rc.left,rc.top,rc.Width(),rc.Height(),DSTINVERT);
}

bool CEditorView::ReplaceSnippet()
{
    // check the word immediately at the left
    const std::string& str = GetDocument()->textline(m_currentrow);
    std::string keyword = "";
    if (!str.empty())   {
        int column = m_currentcolumn;
        while (column > 0 && !(isspace(str[column - 1]) || str[column - 1] == HARDSPACE))
            keyword = str[--column] + keyword;
    } /* if */

    int count = keyword.length();
    if (count == 0)
        return false;
    std::string repl = theApp.Snippets.lookup(keyword);
    if (repl.length() == 0)
        return false;

    // match, erase the original word
    while (count-- > 0) {
        if (m_currentrow || m_currentcolumn) {
            CaretLeft();
            DeleteCharacter();
        } /* if */
    } /* while */

    int column = -1, row = -1;
    count = repl.length();
    for (int idx = 0; idx < count; idx++) {
        if (repl[idx] == '\t') {
            if (m_recording)
                RecordCommand(new KeyDown(this, VK_TAB));
            InsertTab();
            if (m_recording)
                RecordCommand(new KeyUp(this, VK_TAB));
        } else if (repl[idx] == '\v') {
            if (m_recording) {
                RecordCommand(new KeyDown(this, VK_SHIFT));
                RecordCommand(new KeyDown(this, VK_TAB));
            } /* if */
            RevertTab();
            if (m_recording) {
                RecordCommand(new KeyUp(this, VK_TAB));
                RecordCommand(new KeyUp(this, VK_SHIFT));
            } /* if */
        } else if (repl[idx] == '\b') {
            if (m_recording)
                RecordCommand(new KeyDown(this, VK_BACK));
            if (m_currentrow || m_currentcolumn) {
                CaretLeft();
                DeleteCharacter();
            } /* if */
            if (m_recording)
                RecordCommand(new KeyUp(this, VK_BACK));
        } else if (repl[idx] == '^') {
            /* save the current caret position */
            column = m_currentcolumn + 1;
            row = m_currentrow + 1;
        } else if (repl[idx] == '\n') {
            if (m_recording)
                RecordCommand(new Char(this, VK_RETURN));
            if (theApp.AutoIndentOption()) {
                AutoIndent();
            } else {
                SplitLine();
                CaretRight();
            } /* if */
            /* no automatic bullets in snippet replacement */
        } else if (isprintable(repl[idx])) {
            if (m_recording)
                RecordCommand(new Char(this, repl[idx]));
            if (!ExtendEditor(repl[idx])) {
                InsertCharacter(repl[idx]);
                CaretRight();
            } /* if */
        } /* if */
    } /* for */

    if (column > 0 && row > 0) {
        /* set the caret to the saved position */
        SetLineColumn(row, column);
        theApp.ShowLineColumn(row, column);
    } /* if */

    return true;
}

bool CEditorView::AutoComplete()
{
    // check that a balloon is visible
    if (!InfoTip.IsVisible())
        return false;

    // check the word immediately at the left
    const std::string& str = GetDocument()->textline(m_currentrow);
    std::string keyword = "";
    if (!str.empty())   {
        int column = m_currentcolumn;
        unsigned char ch;
        while (column > 0 && (isalpha(ch=str[column - 1]) || isdigit((unsigned char)ch) || ch == '_' || ch == '@'))
            keyword = str[--column] + keyword;
    } /* if */
    if (keyword.length() == 0)
        return false;

    // get the text from the balloon and then the line in InfoTipActiveIndex
    CString WordString;
    WordString = InfoTip.GetText();
    if (WordString.GetLength()==0)
        return false;
    // count the number of words in the list (for wrap-around of the active index)
    int count = 0;
    CString TmpStr = WordString;
    for ( ;; ) {
        int start = TmpStr.Find("<br>");
        if (start < 0)
            break;
        count++;
        TmpStr = TmpStr.Mid(start + 4); /* +4 for the length of <br> */
    } /* for */
    if (TmpStr.GetLength() > 0)
        count++;
    int index = (InfoTipActiveIndex < 0) ? 0 : InfoTipActiveIndex;
    while (index >= count && count > 0)
        index -= count;
    while (index-- > 0) {
        int start = WordString.Find("<br>");
        ASSERT(start > 0);  /* should be found, and should not be at the start of the string */
        if (start >= 0)
            WordString = WordString.Mid(start + 4); /* +4 for the length of <br> */
        else
            return false;
    } /* while */
    // delete the rest of the string
    index = WordString.Find("<br>");
    if (index >= 0)
        WordString = WordString.Left(index);

    // also delete <b> and </b> if any
    index = WordString.Find("<b>");
    if (index >= 0)
        WordString = WordString.Mid(index + 3); /* +3 for the length of <b> */
    index = WordString.Find("</b>");
    if (index >= 0)
        WordString = WordString.Left(index);

    const char *ptr = WordString;
    // skip the first characters (those must match) */
    ASSERT(strlen(ptr)>= keyword.length());
    ASSERT(strncmp(ptr,keyword.c_str(),keyword.length())==0);
    ptr += keyword.length();

    count = strlen(ptr);
    if (count == 0)
        return false;

    for (int idx = 0; idx < count; idx++) {
        ASSERT(isprintable(ptr[idx]));
        if (m_recording)
            RecordCommand(new Char(this, ptr[idx]));
        if (!ExtendEditor(ptr[idx])) {
            InsertCharacter(ptr[idx]);
            CaretRight();
        } /* if */
    } /* for */

    return true;
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView message handlers
void CEditorView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
    SCROLLINFO sivert = {sizeof(SCROLLINFO)};
    GetScrollInfo(SB_VERT, &sivert);
    nPos = sivert.nTrackPos;
    switch(nSBCode) {
        case SB_TOP:
            VScrollTo(0);
            break;
        case SB_THUMBTRACK:
            VScrollTo(nPos);
            break;
        case SB_LINEDOWN:
            ScrollUp();
            break;
        case SB_LINEUP:
            ScrollDown();
            break;
        case SB_PAGEDOWN:
            PageDown();
            break;
        case SB_PAGEUP:
            PageUp();
            break;
        default:
            break;
    }
}

void CEditorView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
    SCROLLINFO sihorz = {sizeof(SCROLLINFO)};
    GetScrollInfo(SB_HORZ, &sihorz);
    nPos = sihorz.nTrackPos;
    switch(nSBCode) {
        case SB_LEFT:
            HScrollTo(0);
            break;
        case SB_LINELEFT:
            ScrollLeft();
            break;
        case SB_LINERIGHT:
            ScrollRight();
            break;
        case SB_PAGELEFT:
            PageLeft();
            break;
        case SB_PAGERIGHT:
            PageRight();
            break;
        case SB_THUMBTRACK:
            HScrollTo(nPos);
            break;
        default:
            break;
    }
}

// ------ convert screen coordinates to document character coordinates,
//        adjusting for scroll position, and line lengths
CPoint CEditorView::ScreenToCharCoordinates(CPoint pt)
{
    if (pt.x < m_margin)
        pt.x = m_margin;
    int x = ((pt.x - m_margin) + m_leftcolumn) / m_fontwidth;
    int y = (pt.y + m_toprow) / m_fontheight;
    if (y >= GetDocument()->linecount())    {
        y = GetDocument()->linecount() - 1;
        if (y < 0)
            y = 0;
    }
    int wd = GetDocument()->textline(y).length();
    if (x > wd)
        x = wd;
    return CPoint(x, y);
}

// ------ convert document character coordinates to client coordinates,
CPoint CEditorView::CharToScreenCoordinates(CPoint pt)
{
    return CPoint(pt.x * m_fontwidth - m_leftcolumn + m_margin, pt.y * m_fontheight - m_toprow);
}

// ---- set the caret position adjusting for tabs in the text
void CEditorView::SetCaretPosition(bool bmoveright, bool frompaging)
{
    if (m_currentrow < 0)
        SetCurrentRow(0);
    if (m_currentcolumn < 0)
        m_currentcolumn = 0;
    assert(GetDocument()->linecount() > 0);
    if (m_currentrow < GetDocument()->linecount())  {
        const std::string& str = GetDocument()->textline(m_currentrow);
        if (!str.empty() && m_currentcolumn < str.length()) {
            int i = m_currentcolumn;
            int tabs = theApp.Tabstops();
            while ((i % tabs) != 0 && str[i] == HARDSPACE)
                if (str[--i] == '\t')
                    break;
            if (str[i] == '\t') {
                if (i != m_currentcolumn && bmoveright) {
                    do
                        i++;
                    while ((i % tabs) != 0);
                }
                m_currentcolumn = i;
            }
        }
        if (m_currentcolumn > str.length())
            m_currentcolumn = str.length();
    }
    else    {
        SetCurrentRow(GetDocument()->linecount() - 1);
        m_currentcolumn = GetDocument()->textline(m_currentrow).length();
    }
    SetCaretPos(CharToScreenCoordinates(CPoint(m_currentcolumn, m_currentrow)));

    if (frompaging && m_pEditorSelection->IsMarking())
        m_pEditorSelection->ExtendSelection(ViewIndex(this, m_currentrow, m_currentcolumn));
    ((CMainFrame*)theApp.m_pMainWnd)->SetRowColumn(m_currentrow+1, m_currentcolumn+1);
    ShowCaret();

    if (MatchingBraceParen.IsValid()) {
        InvalidateChar(MatchingBraceParen.Column(), MatchingBraceParen.Row());
        MatchingBraceParen.Clear();
    } /* if */
    if (CanMatchBraces()) {
        FindBraceParenthesisMatch(&MatchingBraceParen, 50);
        if (MatchingBraceParen.IsValid())
            InvalidateChar(MatchingBraceParen.Column(), MatchingBraceParen.Row());
    } /* if */
}

void CEditorView::InvalidateChar(int col, int row)
{
    CPoint pt = CharToScreenCoordinates(CPoint(col, row));
    InvalidateRect(CRect(pt.x, pt.y, pt.x + m_fontwidth, pt.y + m_fontheight), TRUE);
}

void CEditorView::InvalidateRow(int row)
{
    CPoint pt = CharToScreenCoordinates(CPoint(0, row));
    InvalidateRect(CRect(m_margin, pt.y, m_windowcolumns, pt.y + m_fontheight), FALSE);
}

void CEditorView::OnSetFocus(CWnd* pOldWnd)
{
    CView::OnSetFocus(pOldWnd);
    CreateSolidCaret(2, m_fontheight);
    if (GetDocument()->linecount() > 0)
        SetCaretPosition();
}

void CEditorView::OnKillFocus(CWnd* pNewWnd)
{
    CView::OnKillFocus(pNewWnd);
    ((CMainFrame*)theApp.m_pMainWnd)->SetRowColumn(-1, -1);
    InfoTip.Hide();
    InfoTipActiveIndex = -1;
    HideCaret();
    ::DestroyCaret();
}

////////////////////////////////////////////////////////
// mouse functions

void CEditorView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
    if (!m_recording)   {
        m_pEditorSelection->UnmarkSelection();
        const std::string* str = &GetDocument()->textline(m_currentrow);
        if (!str->empty())  {
            if (iswordchar((*str)[m_currentcolumn]))    {
                while (m_currentcolumn > 0 && iswordchar((*str)[m_currentcolumn]))
                    CaretLeft();
                if (!iswordchar((*str)[m_currentcolumn]))
                    CaretRight();
                m_pEditorSelection->SetMarking(ViewIndex(this, m_currentrow, m_currentcolumn));
                do
                    CaretRight();
                while (iswordchar((*str)[m_currentcolumn]));
                m_pEditorSelection->ExtendSelection(ViewIndex(this, m_currentrow, m_currentcolumn));
            }
        }
    }
    CView::OnLButtonDblClk(nFlags, point);
}

void CEditorView::OnLButtonDown(UINT nFlags, CPoint point)
{
    if (!m_recording)   {
        CPoint pt = ScreenToCharCoordinates(point);
        SetCurrentRow(pt.y);
        m_currentcolumn = pt.x;
        SetCaretPosition();

        ReleaseCapture();

        if (m_pEditorSelection->IsItemInSelection(ViewIndex(this, m_currentrow, m_currentcolumn)))  {
            SetCapture();
            m_hOldCursor = SetCursor(m_ctrldown ? m_hCopyCursor : m_hMoveCursor);
            m_dragging = true;
            m_pEditorSelection->SaveSelection();
            return;
        }

        m_pEditorSelection->UnmarkSelection();

        m_mousemarking = true;
        m_pEditorSelection->SetMarking(ViewIndex(this, m_currentrow, m_currentcolumn));
        KillTimer(0);
        SetCapture();
    }
    CView::OnLButtonDown(nFlags, point);
}

void CEditorView::OnLButtonUp(UINT nFlags, CPoint point)
{
    KillTimer(0);
    if (!m_recording)   {
        if (m_dragging) {
            ViewIndex cvndx(this, m_currentrow, m_currentcolumn);
            if (!m_pEditorSelection->IsItemInSelection(cvndx))  {
                // ---- build a vector from the selection
                std::string str;
                SelectionToString(str);
                std::vector<std::string> strs;
                StringToVector(strs, str.c_str());

                if (!m_ctrldown)
                    // ---- moving, delete the marked selection shifting instead of resetting the caret
                    DeleteSelection(false);

                // ---- drop the marked selection into the document
                InsertStringsIntoDocument(strs, false);

                if (m_ctrldown)
                    // ---- copying, reinvert the marked selection display
                    m_pEditorSelection->RestoreSelection();
                Invalidate(false);
                SetCursor(m_hOldCursor);
            }
            else
                m_pEditorSelection->UnmarkSelection();
            m_dragging = false;
            ReleaseCapture();
        }
        else if (m_mousemarking)    {
            m_mousemarking = false;
            m_pEditorSelection->StopMarking();
            ReleaseCapture();
        }
    }
    CView::OnLButtonUp(nFlags, point);
}

void CEditorView::OnMouseMove(UINT nFlags, CPoint point)
{
    if (!m_recording) {
        if (m_mousemarking || m_dragging) {
            m_ScrollPos = point;
            if (point.y < 0)    {
                CaretUp();
                SetTimer(0, 100, 0);
                return;
            }
            if (point.y > m_windowrows) {
                CaretDown();
                SetTimer(0, 100, 0);
                return;
            }
            CPoint pt = ScreenToCharCoordinates(point);
            if (pt.x >= 0 && pt.x < m_windowcolumns)    {
                SetCurrentRow(pt.y);
                m_currentcolumn = pt.x;
                SetCaretPosition();
                if (m_mousemarking)
                    m_pEditorSelection->ExtendSelection(ViewIndex(this, m_currentrow, m_currentcolumn));
            }
        } else {
            InfoTip.ForwardMouseMove(point);
        } /* if */
    } /* if (!m_recording) */
}

const char *CEditorView::InfoCallback(LPPOINT position, LPVOID User, BOOL InfoTips, int ActiveIndex)
{
	if (!InfoTipEnable)
		return NULL;

    CEditorView *view = (CEditorView*)User;

    /* get the string that the mouse cursor points to */
    CPoint pt(*position);
    pt = view->ScreenToCharCoordinates(pt);
    std::string str = view->GetDocument()->textline(pt.y);
    if (str.empty() || !iswordchar(str[pt.x]))
        return NULL;

    /* get the word that the mouse cursor points to */
    while (pt.x > 0 && iswordchar(str[pt.x - 1]))
        pt.x--;
    int x2;
    for (x2 = pt.x; iswordchar(str[x2]); x2++)
        /* nothing */;
    str = str.substr(pt.x, x2 - pt.x);

    std::string info = "";

    /* if currently debugging, show different info tips) */
    Debugger *dbg = theApp.GetDebugger(false);
    if (dbg) {
        /* verify whether this is a symbol */
        bool issymbol = IsCharAlpha(str[0]) || str[0] == '_';
        for (int i = 1; str[i] && issymbol; i++)
            issymbol = isalnum(str[i]) || str[i] == '_';
        if (issymbol && view->keywords.find(str) != view->keywords.end())
            issymbol = false;   /* reserved words are not "symbols" */
        if (issymbol) {
            /* ask the debugger for the value of the variable hoovered over */
            CString cstr = str.c_str();
            dbg->GetVariableValue(cstr, view->InfoTip.GetCalloutWindow());
            info = "?";
            InfoTipAutoRemove = true;
        } else {
            info = "";
        } /* if */
    } else {
        /* look up the word (fully or partial) */
        if (InfoTips)
            info = theApp.InfoTip_Lookup(str);
        if (info.length() == 0 && (str.length() >= 3 || !InfoTips)) {
            InfoTipAutoRemove = true;
            std::vector<std::string> symbols = theApp.InfoTip_Match(str);
            std::vector<std::string> editwords = view->GetDocument()->MatchWord(str);
            /* append the document words to the known symbols, but avoid duplicates */
            int count = symbols.size();
            std::vector<std::string>::iterator iter;
            for (iter = editwords.begin(); iter != editwords.end(); iter++) {
                if (std::find(symbols.begin(), symbols.end(), *iter) == symbols.end())
                    symbols.push_back(*iter);
            } /* for */
            if (symbols.size() > count)
                std::sort(symbols.begin(), symbols.end());  /* re-sort after adding items */
            /* wrap around active index, but take care of the maximum value if 15 items in the list too */
            const int max_items = 15;
            count = symbols.size();
            if (count > max_items)
                count = max_items;
            while (ActiveIndex >= count && count > 0)
                ActiveIndex -= count;
            /* convert the array to a single string (max 15 items) */
            count = 0;
            info = "";
            for (iter = symbols.begin(); iter != symbols.end(); iter++) {
                if (info.length() > 0)
                    info += "<br>";
                if (count < max_items) {
                    if (count == ActiveIndex)
                        info += "<b>";
                    info += *iter;
                    if (count == ActiveIndex)
                        info += "</b>";
                } else {
                    info += "...";
                    break;
                } /* if */
                count++;
            } /* for */
        } else {
            InfoTipAutoRemove = false;
        } /* if */
    } /* if */
    if (info.length() == 0)
        return NULL;

    /* copy the word to a non-volatile buffer before returning it */
    int length = info.length();
    char *message = (char*)malloc((length + 1)*sizeof(char));
    strcpy(message, info.c_str());
    return message;
}

bool CEditorView::InfoTipCheckRemove()
{
    CPoint infopos;
    if (!InfoTip.IsVisible(&infopos))
        return false;
    CPoint caretpos = CharToScreenCoordinates(CPoint(m_currentcolumn, m_currentrow));
    return (infopos.y < caretpos.y || infopos.y > caretpos.y + 2*m_fontheight);
}

BOOL CEditorView::OnMouseWheel(UINT nFlags, short nDelta, CPoint point)
{
    static DWORD PrevStamp;
    DWORD Stamp = GetTickCount();
    DWORD Delta = Stamp - PrevStamp;
    PrevStamp = Stamp;

    short divider;
    if (Delta < 100)
        divider = 30;
    else if (Delta < 200)
        divider = 60;
    else
        divider = 120;

    if (nDelta < 0)
        ScrollUp(-nDelta / divider);
    else if (nDelta > 0)
        ScrollDown(nDelta / divider);
    return 1;
}

void CEditorView::OnTimer(UINT nIDEvent)
{
    if (nIDEvent == 0)  {
        KillTimer(0);
        OnMouseMove(0, m_ScrollPos);
    }
    CView::OnTimer(nIDEvent);
}

////////////////////////////////////////////////////
// keyboard functions

void CEditorView::TestSelection()
{
    if (!m_shiftdown && IsSelectionMarked())
        m_pEditorSelection->UnmarkSelection();
}
void CEditorView::TestMarking()
{
    if (m_shiftdown)
        m_pEditorSelection->SetMarking(ViewIndex(this, m_currentrow, m_currentcolumn));
}

void CEditorView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
    if (m_recording)
        RecordCommand(new KeyDown(this, nChar));
    if (ExtendEditor(nChar))
        return;

    // verify state of the shift keys (do not assume that we always see both
    // the messages for the press and release os a shift key)
    m_ctrldown = (bool)((GetKeyState(VK_CONTROL) & 0x8000) != 0);
    m_shiftdown = (bool)((GetKeyState(VK_SHIFT) & 0x8000) != 0);

    CPoint pos;
    switch (nChar) {
        case VK_TAB:
            if (m_shiftdown) {
                if (IsSelectionMarked())
                    InsertTab();    /* InsertTab() handles un-indenting of marked blocks too */
                else
                    RevertTab();
            } else if (InfoTipActiveIndex >= 0 && InfoTip.IsVisible(&pos)) {
                AutoComplete();
                InfoTip.Hide();
                InfoTipActiveIndex = -1;
            } else if (!ReplaceSnippet()) {
                InsertTab();        /* InsertTab() also handles indenting of marked blocks */
            }
            return;
        case VK_BACK:
            if (m_currentrow || m_currentcolumn) {
                CaretLeft();
                DeleteCharacter();
            }
            return;
        case VK_RETURN:
            if (InfoTipActiveIndex >= 0 && InfoTip.IsVisible(&pos)) {
                AutoComplete();
            } else {
                SplitLine();
                CaretRight();
            } /* if */
            InfoTip.Hide();
            InfoTipActiveIndex = -1;
            return;
        case VK_DELETE:
            if (m_ctrldown)
                DeleteWord();
            else
                DeleteCharacter();
            return;
        case VK_CONTROL:
            m_ctrldown = true;
            return;
        case VK_SHIFT:
            m_shiftdown = true;
            return;
        case VK_DOWN:
            if (!InfoTip.IsVisible(&pos))
                InfoTipActiveIndex = -1;
            InfoTip.Hide();
            if (InfoTipActiveIndex >= 0) {
                InfoTip.Show(&pos, FALSE, ++InfoTipActiveIndex);
            } else {
                TestSelection();
                if (m_ctrldown) {
                    ScrollUp();
                } else {
                    TestMarking();
                    CaretDown();
                } /* if */
            } /* if */
            return;
        case VK_UP:
            if (!InfoTip.IsVisible(&pos))
                InfoTipActiveIndex = -1;
            InfoTip.Hide();
            if (InfoTipActiveIndex >= 0) {
                if (InfoTipActiveIndex != 0)
                    InfoTipActiveIndex--;
                InfoTip.Show(&pos, FALSE, InfoTipActiveIndex);
            } else {
                TestSelection();
                if (m_ctrldown) {
                    ScrollDown();
                } else {
                    TestMarking();
                    CaretUp();
                } /* if */
            } /* if */
            return;
        case VK_RIGHT:
            TestSelection();
            TestMarking();
            m_ctrldown ? WordRight() : CaretRight();
            return;
        case VK_LEFT:
            TestSelection();
            TestMarking();
            m_ctrldown ? WordLeft() : CaretLeft();
            return;
        case VK_NEXT:
            InfoTip.Hide();
            InfoTipActiveIndex = -1;
            TestSelection();
            if (!m_ctrldown)    {
                TestMarking();
                PageDown();
                SetCurrentRow(m_currentrow + m_windowrows / m_fontheight);
                SetCaretPosition(false, true);
            }
            return;
        case VK_PRIOR:
            InfoTip.Hide();
            InfoTipActiveIndex = -1;
            TestSelection();
            if (!m_ctrldown){
                TestMarking();
                PageUp();
                SetCurrentRow(m_currentrow - m_windowrows / m_fontheight);
                SetCaretPosition(false, true);
            }
            return;
        case VK_END:
            TestSelection();
            TestMarking();
            if (m_ctrldown)
                PageEnd();
            else
                LineEnd();
            return;
        case VK_HOME:
            TestSelection();
            TestMarking();
            if (m_ctrldown)
                PageHome();
            else
                LineHome();
            return;
        default:
            break;
    }
}

void CEditorView::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
    if (m_recording && (nChar == VK_CONTROL || nChar == VK_SHIFT))
        RecordCommand(new KeyUp(this, nChar));
    if (nChar == VK_CONTROL)
        m_ctrldown = false;
    else if (nChar == VK_SHIFT)
        m_shiftdown = false;
}

bool CEditorView::isprintable(int c)
{
    bool v;
    if (c < 128)
        v = isprint(c);
    else
        v = c == 128 || (c >= 161 && c <= 255);
    return v;
}

void CEditorView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
    if (isprintable(nChar) && nChar != VK_TAB)  {
        if (m_recording)
            RecordCommand(new Char(this, nChar));
        if (!ExtendEditor(nChar))   {
            InsertCharacter(nChar);
            CaretRight();
        }
    }
}

void CEditorView::OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
    CView::OnSysKeyDown(nChar, nRepCnt, nFlags);
    InfoTip.Hide();
    InfoTipActiveIndex = -1;
}

////////////////////////////////////////////////////////
// macro functions

void CEditorView::DeleteMacros()
{
    std::vector<MacroCommand*>::iterator iter = m_macrocommands.begin();
    while (iter != m_macrocommands.end())
        delete *(iter++);
    m_macrocommands.clear();
}

void CEditorView::OnRecord()
{
    m_recording = true;
    CMenu* pMenu = ((CMainFrame*)theApp.m_pMainWnd)->GetMenu();
    assert(pMenu != 0);
    pMenu->ModifyMenu(ID_RECORD, MF_BYCOMMAND | MF_STRING, ID_STOPRECORD, "&Stop\tAlt+S");
    DeleteMacros();
    SetCursor(m_hRecordCursor);
}

void CEditorView::OnStopRecord()
{
    m_recording = false;
    CMenu* pMenu = ((CMainFrame*)theApp.m_pMainWnd)->GetMenu();
    assert(pMenu != 0);
    pMenu->ModifyMenu(ID_STOPRECORD, MF_BYCOMMAND | MF_STRING, ID_RECORD, "&Record\tAlt+R");
    SetCursor(m_hArrowCursor);
}

void CEditorView::RecordCommand(MacroCommand* pCmd)
{
    m_macrocommands.push_back(pCmd);
}

void CEditorView::OnPlayback()
{
    std::vector<MacroCommand*>::iterator iter = m_macrocommands.begin();
    while (iter != m_macrocommands.end())   {
        (*iter)->PlayBack();
        iter++;
    }
}

void CEditorView::OnUpdatePlayback(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(!m_recording && !m_macrocommands.empty());
}

void CEditorView::OnUpdateRecord(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(!m_recording);
}

void CEditorView::OnUpdateStopRecord(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(m_recording);
}

////////////////////////////////////////////////////////
// clipboard functions


void CEditorView::OnUpdateEditCut(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(IsSelectionMarked());
}

//void CEditorView::OnUpdateEditCopy(CCmdUI* pCmdUI)
//{
//  pCmdUI->Enable(IsSelectionMarked());
//}

void CEditorView::OnUpdateEditPaste(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(IsClipboardFormatAvailable(CF_TEXT));
}

void CEditorView::OnUpdateEditClear(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(!IsRecording() && IsSelectionMarked());
}

void CEditorView::OnEditCut()
{
    OnEditCopy();
    OnEditClear();
}

void CEditorView::OnEditClear()
{
    DeleteSelection();
}

void CEditorView::OnEditSelectAll()
{
    m_pEditorSelection->UnmarkSelection();
    PageHome();
    m_pEditorSelection->SetMarking(ViewIndex(this, 0, 0));
    int endrow = GetDocument()->linecount() - 1;
    int endcol = GetDocument()->textline(endrow).length();
    m_pEditorSelection->ExtendSelection(ViewIndex(this, endrow, endcol));
}
// ------ functions to support view contexts for undo/redo
void CEditorView::GetCurrentPosition(unsigned int& toprow, unsigned int& leftcolumn, unsigned int& row, unsigned int& column) const
{
    toprow = m_toprow;
    leftcolumn = m_leftcolumn;
    row = m_currentrow;
    column = m_currentcolumn;
}
void CEditorView::SetCurrentPosition(unsigned int toprow, unsigned int leftcolumn, unsigned int row, unsigned int column)
{
    if (m_leftcolumn != leftcolumn || m_toprow != toprow)
        Invalidate(false);  // changing scroll position
    m_toprow = toprow;
    m_leftcolumn = leftcolumn;
    SetCurrentRow(row);
    m_currentcolumn = column;
    SetScrollPosition(SB_VERT, m_toprow);
    SetCaretPosition();
    AdjustScroll();
}

// --- copy the text selection to one string, collapsing tab expansions
//     and inserting \r\n between lines
//     Used by cut, copy and drop operations
void CEditorView::SelectionToString(std::string& str)
{
    ViewIndex begin, end;
    m_pEditorSelection->GetSelectionMarkers(begin, end);
    std::string strline = GetDocument()->textline(begin.row);
    if (begin.row == end.row)   {
        // --- the selection is all on one line
        str = strline.substr(begin.column, end.column - begin.column);
        CEditorDoc::entab(str);
    }
    else    {
        str = strline.substr(begin.column, strline.length() - begin.column) + "\r\n";
        CEditorDoc::entab(str);
        while (++begin.row != end.row)  {
            strline = GetDocument()->textline(begin.row);
            CEditorDoc::entab(strline);
            str += strline + "\r\n";
        }
        if (end.row != GetDocument()->linecount())  {
            strline = GetDocument()->textline(end.row);
            strline = strline.substr(0, end.column);
            CEditorDoc::entab(strline);
            str += strline;
            if (end.column == 0)
                str += "\r\n";
        }
    }
}

// --- build a vector of strings from a null-terminated string with "\r\n" separators
//     Used by paste and drop operations
void CEditorView::StringToVector(std::vector<std::string>& strs, const char* cp)
{
    std::string str;
    while (*cp) {
        str += *cp;
        if (*cp == '\n')    {
            strs.push_back(str.substr(0, str.length()-2));
            str.erase();
        }
        cp++;
    }
    if (str.length() > 0)
        strs.push_back(str);
}

// --- insert a vector of text line strings into the document at the current insertion point,
//     expanding tabs
//     Used by paste and drop operations
void CEditorView::InsertStringsIntoDocument(const std::vector<std::string>& strs, bool bterminate)
{
    if (strs.size() > 0)    {
        m_buildcomments = true;
        const std::string& str = GetDocument()->textline(m_currentrow);
        std::string first = str.substr(0, m_currentcolumn);
        std::string last = str.substr(m_currentcolumn, str.length() - m_currentcolumn);
        std::string mid = *strs.begin();

        if (strs.size() == 1)   {
            // --- only one text line in the vector
            int ccol = first.length();
            CEditorDoc::detab(mid);
            ccol += mid.length();
            CEditorDoc::entab(mid);
            CEditorDoc::entab(first);
            CEditorDoc::entab(last);
            std::string str(first+mid+last);
            CEditorDoc::detab(str);
            GetDocument()->replaceline(m_currentrow, str, bterminate);
            m_currentcolumn = ccol;
        }
        else    {
            // ---- process the first line from the vector
            CEditorDoc::entab(first);
            std::string str(first+mid);
            CEditorDoc::detab(str);
            GetDocument()->replaceline(m_currentrow, str, bterminate);

            int inserter = m_currentrow + 1;

            // ---- process the middle lines from the vector
            if (strs.size() > 2)    {
                std::vector<std::string>::const_iterator iter;
                for (iter = strs.begin() + 1; iter != strs.end()-1; iter++) {
                    std::string mstr = *iter;
                    CEditorDoc::detab(mstr);
                    GetDocument()->insertline(inserter++, mstr, false);
                }
            }
            // ---- process the last line from the vector
            std::string lstr = *(strs.end()-1);
            CEditorDoc::detab(lstr);    /* detab -> to get expanded size, for cursor positioning */
            unsigned int ccol = lstr.length();
            CEditorDoc::entab(lstr);    /* entab -> because TABs must be recalculated after insertion */
            CEditorDoc::entab(last);
            str = lstr + last;
            CEditorDoc::detab(str);
            if (inserter >= GetDocument()->linecount())
                GetDocument()->appendline(str, false);
            else
                GetDocument()->insertline(inserter, str, false);
            m_currentcolumn = ccol;
            SetCurrentRow(inserter);
        }
    }
}

void CEditorView::StringToClipboard(const std::string& str)
{
    HGLOBAL hGlobalMemory = GlobalAlloc(GHND, str.length() + 1);
    if (hGlobalMemory != 0) {
        char* pGlobalMemory = (char*) GlobalLock(hGlobalMemory);
        if (pGlobalMemory != 0) {
            int len = str.length();
            const char* cp = str.c_str();
            while (len--)
                *pGlobalMemory++ = *cp++;
        }
        GlobalUnlock(hGlobalMemory);
        OpenClipboard();
        EmptyClipboard();
        SetClipboardData(CF_TEXT, hGlobalMemory);
        CloseClipboard();
    }
}

void CEditorView::OnEditCopy()
{
    std::string str;
    SelectionToString(str);
    if (str.empty())
        str = GetDocument()->textline(m_currentrow);
    StringToClipboard(str);
}

void CEditorView::OnEditPaste()
{
    OpenClipboard();
    HANDLE hClipboardData = GetClipboardData(CF_TEXT);
    std::vector<std::string> strs;
    bool bsel = m_pEditorSelection->IsSelectionMarked();
    if (hClipboardData != 0)    {
        char* cp = (char*) GlobalLock(hClipboardData);
        if (cp != 0)    {
            if (bsel)
                DeleteSelection();
            // --- build a vector of strings from the clipboard \r\n terminated strings
            StringToVector(strs, cp);
        }
        GlobalUnlock(hClipboardData);
    }
    CloseClipboard();
    if (strs.size() > 0)    {
        InsertStringsIntoDocument(strs, !bsel);
        Invalidate(false);
        AdjustScrollQuietly();
        SetCaretPosition();
    }
}

////////////////////////////////////////////////////////
// search and replace functions

void CEditorView::OnEditFind()
{
    m_ctrldown = false;         // in case of Ctrl+F
    FindReplace(true);
}

void CEditorView::OnEditReplace()
{
    m_ctrldown = false;         // in case of Ctrl+H
    FindReplace(false);
}

void CEditorView::OnUpdateEditFindNext(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(m_findtext.length() != 0);
}

void CEditorView::OnEditFindNext()
{
    FindNext();
}

void CEditorView::FindReplace(bool findonly)
{
    std::string str = SelectedText();
    if (!str.empty())
        m_findtext = str;
    m_pEditorSelection->UnmarkSelection();
    m_wasfound = m_found = m_bchanged = false;
    delete m_pFindDlg;
    m_pFindDlg = new CFindReplaceDialog;
    m_pFindDlg->Create(findonly, m_findtext.c_str(), m_replacetext.empty() ? 0 : m_replacetext.c_str(), m_nfrflags, this);
    /* position the dialog (move it to the right edge, to minimize overlapping of text) */
    RECT rcFind, rcEdit;
    m_pFindDlg->GetWindowRect(&rcFind);
    GetWindowRect(&rcEdit);
    CPoint pt = CharToScreenCoordinates(CPoint(m_currentcolumn, m_currentrow));
    OffsetRect(&rcFind, rcEdit.right - rcFind.right - 16, pt.y + rcEdit.top - rcFind.top - 32);
    m_pFindDlg->MoveWindow(&rcFind);
}

void CEditorView::FindNext()
{
    m_pEditorSelection->UnmarkSelection();
    if (m_nfrflags & FR_DOWN)
        FindTextForward();
    else
        FindTextBackward();
    if (!m_found && m_wasfound && (m_nfrflags & FR_DOWN)) {
        const char *msg = "Continue search from start of file?";
        const char *caption = "Search string not found";
        int result;
        if (m_pFindDlg)
            result = ::MessageBox(m_pFindDlg->GetSafeHwnd(), msg, caption, MB_ICONQUESTION|MB_YESNO|MB_DEFBUTTON2);
        else
            result = MessageBox(msg, caption, MB_ICONQUESTION|MB_YESNO|MB_DEFBUTTON2);
        if (result == IDYES) {
            m_wasfound = false;
            PageHome();
            FindTextForward();
        } else if (m_pFindDlg) {
            m_pFindDlg->PostMessage(WM_COMMAND, IDABORT);
        } /* if */
    } /* if */
    m_wasfound |= m_found;
    if (m_found) {
        int len = m_findtext.length();
        SetCurrentRow(m_findrow);
        m_currentcolumn = m_findcol;
        if (m_nfrflags & FR_DOWN)
            m_currentcolumn += len;
        else
            m_findcol += len;
        m_pEditorSelection->SetMarking(ViewIndex(this, m_findrow, m_findcol));
        m_pEditorSelection->ExtendSelection(ViewIndex(this, m_currentrow, m_currentcolumn));
        AdjustScrollQuietly();
    }
}

void CEditorView::OnHelp()
{
    /* for some reason, I get a double call to this function; let only one of these through */
    static DWORD LastStamp;
    DWORD Stamp = GetTickCount();
    if (Stamp - LastStamp < 500)
        return;
    LastStamp = Stamp;

    /* if there is a selection, get it */
    std::string str = SelectedText();
    if (!str.empty())
        theApp.OpenHelp(str.c_str());
    else
        theApp.OpenHelp(ID_HELP);
}


LONG CEditorView::OnFindReplace(WPARAM wParam, LPARAM lParam)
{
    LPFINDREPLACE fr = (LPFINDREPLACE)lParam;
    m_findtext = fr->lpstrFindWhat;
    m_replacetext = fr->lpstrReplaceWith;
    m_nfrflags = fr->Flags;

    if (m_nfrflags & FR_DIALOGTERM) {
        m_pFindDlg = 0;
        m_wasfound = m_found = m_bchanged = false;
        m_nfrflags &= ~FR_DIALOGTERM;
        return 0;
    }

    int saverow = m_currentrow;
    int savecol = m_currentcolumn;

    if (m_nfrflags & FR_REPLACEALL) {
        SetCurrentRow(0);
        m_currentcolumn = 0;
    } /* if */
    bool bterminate = true;
    for (;;)    {
        if (((m_nfrflags & FR_REPLACE) || (m_nfrflags & FR_REPLACEALL)) && m_found) {
            assert(m_pEditorSelection->IsSelectionMarked());
            ViewIndex start, stop;
            m_pEditorSelection->GetSelectionMarkers(start, stop);
            m_pEditorSelection->UnmarkSelection();
            assert(start.row == stop.row);
            assert(start.column < stop.column);
            const std::string& line = GetDocument()->textline(start.row);
            std::string first = line.substr(0, start.column);
            std::string last = line.substr(stop.column, line.length() - stop.column);
            std::string mid(m_replacetext);
            std::string line1 = first + mid + last;
            GetDocument()->replaceline(start.row, line1, bterminate);
            SetCurrentRow(start.row);
            m_currentcolumn = start.column + m_replacetext.length();
            bterminate = false;
            m_bchanged = true;
            m_buildcomments = true;
            Invalidate(false);
        }
        else
            m_pEditorSelection->UnmarkSelection();
        int len = m_findtext.length();
        FindNext();
        m_wasfound |= m_found;
        if (!m_found)   {
            if (!m_wasfound)    {
                CString msg("Cannot find \"");
                msg += m_findtext.c_str();
                msg += '"';
                if (m_pFindDlg)
                    ::MessageBox(m_pFindDlg->GetSafeHwnd(), msg, "Replace", MB_OK | MB_ICONEXCLAMATION);
                else
                    MessageBox(msg, "Replace", MB_OK | MB_ICONEXCLAMATION);
                SetCurrentRow(saverow);
                m_currentcolumn = savecol;
            }
            break;
        }
        if (!(m_nfrflags & FR_REPLACEALL))
            break;
    }
    if (m_bchanged)
        AdjustScrollQuietly();
    return 0;
}

bool CEditorView::isword(const char* cp, int col, int len)
{
    if (col == 0 || isspace(cp[col-1]) || cp[col-1] == HARDSPACE || ispunct(cp[col-1]))
        if (cp[col+len] == '\0' || isspace(cp[col+len]) || cp[col+len] == HARDSPACE || ispunct(cp[col+len]))
            return true;
    return false;
}

void CEditorView::FindTextForward()
{
    m_found = false;
    m_findrow = m_currentrow;
    m_findcol = m_currentcolumn;
    int len = m_findtext.length();
    while (m_findrow < GetDocument()->linecount())  {
        const std::string& line = GetDocument()->textline(m_findrow);
        while (m_findcol + len <= line.length())    {
            bool whole = (m_nfrflags & FR_WHOLEWORD) != 0;
            if ((m_nfrflags & FR_MATCHCASE) == 0)   {
                if (strnicmp(m_findtext.c_str(), line.c_str() + m_findcol, len) == 0)   {
                    if (!whole || isword(line.c_str(), m_findcol, len)) {
                        m_found = true;
                        return;
                    }
                }
            }
            else if (strncmp(m_findtext.c_str(), line.c_str() + m_findcol, len) == 0)   {
                if (!whole || isword(line.c_str(), m_findcol, len)) {
                    m_found = true;
                    return;
                }
            }
            m_findcol++;
        }
        m_findcol = 0;
        m_findrow++;
    }
}

void CEditorView::FindTextBackward()
{
    m_found = false;
    m_findrow = m_currentrow;
    m_findcol = m_currentcolumn;
    int len = m_findtext.length();
    while (m_findrow >= 0)  {
        const std::string& line = GetDocument()->textline(m_findrow);
        m_findcol -= len;
        while (m_findcol >= 0)  {
            bool whole = (m_nfrflags & FR_WHOLEWORD) != 0;
            if ((m_nfrflags & FR_MATCHCASE) == 0)   {
                if (strnicmp(m_findtext.c_str(), line.c_str() + m_findcol, len) == 0)   {
                    if (!whole || isword(line.c_str(), m_findcol, len)) {
                        m_found = true;
                        return;
                    }
                }
            }
            else if (strncmp(m_findtext.c_str(), line.c_str() + m_findcol, len) == 0)   {
                if (!whole || isword(line.c_str(), m_findcol, len)) {
                    m_found = true;
                    return;
                }
            }
            --m_findcol;
        }
        if (--m_findrow >= 0)
            m_findcol = GetDocument()->textline(m_findrow).length();
    }
}

////////////////////////////////////////////////////////
// undo/redo functions

void CEditorView::OnEditUndo()
{
    m_buildcomments = true;
    m_pEditorSelection->UnmarkSelection();
    GetDocument()->OnEditUndo();
}

void CEditorView::OnEditRedo()
{
    m_buildcomments = true;
    m_pEditorSelection->UnmarkSelection();
    GetDocument()->OnEditRedo();
}

BOOL CEditorView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
    SetCursor(m_recording ? m_hRecordCursor : m_hArrowCursor);
    return true;
}

void CEditorView::OnFileOpen()
{
    m_buildcomments = true;
    m_ctrldown = false;         // in case of Ctrl+O
    theApp.OnFileOpen();
}

void CEditorView::OnFilePrint()
{
    m_ctrldown = false;         // in case of Ctrl+P
    CView::OnFilePrint();
}

void CEditorView::OnUpdateFileSaveAll(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(true);
}

// ------- brace matching
void CEditorView::OnUpdateBracematch(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(IsSourceCodeFile() && CanMatchBraces());
}

/* ensure that brace/parenthesis character is not character or string
 * literal and not in a comment
 */
bool CEditorView::IsSpecificBraceParen(char ch, int row, int col)
{
    if (GetDocument()->textchar(row, col) != ch)
        return false;
    if (col > 0 && IsCharLiteral(row, col))
        return false;
    if (IsContextElement(row, col) && IsContextElement(row, col + 1))
        return false;
    return true;
}

#ifdef _DEBUG
void CEditorView::DumpContextTable()
{
    std::set<CodeElement>::iterator iter;
    TRACE("\n -------- Context Table ----------");
    for (iter = m_contexttable.begin(); iter != m_contexttable.end(); iter++)   {
        CodeElement cmt = *iter;
        TRACE("\nLine %02d: Char %02d: Clr %06x", cmt.line, cmt.charpos, cmt.color);
    }
    TRACE("\n -------- End of Context Table ----------\n");
}
#endif

bool CEditorView::IsContextElement(int row, int col)
{
    CodeElement ce;
    ce.line = row;
    ce.charpos = col;

    std::set<CodeElement>::const_iterator it = std::lower_bound(m_contexttable.begin(), m_contexttable.end(), ce);
    if (it == m_contexttable.end())
        return false;
    if (it != m_contexttable.begin())
        --it;
    return (*it).color != theApp.NormalColor();
}

bool CEditorView::IsCharLiteral(int row, int col)
{
    const std::string& str = GetDocument()->textline(row);
    if (col < str.length()-1)   {
        if (GetDocument()->textchar(row, col-1) == '\'')
            if (GetDocument()->textchar(row, col+1) == '\'')
                return true;
    }
    return false;
}

bool CEditorView::FindBraceParenthesisMatch(HighlightPosition *pos, int limitsearch)
{
#if defined _DEBUG && 0
    DumpContextTable();
#endif
#define IsOpenMatch(b,d,c,r)    ((b) ? ((d)>0 ? IsLeftBrace((r),(c)) : IsRightBrace((r),(c))) : ((d)>0 ? IsLeftParenthesis((r),(c)) : IsRightParenthesis((r),(c))))
#define IsCloseMatch(b,d,c,r)   ((b) ? ((d)>0 ? IsRightBrace((r),(c)) : IsLeftBrace((r),(c))) : ((d)>0 ? IsRightParenthesis((r),(c)) : IsLeftParenthesis((r),(c))))

    // --- these are zero-based
    int row = m_currentrow;
    int col = m_currentcolumn;
    int lowmark = 0;
    int highmark = GetDocument()->linecount();
    pos->Clear();

    // First try to match with a brace/parenthesis *before* the cursor;
    // if that fails, match a brace/parenthesis *at* the cursor. The reason
    // is that when a user types a closing brace/parenthesis, you want the
    // matching opening brace/parenthesis to be highlighted, but the cursor
    // is now behind it.
    if (col>0 && (IsLeftBrace(row,col-1) || IsRightBrace(row,col-1) || IsLeftParenthesis(row,col-1) || IsRightParenthesis(row,col-1)))
        col--;

    ASSERT(IsLeftBrace(row,col) || IsRightBrace(row,col) || IsLeftParenthesis(row,col) || IsRightParenthesis(row,col));
    bool isbrace = IsLeftBrace(row, col) || IsRightBrace(row, col);
    int delta = (IsLeftBrace(row, col) || IsLeftParenthesis(row, col)) ? 1 : -1;
    int nests = 0;

    // Optionally limit the search range (so that the search will be faster)
    if (limitsearch > 0) {
        if (lowmark < row - limitsearch)
            lowmark =  row - limitsearch;
        if (highmark > row + limitsearch)
            highmark = row + limitsearch;
    } /* if */

    while (0 <= row && row < highmark)  {
        int len = GetDocument()->textline(row).length();
        if (delta <0 && col == 0)
            col = len - 1;
        while (0 <= col && col < len)   {
            if (IsOpenMatch(isbrace, delta, col, row)) {
                nests++;
            } else if (IsCloseMatch(isbrace, delta, col, row)) {
                if (--nests == 0) {
                    pos->Set(col, row);
                    return true;
                } /* if */
            } /* if */
            col += delta;
        } /* while */
        row += delta;
        col = 0;    /* this is reset at the top of the loop, in case delta == -1 */
    } /* while */
    return false;
}

void CEditorView::OnBracematch()
{
    HighlightPosition pos;
    if (FindBraceParenthesisMatch(&pos)) {
        SetCurrentRow(pos.Row());
        m_currentcolumn = pos.Column();
        AdjustScrollQuietly();
    } else {
        MessageBeep(MB_ICONSTOP);
        m_ctrldown = false;
    } /* if */
}

// ----- code beautifier (reformatter)
void CEditorView::Beautify()
{
    PageHome();
    m_pEditorSelection->UnmarkSelection();
    beautifiedtext.clear();
    CString strExe = theApp.Enquote(theApp.QuincyBinPath() + "\\uncrustify.exe ");
    CString strArgs;
    strArgs.Format("-l PAWN -q -c \"%s\"", theApp.BeautifierConfig());
    delete m_pConsoleApp;
    m_pConsoleApp = new ConsoleApp(strExe, &Notify, &Collect);
    try {
        m_pConsoleApp->Run(strArgs);

        int lines = GetDocument()->linecount();
        if (lines != 0) {
            for (int i = 0; i < lines; i++) {
                std::string str = GetDocument()->textline(i);
                CEditorDoc::entab(str);
                m_pConsoleApp->WriteConsole(str.c_str());
//              TRACE("\nOUT: %s", str.c_str());
            }
        }
        char ctrlz[2] = {26,0};
        m_pConsoleApp->WriteConsole(ctrlz);
    }
    catch(...)  {
        AfxMessageBox("\nCannot execute the beautifier \"Uncrustify\".", MB_ICONSTOP);
    }
}

// --- called from the console application thread while beautifying is going on
void CEditorView::Collect(DWORD bufct)
{
    ASSERT(pEditor != 0);
    pEditor->CollectSourceLines(bufct);
}

void CEditorView::CollectSourceLines(DWORD bufct)
{
    char *line = new char[bufct+1];
    ASSERT(m_pConsoleApp);
    if (m_pConsoleApp->ReadConsole(line, bufct) != 0)   {
//      TRACE("\nIN:  %s", line);
        std::string str(line);
        CEditorDoc::detab(str);
        beautifiedtext.push_back(str);
    }
    delete [] line;
}

void CEditorView::Notify()
{
    ASSERT(pEditor != 0);
    pEditor->NotifyTermination();
}

void CEditorView::NotifyTermination()
{
//  TRACE("\n---done---\n");
    beautifiedtext.push_back(std::string());
    GetDocument()->ReplaceDocument(beautifiedtext);
    beautifiedtext.clear();
    BuildContextHighlightTable();
    Invalidate(TRUE);
    delete m_pConsoleApp;
    m_pConsoleApp = 0;
    pEditor = 0;
}

void CEditorView::OnUpdateBeautify(CCmdUI* pCmdUI)
{
    pCmdUI->Enable(pEditor == 0 && theApp.BeautifierIsInstalled() && IsSourceCodeFile());
}

void CEditorView::OnBeautify()
{
    CBeautifier bt;
    bt.m_style = theApp.BeautifierStyle();
    //bt.m_configfile = theApp.BeautifierConfig();
    if (bt.DoModal() == IDOK)   {
        pEditor = this;
        theApp.SetBeautifierStyle(bt.m_style);
        theApp.SetBeautifierConfig(bt.m_configfile);
        Beautify();
    }
}


// ---- Editor calls this function for every character typed.
//      Use the CEditorView and CEditorDoc APIs to extend the editor.
//      return true if you don't want Editor to further process the keystroke
bool CEditorView::ExtendEditor(UINT nChar)
{
    bool result = false;

    switch (nChar) {
    case VK_RETURN:
        if (InfoTipActiveIndex >= 0 && InfoTip.IsVisible())
            return false;   /* handle autocompletion list selection elsewhere */
        if (theApp.AutoIndentOption()) {
            InfoTip.Hide();
            InfoTipActiveIndex = -1;
            AutoIndent();
            result = true;
        } /* if */
        if (theApp.RepeatBullet()) {
            int lno = CurrentLineNumber();  // one-based line number
            if (lno > 1) {
                const std::string& line = GetDocument()->textline(lno-2);  // get previous line
                const char *ptr = line.c_str();
                bool add_space = false;
                while (*ptr <= ' ' && *ptr != '\0')
                    ptr++;                  // skip white space
                if (*ptr == '/' && *(ptr+1) == '*' && strstr(ptr+1, "*/") == NULL) {
                    ptr++;                  // skip start of C comment
                    add_space = true;
                } /* if */
                if (*ptr == '*' && (*(ptr+1) == ' ' || *(ptr+1) == '*' && *(ptr+2) == ' ')) {   // bullet found
                    if (add_space) {
                        if (m_recording)
                            RecordCommand(new Char(this, ' '));
                        InsertCharacter(' ');
                        CaretRight();
                    } /* if */
                    if (m_recording)
                        RecordCommand(new Char(this, *ptr));
                    InsertCharacter(*ptr);
                    CaretRight();
                    if (*(ptr+1) == '*') {
                        if (m_recording)
                            RecordCommand(new Char(this, *(ptr+1)));
                        InsertCharacter(*(ptr+1));
                        CaretRight();
                    } /* if */
                    if (m_recording)
                        RecordCommand(new Char(this, ' '));
                    InsertCharacter(' ');
                    CaretRight();
                } /* if */
            } /* if */
            result = true;
        } /* if */
        break;
    } /* switch */

    return result;
}
// --- automatic indenting puts insertion caret and any following text
//     under leftmost character of previous line after user presses Enter key
void CEditorView::AutoIndent()
{
    int lno = CurrentLineNumber(); // one-based line number
    ASSERT(lno > 0);
    SplitLine();
    CaretRight();

    // next line moved down from 2 statements up as it was returning a
    // reference that was invalidated in splitline, crashing on new files/
    const std::string& line = GetDocument()->textline(lno-1);  // zero-based to get current line
    int len = line.length();
    int i;
    for (i = 0; i < len; i++)
        if (line[i] != '\t' && line[i] != HARDSPACE && line[i] != ' ')
              break;
    int tbs = theApp.Tabstops();
    if (theApp.TabOption() == 0)    {
        while (i >= tbs)    {
            InsertCharacter('\t', false);
            i -= tbs;
            CaretRight();
        }
    }
    while (i-- > 0) {
        InsertCharacter(' ', false);
        CaretRight();
    }
}

void CEditorView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView)
{
    InfoTip.Hide();
    InfoTipActiveIndex = -1;
    CView::OnActivateView(bActivate, pActivateView, pDeactiveView);
    theApp.RegisterView(pEditor);
}

void CEditorView::UpdateTitle(CDocument* pDoc)
{
    CString caption;
    CWnd* pWnd = GetParent();
    ASSERT(pWnd != 0);
    pWnd->GetWindowText(caption);
    if (!caption.IsEmpty()) {
        bool tagged = caption[caption.GetLength()-1] == '*';
        ASSERT(pDoc != 0);
        if (pDoc->IsModified()) {
            if (!tagged)
                pWnd->SetWindowText(caption + " *");
        }
        else if (tagged)
            pWnd->SetWindowText(caption.Left(caption.GetLength()-2));
    }
}

std::string CEditorView::SelectedText()
{
    std::string sstr;
    ASSERT(m_pEditorSelection);
    if (m_pEditorSelection->IsSelectionMarked())    {
        ViewIndex begin, end;
        m_pEditorSelection->GetSelectionMarkers(begin, end);
        if (begin.row == end.row)
            // --- the selection is all on one line
            SelectionToString(sstr);
    }
    else    {
        const std::string& str = GetDocument()->textline(m_currentrow);
        if (!str.empty()) {
            int col = m_currentcolumn;
            if (iswordchar(str[col]))   {
                while (col > 0 && iswordchar(str[col]))
                    --col;
                if (!iswordchar(str[col]))
                    col++;
                do
                    sstr += str[col++];
                while (iswordchar(str[col]));
            }
        }
    }
    return sstr;
}

void CEditorView::OnGotoline()
{
    static long linenr = 1;
    GotoLineDlg gotoDlg;
    gotoDlg.m_LineNr = linenr;
    if (gotoDlg.DoModal() == IDOK) {
        linenr = gotoDlg.m_LineNr;
        if (linenr > GetDocument()->linecount())
            linenr = GetDocument()->linecount();
        SetLineColumn(linenr, 1);
        theApp.ShowLineColumn(linenr, 1);
    } /* if */
}

void CEditorView::OnGotoSymbol()
{
	/* get the symbol below the cursor */
    std::string str = SelectedText();
	if (str.length() == 0) {
		MessageBox("No symbol at cursor", "Locate symbol", MB_OK|MB_ICONEXCLAMATION);
		return;
	} /* if */

	/* look up the symbol in the list */
	CString symbol = str.c_str();
	CString filename;
	int line;
	int result = ((CMainFrame*)theApp.m_pMainWnd)->LookupSymbol(symbol, &filename, &line, NULL, NULL);
	if (result == 0) {
		MessageBox("Symbol \"" + symbol + "\"not found.", "Locate symbol", MB_OK|MB_ICONEXCLAMATION);
		return;
	} /* if */

	/* jump to it */
	theApp.SelectFileAndLine(filename, line, false, symbol);
}

void CEditorView::OnAutocomplete()
{
    InfoTip.Hide();
    InfoTipActiveIndex = -1;
    CPoint cursor = CPoint(m_currentcolumn, m_currentrow);
    if (cursor.x > 0)
        cursor.x--;
    cursor = CharToScreenCoordinates(cursor);
    if (InfoTip.Show(&cursor, FALSE, 0)) {
        /* Show() returns FALSE if the callback returns NULL.
         * The callback return NULL if the matched info is an empty string.
         * When showing partial matches, only longer words match, so when
         * there are no *longer* words in the list than the keyword, the
         * matched info is empty.
         * This means that if Show() returns TRUE, an expansion is possible.
         */
        InfoTipActiveIndex = 0;
        /* Now check whether this is is single match (expand immediately) */
        CString WordString = InfoTip.GetText();
        if (WordString.GetLength() > 0 && WordString.Find("<br>") < 0) {
            AutoComplete();
            ASSERT(InfoTipActiveIndex == -1);
        } /* if */
    } else {
        /* no expansion possible, word already complete */
        ASSERT(InfoTipActiveIndex == -1);
        InfoTip.Show(&cursor);
    } /* if */
}

void CEditorView::OnTab2Space()
{
    CEditorDoc* pDoc = GetDocument();

    /* run through the current file, replacing all TABs by spaces */
    int lines = pDoc->linecount();
    if (lines == 0)
        return;

    int i;
    std::string tabstr;
    for (i = 0; i < theApp.Tabstops(); i++)
        tabstr += " ";

    bool first_undo = true;
    for (i = 0; i < lines; i++) {
        bool modif = false;
        std::string str = pDoc->textline(i);
        CEditorDoc::entab(str);
        std::string::size_type pos;
        while ((pos = str.find('\t')) != std::string::npos ) {
            str.erase(pos, 1);
            str.insert(pos, tabstr);
            modif = true;
        } /* while */
        if (modif) {
            /* CEditorDoc::detab(str) is not necessary, because there are no TABs left */
            pDoc->replaceline(i, str, first_undo);
            first_undo = false;
        } /* if */
    } /* for */
}


void CEditorView::Tab2Space(bool indent_only)
{
    CEditorDoc* pDoc = GetDocument();

    int lines = pDoc->linecount();
    if (lines == 0)
        return;

    bool first_undo = true;
    int stops = theApp.Tabstops();
    for (int i = 0; i < lines; i++) {
        bool modif = false;
        std::string str = pDoc->textline(i);
        CEditorDoc::entab(str);
        std::string::size_type idx, pos;
        int len = str.length();
        for (idx = pos = 0; idx < len; idx++) {
            if (str[idx] == '\t')
                pos += stops;
            else
                pos++;
            if (str[idx] == ' ' && pos % stops == 0) {
                /* last character before a TAB stop is a space, see how many
                 * TABs we can remove (but verify that span does not exceed 1 TAB)
                 */
                std::string::size_type start = idx;
                std::string::size_type spos = pos;
                while (start > 0 && str[start-1] == ' ' && (spos - 1) % stops != 0) {
                    start--;
                    spos--;
                } /* while */
                /* we wish to avoid converting a single space between two words
                 * to a TAB (in fact, this cannot happen if converting indent
                 * spacing only)
                 */
                if (idx - start > 0 || idx + 1 < len && str[idx] <= ' ') {
                    /* replace the subrange of spaces with a TAB */
                    str.erase(start, (idx - start + 1));
                    str.insert(start, "\t");
                    idx = start;    /* adjust current position and string length */
                    len = str.length();
                    modif = true;
                } /* if */
            } else if (indent_only && str[idx] > ' ') {
                break;
            } /* if */
        } /* for */
        if (modif) {
            CEditorDoc::detab(str);
            pDoc->replaceline(i, str, first_undo);
            first_undo = false;
        } /* if */
    } /* for */
}

void CEditorView::OnIndentTabs()
{
    Tab2Space(true);
}

void CEditorView::OnSpace2Tab()
{
    Tab2Space(false);
}
