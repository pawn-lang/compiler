#if !defined(AFX_GDBCONSOLE_H__7C07D193_9749_4568_BB31_9FC54977B4CD__INCLUDED_)
#define AFX_GDBCONSOLE_H__7C07D193_9749_4568_BB31_9FC54977B4CD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GdbConsole.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// GdbConsole dialog

class GdbConsole : public CDialog
{
// Construction
	void scroll(CListBox* pList);
public:
	GdbConsole(CWnd* pParent = 0);   // standard constructor
	void AddString(const char* str);
	void AppendString(const char* str);
	void ClearConsole();

	void SetAutoClose(BOOL value = TRUE) { AutoClose = value; }
	BOOL IsAutoClose() { return AutoClose; }

// Dialog Data
	//{{AFX_DATA(GdbConsole)
	enum { IDD = IDD_GDBCONSOLE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(GdbConsole)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

private:
	BOOL AutoClose;
	CFont fntMono;

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(GdbConsole)
		// NOTE: the ClassWizard will add member functions here
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GDBCONSOLE_H__7C07D193_9749_4568_BB31_9FC54977B4CD__INCLUDED_)
