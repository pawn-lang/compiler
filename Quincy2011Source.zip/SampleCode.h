#if !defined(AFX_SAMPLECODE_H__618D2764_7485_11D4_A77C_00207815827F__INCLUDED_)
#define AFX_SAMPLECODE_H__618D2764_7485_11D4_A77C_00207815827F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// SampleCode.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSampleCode window

class CSampleCode : public CEdit
{
	bool testfont(int ht);
	void AdjustFont(int adj);
// Construction
public:
	CSampleCode();

// Attributes
public:
	COLORREF m_backgroundcolor;
	COLORREF m_normalcolor;
	COLORREF m_keywordcolor;
	COLORREF m_operatorcolor;
	COLORREF m_commentcolor;
	COLORREF m_stringcolor;
	COLORREF m_numbercolor;
	COLORREF m_activerowcolor;
	int m_tabstops;
	bool m_syntaxcolor;
	int m_fontheight;
	int m_fontweight;
	TCHAR m_fontname[LF_FACESIZE];
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSampleCode)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSampleCode();
	void IncreaseFont();
	void DecreaseFont();
	void DefaultFont();
	void ChangeFont(LPCTSTR name, int height, int weight);
	// Generated message map functions
protected:
	//{{AFX_MSG(CSampleCode)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAMPLECODE_H__618D2764_7485_11D4_A77C_00207815827F__INCLUDED_)
