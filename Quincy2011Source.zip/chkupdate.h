#ifndef CHKUPDATE_H
#define CHKUPDATE_H

#if defined __cplusplus
  extern "C" {
#endif

enum UPDATE_VERNUMBER {
  CHK_FULLVERSION,	/**< check full version number (only equality) */
  CHK_MAJOR,		/**< check major version number */
  CHK_MAJOR_MINOR,	/**< check major + minor version numbers */
  CHK_BUILD,		/**< check build number only */
};

BOOL CheckUpdate(LPCSTR Topic, enum UPDATE_VERNUMBER NumberPart, LPCSTR key, LPCSTR KeyVersion, LPCSTR KeyStamp, LPCSTR Profile);

#if defined __cplusplus
  }
#endif

#endif /* CHKUPDATE_H */
