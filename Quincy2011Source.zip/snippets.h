/* snippets */

#ifndef SNIPPETS_H
#define SNIPPETS_H

#include <set>

class CSnippets
{
public:
	void insert(CString keyword, CString replacement, bool needtranslation = true);
	void load();
	void save();
	void clear()
		{ List.clear(); }
	const std::string lookup(std::string keyword);

	void translatespecials(CString& str, bool internal);

	std::map<std::string, std::string> List;

private:
	void trimspaces(std::string& string);
};

#endif /* SNIPPETS_H */
