#if !defined(AFX_GENERALOPTIONS_H__7CA95BB6_9F5E_445A_8B22_8DD421FE92D8__INCLUDED_)
#define AFX_GENERALOPTIONS_H__7CA95BB6_9F5E_445A_8B22_8DD421FE92D8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GeneralOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptions dialog

class CGeneralOptions : public CPropertyPage
{
// Construction
public:
	CGeneralOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGeneralOptions)
	enum { IDD = IDD_GENERAL_OPTIONS };
	BOOL	m_CheckForUpdates;
	BOOL	m_ShowCmdLine;
	BOOL	m_ClearBuildMsg;
	BOOL	m_ClearLogMsg;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGeneralOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGeneralOptions)
	afx_msg void OnCheckForUpdate();
	afx_msg void OnCheckUpdateBtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GENERALOPTIONS_H__7CA95BB6_9F5E_445A_8B22_8DD421FE92D8__INCLUDED_)
