// ExamineDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CExamineDialog dialog

class CExamineDialog : public CDialog
{
// Construction
public:
	CExamineDialog(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CExamineDialog)
	enum { IDD = IDD_EXAMINE };
	CString	m_strExpression;
	CString	m_strNewValue;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExamineDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CExamineDialog)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
