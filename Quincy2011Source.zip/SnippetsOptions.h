#if !defined(AFX_SNIPPETSOPTIONS_H__0C2BB219_B86F_458F_BC8B_934BC3FAC894__INCLUDED_)
#define AFX_SNIPPETSOPTIONS_H__0C2BB219_B86F_458F_BC8B_934BC3FAC894__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SnippetsOptions.h : header file
//

#include "snippets.h"
#include "ReportCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CSnippetsOptions dialog

class CSnippetsOptions : public CPropertyPage
{
// Construction
public:
	CSnippetsOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSnippetsOptions)
	enum { IDD = IDD_SNIPPETS_OPTIONS };
	CReportCtrl	m_List;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSnippetsOptions)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSnippetsOptions)
	virtual BOOL OnInitDialog();
	afx_msg void OnItemchangedSnippetlist(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	// --- insertable snippets
	CSnippets Snippets;
	bool m_InitDone;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SNIPPETSOPTIONS_H__0C2BB219_B86F_458F_BC8B_934BC3FAC894__INCLUDED_)
