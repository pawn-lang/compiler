// TutDlg.h : header file
//
#ifndef TUTDLG_H
#define TUTDLG_H

/////////////////////////////////////////////////////////////////////////////
// CTutDlg dialog

class CTutDlg : public CDialog
{
	CString m_strTutorialPath;
	CString m_strTocName;
	CString m_strChapterNo;
	int m_nImages[6];
	enum { maxentries = 500 };
	UINT m_nEntries;

	struct	{
		unsigned char m_nLevel;
		HTREEITEM m_hItem;
	} m_TreeEntry[maxentries];

	HTREEITEM m_hRootItem;
	CImageList m_imgList;

	HINSTANCE hinstRichEdit;

// Construction
public:
	CTutDlg(const CString& strTocName, const CString& strTutorialPath);
	~CTutDlg();				// destructor
	void LoadSelectedTutorial()
		{ /*OnOK();*/ }

// Dialog Data
	//{{AFX_DATA(CTutDlg)
	enum { IDD = IDD_TUTORIAL };
	CTreeCtrl	m_ExerciseTree;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTutDlg)
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDblclkExercisetree(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnCancel();
	afx_msg void OnSelchangedExercisetree(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void OpenExercise(const CString& strTutorial);
};

#endif
