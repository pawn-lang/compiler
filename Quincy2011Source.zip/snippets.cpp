/* Snippet interface
 * $Id: snippets.cpp 3982 2008-07-18 10:34:09Z thiadmer $
 */

#include "stdafx.h"
#include "quincy.h"
#include "snippets.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define BUFFERSIZE	32768

void CSnippets::load()
{
	CString keywords;
	char *keyword = keywords.GetBuffer(BUFFERSIZE);
	::GetPrivateProfileString("Snippets", NULL, "", keyword, BUFFERSIZE, theApp.m_pszProfileName);

	while (*keyword != '\0') {
		CString repl = theApp.GetProfileString("Snippets", keyword);
		/* replace special characters */
		translatespecials(repl, true);
		/* add it to the list */
		List.insert(std::make_pair(keyword, repl));
		keyword += strlen(keyword) + 1;
    } /* while */
}

void CSnippets::save()
{
	/* erase the section */
	::WritePrivateProfileString("Snippets", NULL, NULL, theApp.m_pszProfileName);

	/* walk through all items */
	std::map<std::string,std::string>::iterator iter;
	for (iter = List.begin(); iter != List.end(); iter++) {
		std::string keyword = iter->first;
		if (keyword.length() > 0) {
			CString repl = iter->second.c_str();
			translatespecials(repl, false);
			theApp.WriteProfileString("Snippets", keyword.c_str(), repl);
		} /* if */
	} /* for */
}

void CSnippets::insert(CString keyword, CString replacement, bool needtranslation)
{
	if (needtranslation)
		translatespecials(replacement, true);
	List.insert(std::make_pair(keyword, replacement)); 
}

const std::string CSnippets::lookup(std::string keyword)
{
	std::map<std::string,std::string>::iterator iter = List.find(keyword);
	if (iter != List.end())
		return iter->second;
	return std::string("");
}

void CSnippets::translatespecials(CString& str, bool internal)
{
	if (internal) {
		str.Replace("\\n", "\n");
		str.Replace("\\t", "\t");
		str.Replace("\\s", "\v");
		str.Replace("\\\\", "\\");	/* do this one last */
	} else {
		str.Replace("\\", "\\\\");	/* do this one first */
		str.Replace("\n", "\\n");
		str.Replace("\t", "\\t");
		str.Replace("\v", "\\s");
	} /* if */
}

void CSnippets::trimspaces(std::string& str)
{
	// Trim Both leading and trailing spaces
	const char spacelist[] = " \t\n";
	size_t startpos = str.find_first_not_of(spacelist);	// Find the first character position after excluding leading blank spaces
	size_t endpos = str.find_last_not_of(spacelist);	// Find the first character position from reverse af

	// if all spaces or empty return an empty string
	if (std::string::npos == startpos || std::string::npos == endpos)
		str = "";
	else
		str = str.substr(startpos, endpos - startpos + 1);
}
