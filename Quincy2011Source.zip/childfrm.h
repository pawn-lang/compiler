// ChildFrm.h : interface of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////

#include "EditorView.h"

class CChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CChildFrame)
	CView* m_pview;
public:
	CChildFrame();
	virtual ~CChildFrame();
	void RegisterView(CView* pcv)
		{ m_pview = pcv; }
protected:
	virtual void OnContextMenu(CWnd *pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
};

