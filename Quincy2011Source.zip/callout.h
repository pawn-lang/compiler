/*****************************************************************************\
*                                                                             *
* callout.h   -- Interface for the "Callout" control                          *
*                                                                             *
* By Thiadmer Riemersma, for Windows Developer Magazine                       *
*                                                                             *
\*****************************************************************************/

#ifndef __CALLOUT_H
#define __CALLOUT_H


/* Class name, for CreateWindow() */
#define CALLOUT_CLASSA          "Callout"
#define CALLOUT_CLASSW          L"Callout"

#ifdef UNICODE
  #define  CALLOUT_CLASS        CALLOUT_CLASSW
#else
  #define  CALLOUT_CLASS        CALLOUT_CLASSA
#endif


/* Callout tail styles */
#define CS_SPEAK  0
#define CS_THINK  1

/* Callout preferred alignment */
#define CS_ALIGNABOVE 0
#define CS_ALIGNBELOW 1

/* Callout messages */
#define CM_GETANCHOR            (WM_USER + 1) /* screen coordinates */
#define CM_SETANCHOR            (WM_USER + 2)
#define CM_GETRECT              (WM_USER + 3) /* balloon rectangle */
#define CM_GETMINWIDTH          (WM_USER + 4)
#define CM_SETMINWIDTH          (WM_USER + 5)
#define CM_GETEXTRAHEIGHT       (WM_USER + 6)
#define CM_SETEXTRAHEIGHT       (WM_USER + 7)
#define CM_GETRADIUS            (WM_USER + 8)
#define CM_SETRADIUS            (WM_USER + 9)
#define CM_GETBORDER            (WM_USER + 10)
#define CM_SETBORDER            (WM_USER + 11)
#define CM_GETTAILSTYLE         (WM_USER + 12)
#define CM_SETTAILSTYLE         (WM_USER + 13)
#define CM_GETTAILSLANT         (WM_USER + 14)
#define CM_SETTAILSLANT         (WM_USER + 15)
#define CM_GETTAILHEIGHT        (WM_USER + 16)
#define CM_SETTAILHEIGHT        (WM_USER + 17)
#define CM_GETTAILOFFSET        (WM_USER + 18)
#define CM_SETTAILOFFSET        (WM_USER + 19)
#define CM_GETTAILJOIN          (WM_USER + 20)
#define CM_SETTAILJOIN          (WM_USER + 21)
#define CM_GETTAILWIDTH         (WM_USER + 22)
#define CM_SETTAILWIDTH         (WM_USER + 23)
#define CM_GETTIMEOUT           (WM_USER + 24)
#define CM_SETTIMEOUT           (WM_USER + 25)
#define CM_GETTEXTCOLOR         (WM_USER + 26)
#define CM_SETTEXTCOLOR         (WM_USER + 27)
#define CM_GETBACKCOLOR         (WM_USER + 28)
#define CM_SETBACKCOLOR         (WM_USER + 29)
#define CM_GETDRAWTEXTPROC      (WM_USER + 30)
#define CM_SETDRAWTEXTPROC      (WM_USER + 31)
#define CM_GETVERTALIGN         (WM_USER + 32)
#define CM_SETVERTALIGN         (WM_USER + 33)
#define CM_GETREFORMATTEXT      (WM_USER + 34)
#define CM_SETREFORMATTEXT      (WM_USER + 35)


/* Notification messages */
#define CN_FIRST                ((UINT)-751)
#define CN_LAST                 ((UINT)-760)
#define CN_SHOW                 (CN_FIRST - 1)
#define CN_POP                  (CN_FIRST - 2)


/* Helper macros */

#ifndef SNDMSG
  #define undef_SNDMSG
  #ifdef __cplusplus
    #define SNDMSG ::SendMessage
  #else
    #define SNDMSG SendMessage
  #endif
#endif

#define Callout_GetAnchor(hwnd) \
            SNDMSG(hwnd, CM_GETANCHOR, 0, 0)
#define Callout_GetBackColor(hwnd) \
            SNDMSG(hwnd, CM_GETBACKCOLOR, 0, 0)
#define Callout_GetBorder(hwnd) \
            (int)SNDMSG(hwnd, CM_GETBORDER, 0, 0)
#define Callout_GetDrawTextProc(hwnd) \
            (FARPROC)SNDMSG(hwnd, CM_GETDRAWTEXTPROC, 0, 0)
#define Callout_GetExtraHeight(hwnd) \
            SNDMSG(hwnd, CM_GETEXTRAHEIGHT, 0, 0)
#define Callout_GetMinWidth(hwnd) \
            SNDMSG(hwnd, CM_GETMINWIDTH, 0, 0)
#define Callout_GetRadius(hwnd) \
            (int)SNDMSG(hwnd, CM_GETRADIUS, 0, 0)
#define Callout_GetRect(hwnd) \
            (LPRECT)SNDMSG(hwnd, CM_GETRECT, 0, 0)
#define Callout_GetReformatText(hwnd) \
            (int)SNDMSG(hwnd, CM_GETREFORMATTEXT, 0, 0)
#define Callout_GetTailHeight(hwnd) \
            (int)SNDMSG(hwnd, CM_GETTAILHEIGHT, 0, 0)
#define Callout_GetTailJoin(hwnd) \
            (int)SNDMSG(hwnd, CM_GETTAILJOIN, 0, 0)
#define Callout_GetTailOffset(hwnd) \
            (int)SNDMSG(hwnd, CM_GETTAILOFFSET, 0, 0)
#define Callout_GetTailSlant(hwnd) \
            (int)SNDMSG(hwnd, CM_GETTAILSLANT, 0, 0)
#define Callout_GetTailStyle(hwnd) \
            (int)SNDMSG(hwnd, CM_GETTAILSTYLE, 0, 0)
#define Callout_GetTailWidth(hwnd) \
            (int)SNDMSG(hwnd, CM_GETTAILWIDTH, 0, 0)
#define Callout_GetTextColor(hwnd) \
            (int)SNDMSG(hwnd, CM_GETTEXTCOLOR, 0, 0)
#define Callout_GetTimeout(hwnd) \
            (int)SNDMSG(hwnd, CM_GETTIMEOUT, 0, 0)
#define Callout_GetVertAlign(hwnd) \
            (int)SNDMSG(hwnd, CM_GETVERTALIGN, 0, 0)
#define Callout_SetAnchor(hwnd, x, y) \
            SNDMSG(hwnd, CM_SETANCHOR, 0, MAKELONG((x), (y)))
#define Callout_SetBackColor(hwnd, Color, Repaint) \
            SNDMSG(hwnd, CM_SETBACKCOLOR, (WPARAM)(Color), \
                   MAKELPARAM((Repaint),0))
#define Callout_SetBorder(hwnd, Width, Repaint) \
            SNDMSG(hwnd, CM_SETBORDER, (Width), MAKELPARAM((Repaint),0))
#define Callout_SetDrawTextProc(hwnd, Proc, Repaint) \
            SNDMSG(hwnd, CM_SETDRAWTEXTPROC, (WPARAM)(Proc), \
                   MAKELPARAM((Repaint),0))
#define Callout_SetExtraHeight(hwnd, Height, Repaint) \
            SNDMSG(hwnd, CM_SETEXTRAHEIGHT, (Height), MAKELPARAM((Repaint),0))
#define Callout_SetMinWidth(hwnd, Width, Repaint) \
            SNDMSG(hwnd, CM_SETMINWIDTH, (Width), MAKELPARAM((Repaint),0))
#define Callout_SetRadius(hwnd, Radius, Repaint) \
            SNDMSG(hwnd, CM_SETRADIUS, (Radius), MAKELPARAM((Repaint),0))
#define Callout_SetReformatText(hwnd, Reformat, Repaint) \
            SNDMSG(hwnd, CM_SETREFORMATTEXT, (Reformat), MAKELPARAM((Repaint),0))
#define Callout_SetTailHeight(hwnd, Height, Repaint) \
            SNDMSG(hwnd, CM_SETTAILHEIGHT, (Height), MAKELPARAM((Repaint),0))
#define Callout_SetTailJoin(hwnd, Join, Repaint) \
            SNDMSG(hwnd, CM_SETTAILJOIN, (Join), MAKELPARAM((Repaint),0))
#define Callout_SetTailOffset(hwnd, Offset, Repaint) \
            SNDMSG(hwnd, CM_SETTAILOFFSET, (Offset), MAKELPARAM((Repaint),0))
#define Callout_SetTailSlant(hwnd, Slant, Repaint) \
            SNDMSG(hwnd, CM_SETTAILSLANT, (Slant), MAKELPARAM((Repaint),0))
#define Callout_SetTailStyle(hwnd, Style, Repaint) \
            SNDMSG(hwnd, CM_SETTAILSTYLE, (Style), MAKELPARAM((Repaint),0))
#define Callout_SetTailWidth(hwnd, Width, Repaint) \
            SNDMSG(hwnd, CM_SETTAILWIDTH, (Width), MAKELPARAM((Repaint),0))
#define Callout_SetTextColor(hwnd, Color, Repaint) \
            SNDMSG(hwnd, CM_SETTEXTCOLOR, (Color), MAKELPARAM((Repaint),0))
#define Callout_SetTimeout(hwnd, Timeout) \
            SNDMSG(hwnd, CM_SETTIMEOUT, 0, (Timeout))
#define Callout_SetVertAlign(hwnd, Alignment, Repaint) \
            SNDMSG(hwnd, CM_SETVERTALIGN, (Alignment), MAKELPARAM((Repaint),0))


#ifdef undef_SNDMSG
  #undef SNDMSG
  #undef undef_SNDMSG
#endif


/* Functions for static linking */
BOOL CalloutInit(HINSTANCE hInstance);
void CalloutCleanup(HINSTANCE hInstance);

#endif /* __CALLOUT_H */
