#ifndef SYMBROWSE_H
#define SYMBROWSE_H

// SymBrowseDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// SymBrowseDialog dialog

class CSymbolEntry
{
public:
	CSymbolEntry() : Next(0) {}
	bool Add(const CString &xmlfile, const CString &symname, const CString &syntax, 
		     const CString &summary, const CString &source, int line);
	void Remove(const CString &xmlfile = _T(""));

public:
	CString SymbolName;	// name plus type
	CString Syntax;		// name plus decoration
	CString Source;		// source file where the symbol is defined
	CString Summary;	// symbol documentation (summary)
	int Line;

	CString XMLfile;	// XML report file from which the declaration comes
	CSymbolEntry *Next;
};

class CSymBrowseDialog : public CDialog
{
	DECLARE_DYNAMIC(CSymBrowseDialog)

// Construction
public:
	CSymBrowseDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSymBrowseDialog();

// Dialog Data
	//{{AFX_DATA(CSymBrowseDialog)
	enum { IDD = IDD_SYMBROWSE };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSymBrowseDialog)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(SymBrowseDialog)
	afx_msg void OnDblclkTree(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnClose();
	virtual BOOL OnInitDialog();
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnExplicitClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	HTREEITEM AddSection(const CString &name);
	void RebuildTree(const CSymbolEntry *root);

	void Clear();
	bool LoadReportFile(const CString& file, bool RefreshTree = true);
	int LoadAllReportFiles(const CString& path);
	int LoadAllReportFiles();
	int Lookup(const CString &symbol, CString *filename, int *line,
		       CString *syntax, CString *summary, int nextmatch = -1);
private:
	CSymbolEntry SymbolList;
};

#endif /* SYMBROWSE_H */
