// GeneralOptions.cpp : implementation file
// $Id: GeneralOptions.cpp 4096 2009-03-26 12:12:45Z thiadmer $

#include "stdafx.h"
#include "quincy.h"
#include "GeneralOptions.h"
#include "chkupdate.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptions dialog


CGeneralOptions::CGeneralOptions(CWnd* pParent)
	: CPropertyPage(CGeneralOptions::IDD)
{
	//{{AFX_DATA_INIT(CGeneralOptions)
	m_CheckForUpdates = FALSE;
	m_ShowCmdLine = FALSE;
	m_ClearBuildMsg = FALSE;
	m_ClearLogMsg = FALSE;
	//}}AFX_DATA_INIT
}


void CGeneralOptions::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneralOptions)
	DDX_Check(pDX, IDC_CHECKFORUPDATES, m_CheckForUpdates);
	DDX_Check(pDX, IDC_SHOWCMDLINE, m_ShowCmdLine);
	DDX_Check(pDX, IDC_CLEARBUILDMSG, m_ClearBuildMsg);
	DDX_Check(pDX, IDC_CLEARLOGMSG, m_ClearLogMsg);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGeneralOptions, CPropertyPage)
	//{{AFX_MSG_MAP(CGeneralOptions)
	ON_BN_CLICKED(IDC_CHECKUPDATEBTN, OnCheckUpdateBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptions message handlers


void CGeneralOptions::OnCheckUpdateBtn() 
{
	const char Topic[] = "Pawn";
	const char UpdateURL[] = "PadURL";
	const char KeyStamp[] = "LastVersionCheck";
	WritePrivateProfileString(Topic, KeyStamp, NULL, theApp.m_pszProfileName);	// force an online check
	if (!CheckUpdate(theApp.GetCompilerVersion(), CHK_BUILD, Topic, UpdateURL, KeyStamp, theApp.m_pszProfileName))
		MessageBox("No new updates were found on-line.", "Quincy", MB_OK | MB_ICONINFORMATION);
}
