// ------- stabs.cpp
// $Id: Stabs.cpp 3787 2007-07-04 10:27:06Z thiadmer $

#include "stdafx.h"
#include "stabs.h"

#if !defined PAWN_CELL_SIZE
  #define PAWN_CELL_SIZE  32
#endif

#if PAWN_CELL_SIZE==16
  #define AMX_MAGIC     0xf1e2
#elif PAWN_CELL_SIZE==32
  #define AMX_MAGIC     0xf1e0
#elif PAWN_CELL_SIZE==64
  #define AMX_MAGIC     0xf1e1
#endif

#define AMX_FLAG_DEBUG    0x02  /* symbolic info. available */

CStab::CStab(const std::string& filename)
{
	has_symbols = false;
	// ---- open the executable file
    std::ifstream ifile(filename.c_str(), std::ios::binary);
	if (!ifile.fail())	{

		// ----- read the part of the AMX header
		unsigned short header[5];
		ifile.read((char*)&header, sizeof header);

		// ----- test AMX file signature
		if (header[2] == AMX_MAGIC) {
			// --- is an executable, check the flags
			has_symbols = (header[4] & AMX_FLAG_DEBUG) != 0;
		}
	}
}


