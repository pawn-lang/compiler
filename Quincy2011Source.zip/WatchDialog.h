// WatchDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWatchDialog dialog

class CWatchDialog : public CDialog
{
// Construction
	class CAddWatch* m_pdlgAddWatch;
public:
	CWatchDialog(CWnd* pParent = 0);   // standard constructor
	~CWatchDialog();
	void AddWatch()
		{ OnAddwatch(); }
	void AddSelectedWatch(const std::string& watch);
	void AddWatch(const CString& strWatch);
	void ClearWatches();
	int GetWatchCount();
	void GetWatchValue(int nSel, CString& strValue);
	void DisplayWatch(const CString& strVarName, const CString& strVarValue);
	CString* GetWatchNames();
	CListBox* GetWatchListbox();

// Dialog Data

	CString* Watches;

	//{{AFX_DATA(CWatchDialog)
	enum { IDD = IDD_WATCH };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWatchDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CWatchDialog)
	afx_msg void OnAddwatch();
	afx_msg void OnDeletewatch();
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDeletewatches();
	afx_msg void OnHelp();
	afx_msg void OnEditWatch();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
