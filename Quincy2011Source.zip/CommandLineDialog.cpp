// CommandLineDialog.cpp : implementation file
// $Id: CommandLineDialog.cpp 3787 2007-07-04 10:27:06Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "CommandLineDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCommandLineDialog dialog


CCommandLineDialog::CCommandLineDialog(CWnd* pParent)
	: CDialog(CCommandLineDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCommandLineDialog)
	m_strCommandLine = _T("");
	//}}AFX_DATA_INIT
}


void CCommandLineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCommandLineDialog)
	DDX_Text(pDX, IDC_CMDLINE, m_strCommandLine);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCommandLineDialog, CDialog)
	//{{AFX_MSG_MAP(CCommandLineDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCommandLineDialog message handlers
