// GotoLineDlg.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "GotoLineDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GotoLineDlg dialog


GotoLineDlg::GotoLineDlg(CWnd* pParent /*=NULL*/)
	: CDialog(GotoLineDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(GotoLineDlg)
	m_LineNr = 1;
	//}}AFX_DATA_INIT
}


void GotoLineDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GotoLineDlg)
	DDX_Text(pDX, IDC_GOTOLINE, m_LineNr);
	DDV_MinMaxLong(pDX, m_LineNr, 1, 2147483647);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(GotoLineDlg, CDialog)
	//{{AFX_MSG_MAP(GotoLineDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GotoLineDlg message handlers
