// ErrorLogDialog.h : header file
//

#include "XListBox.h"
#include "CustomTabCtrl.h"
#include "BalloonTip.h"
#include "rs232.h"

/////////////////////////////////////////////////////////////////////////////
// CErrorLogDialog dialog

class CErrorLogDialog : public CDialog
{
// Construction
public:
	CErrorLogDialog(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CErrorLogDialog)
	enum { IDD = IDD_ERRORLOG };
	CEdit	m_LogView;
	CCustomTabCtrl	m_Tabs;
	CXListBox		m_ErrorList;
	CXListBox		m_SearchList;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CErrorLogDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CErrorLogDialog)
	afx_msg void OnDblclkErrorlist();
	afx_msg void OnDblclkSearchlist();
	virtual void OnOK();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnClose();
	virtual BOOL OnInitDialog();
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnExplicitClose();
	afx_msg void OnChangeTab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnClear();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	void SwitchTab(int index);

	void AddBuildMessage(const CString& msg);
	void ClearBuildView();

	void AddLogMessage(const CString& msg);
	void ClearLogView();
	void StartLogMonitor();
	void StopLogMonitor();
	bool SuspendLogMonitor(bool enable=true);

	void AddSearchMessage(const CString& msg);
	void ClearSearchView();

private:
	CFont fntMono;
	int m_ErrorListWidth;			// width of the widest message in the build log
	int m_SearchListWidth;

	CBalloonTip InfoTip;

	bool m_logactive;
	bool m_logsuspended;
	bool m_autoswitchlog;
	RS232 comm;
public:
	afx_msg void OnSelChangeErrorlist();
	afx_msg void OnKillFocusErrorlist();
};
