// TextDocument.cpp : implementation file
// $Id: textdocument.cpp 4096 2009-03-26 12:12:45Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "TextDocument.h"
#include "debugger.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTextDocument

IMPLEMENT_DYNCREATE(CTextDocument, CEditorDoc)

CTextDocument::CTextDocument()
{
}

CTextDocument::~CTextDocument()
{
}

BEGIN_MESSAGE_MAP(CTextDocument, CEditorDoc)
	//{{AFX_MSG_MAP(CTextDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT, OnUpdateFilePrint)
	ON_UPDATE_COMMAND_UI(ID_DELETE_FILE, OnUpdateDeleteFile)
	ON_UPDATE_COMMAND_UI(ID_INSERT_FILE, OnUpdateInsertFile)
	ON_UPDATE_COMMAND_UI(ID_EXECUTE, OnUpdateExecute)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_BREAKPOINT, OnUpdateDebugBreakpoint)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_WATCH, OnUpdateDebugWatch)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_STEP, OnUpdateDebugStep)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_STEPOVER, OnUpdateDebugStepover)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_STEPTOCURSOR, OnUpdateDebugSteptocursor)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_STEPOUTOFFUNCTION, OnUpdateDebugStepoutoffunction)
	ON_UPDATE_COMMAND_UI(ID_DEBUG_TRANSFER, OnUpdateDebugTransfer)
	ON_UPDATE_COMMAND_UI(ID_NEXT_BREAKPOINT, OnUpdateNextBreakpoint)
	ON_UPDATE_COMMAND_UI(ID_PREV_BREAKPOINT, OnUpdatePrevBreakpoint)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextDocument diagnostics

#ifdef _DEBUG
void CTextDocument::AssertValid() const
{
	CEditorDoc::AssertValid();
}

void CTextDocument::Dump(CDumpContext& dc) const
{
	CEditorDoc::Dump(dc);
}
#endif //_DEBUG


// --- files you can compile
bool CTextDocument::IsSourceFile()
{
	CString& rstrPath = const_cast<CString&>(GetPathName());
	return rstrPath.Right(2).CompareNoCase(".p")    == 0 ||
		   rstrPath.Right(4).CompareNoCase(".pwn")  == 0 ||
		   rstrPath.Right(5).CompareNoCase(".pawn") == 0;
}

// --- files you can set breakpoints in
bool CTextDocument::IsExecutableSourceFile()
{
	CString& rstrPath = const_cast<CString&>(GetPathName());
	return rstrPath.Right(2).CompareNoCase(".p")    == 0 ||
		   rstrPath.Right(4).CompareNoCase(".pwn")  == 0 ||
		   rstrPath.Right(5).CompareNoCase(".pawn") == 0 ||
		   rstrPath.Right(4).CompareNoCase(".inc")  == 0;
}

/////////////////////////////////////////////////////////////////////////////
// CTextDocument commands

void CTextDocument::OnUpdateFilePrint(CCmdUI* pCmdUI) 
{
    pCmdUI->Enable(true);	
}

void CTextDocument::OnUpdateDeleteFile(CCmdUI* pCmdUI) 
{
    pCmdUI->Enable(false);	
}

void CTextDocument::OnUpdateInsertFile(CCmdUI* pCmdUI) 
{
    pCmdUI->Enable(false);	
}

void CTextDocument::OnUpdateExecute(CCmdUI* pCmdUI) 
{
	if (theApp.CompileRunning() || !theApp.CanCompile()) {
		pCmdUI->Enable(false);
		return;
	}
	Debugger* pDebugger = theApp.GetDebugger(false);
	if (pDebugger != 0)	{
		OnUpdateDebugWatch(pCmdUI);
		return;
	}
	bool canexecute = theApp.CanExecute() || theApp.CanDebug(DEBUG_BOTH);
	pCmdUI->Enable(IsSourceFile() && canexecute);
}

void CTextDocument::OnUpdateDebugBreakpoint(CCmdUI* pCmdUI) 
{
	if (theApp.CompileRunning() || !IsExecutableSourceFile() || !theApp.CanCompile()) {
		pCmdUI->Enable(false);
		return;
	}
	Debugger* pDebugger = theApp.GetDebugger(false);
	pCmdUI->Enable(pDebugger == 0 || !pDebugger->isInProgram());
}

void CTextDocument::OnUpdateNextBreakpoint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(theApp.BreakpointCount() > 0);
}

void CTextDocument::OnUpdatePrevBreakpoint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(theApp.BreakpointCount() > 0);
}

void CTextDocument::OnUpdateDebugStep(CCmdUI* pCmdUI) 
{
	if (theApp.CompileRunning() || !IsExecutableSourceFile() || !theApp.CanCompile()) {
		pCmdUI->Enable(false);
		return;
	}
	Debugger* pDebugger = theApp.GetDebugger(false);
	pCmdUI->Enable(pDebugger != 0 && !pDebugger->isInProgram());
}

void CTextDocument::OnUpdateDebugStepover(CCmdUI* pCmdUI) 
{
	OnUpdateDebugStep(pCmdUI);
}

void CTextDocument::OnUpdateDebugWatch(CCmdUI* pCmdUI) 
{
	if (theApp.CompileRunning() || !IsExecutableSourceFile() || !theApp.CanCompile()) {
		pCmdUI->Enable(false);
		return;
	}
	Debugger* pDebugger = theApp.GetDebugger(false);
	pCmdUI->Enable(pDebugger == 0 || !pDebugger->isInProgram());
}

void CTextDocument::OnUpdateDebugSteptocursor(CCmdUI* pCmdUI) 
{
	OnUpdateDebugStep(pCmdUI);
}

void CTextDocument::OnUpdateDebugStepoutoffunction(CCmdUI* pCmdUI) 
{
	OnUpdateDebugStep(pCmdUI);
}

void CTextDocument::OnUpdateDebugTransfer(CCmdUI* pCmdUI) 
{
	if (theApp.CompileRunning() || !theApp.CanCompile()) {
		pCmdUI->Enable(false);
		return;
	}
	if (theApp.GetDebugPort() == 0)	{
		pCmdUI->Enable(false);
		return;
	}
	pCmdUI->Enable(IsSourceFile());
}
