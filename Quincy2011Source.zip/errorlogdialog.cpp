// ErrorLogDialog.cpp : implementation file
// $Id: errorlogdialog.cpp 4523 2011-06-21 15:03:47Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "MainFrm.h"
#include "compiler.h"
#include "ErrorLogDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CErrorLogDialog dialog


CErrorLogDialog::CErrorLogDialog(CWnd* pParent)
	: CDialog(CErrorLogDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CErrorLogDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_ErrorListWidth = 0;
	m_SearchListWidth = 0;
	fntMono.CreateFont(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
						ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
						DEFAULT_QUALITY, FIXED_PITCH | FF_DONTCARE, "Andante");
	m_logactive = false;
	m_logsuspended = false;
	m_autoswitchlog = false;
}


void CErrorLogDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CErrorLogDialog)
	DDX_Control(pDX, IDC_LOGVIEW, m_LogView);
	DDX_Control(pDX, IDC_LOGTABS, m_Tabs);
	DDX_Control(pDX, IDC_ERRORLIST, m_ErrorList);
	DDX_Control(pDX, IDC_GREPLIST, m_SearchList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CErrorLogDialog, CDialog)
	//{{AFX_MSG_MAP(CErrorLogDialog)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_SHOWWINDOW()
	ON_WM_CLOSE()
	ON_WM_NCHITTEST()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDCLOSE, OnExplicitClose)
	ON_NOTIFY(CTCN_SELCHANGE, IDC_LOGTABS, OnChangeTab)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CLEAR, OnClear)
	ON_LBN_DBLCLK(IDC_ERRORLIST, OnDblclkErrorlist)
	ON_LBN_SELCHANGE(IDC_ERRORLIST, OnSelChangeErrorlist)
	ON_LBN_KILLFOCUS(IDC_ERRORLIST, OnKillFocusErrorlist)
	ON_LBN_DBLCLK(IDC_GREPLIST, OnDblclkSearchlist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CErrorLogDialog message handlers

int CErrorLogDialog::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	theApp.RestoreDialogWindowPosition("ErrorLog", this);
	SetTimer(1, 250, NULL);

	return 0;
}

void CErrorLogDialog::OnDestroy()
{
	theApp.SaveDialogWindowPosition("ErrorLog", this);
	KillTimer(1);
	StopLogMonitor();
	CDialog::OnDestroy();
}

BOOL CErrorLogDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	ShowWindow(SW_HIDE);
	SetParent((CMainFrame*)theApp.m_pMainWnd);
	((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(this->m_hWnd);

	m_ErrorList.SetFont(&fntMono);
	m_SearchList.SetFont(&fntMono);
	m_LogView.SetFont(&fntMono);
	m_LogView.SetLimitText(0xffffffff);

	// http://www.codeproject.com/KB/tabs/AMCustomTabCtrlDemo.aspx
	m_Tabs.ModifyStyle(0, CTCS_AUTOHIDEBUTTONS, 0);
	m_Tabs.InsertItem(0,"Build result");	// Pawn compiler messages
	m_Tabs.InsertItem(1,"Log messages");	// input received (RS232, Syslog or SNMP trap)
	m_Tabs.InsertItem(2,"Search results");	// GREP results
	SwitchTab(0);

    CRect rc;
    GetClientRect(&rc);
	PostMessage(WM_SIZE, SIZE_RESTORED, MAKELONG(rc.right, rc.bottom));

	// open COM port (if set up)
	if (theApp.GetIsLogEnabled())
		StartLogMonitor();

	InfoTip.CreateTipWnd(theApp.m_pMainWnd, "", 1000, TRUE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CErrorLogDialog::OnDblclkErrorlist()
{
	OnOK();
}

void CErrorLogDialog::OnDblclkSearchlist()
{
	OnOK();
}

void CErrorLogDialog::OnOK()
{
	switch (m_Tabs.GetCurSel()) {
	case 0:
		// -- get the current selection and send to CQuincyApp object
		theApp.SelectErrorLine(m_ErrorList.GetCurSel());
		break;
	case 2:
		theApp.SelectGrepLine(m_SearchList.GetCurSel());
		break;
	} /* if */
}

void CErrorLogDialog::OnSize(UINT nType, int cx, int cy)
{
#define LEFTMARGIN		15
#define RIGHTMARGIN		16
#define TOPMARGIN		4
//      BOTTOMMARGIN	16
#define BUTTONWIDTH		14
#define BUTTONHEIGHT	14
#define TAB_HEIGHT      18
#define CLEAR_WIDTH		44
#define PADDING			2

	CDialog::OnSize(nType, cx, cy);

    CRect rc;
    GetClientRect(&rc);

	// resize error list view
	if (::IsWindow(m_ErrorList.m_hWnd)) {
		m_ErrorList.MoveWindow(rc.left+LEFTMARGIN, rc.top+TOPMARGIN, rc.right-LEFTMARGIN-RIGHTMARGIN, rc.bottom-TOPMARGIN-TAB_HEIGHT-PADDING, TRUE);
		m_ErrorList.RedrawWindow();
	} /* if */

	// resize log view
	if (::IsWindow(m_LogView.m_hWnd)) {
		m_LogView.MoveWindow(rc.left+LEFTMARGIN, rc.top+TOPMARGIN, rc.right-LEFTMARGIN-RIGHTMARGIN, rc.bottom-TOPMARGIN-TAB_HEIGHT-PADDING, TRUE);
		m_LogView.RedrawWindow();
	} /* if */

	// resize search list view
	if (::IsWindow(m_SearchList.m_hWnd)) {
		m_SearchList.MoveWindow(rc.left+LEFTMARGIN, rc.top+TOPMARGIN, rc.right-LEFTMARGIN-RIGHTMARGIN, rc.bottom-TOPMARGIN-TAB_HEIGHT-PADDING, TRUE);
		m_SearchList.RedrawWindow();
	} /* if */

	// resize tab control
	if (::IsWindow(m_Tabs.m_hWnd)) {
		m_Tabs.MoveWindow(rc.left+LEFTMARGIN, rc.bottom-TAB_HEIGHT-PADDING, rc.right-CLEAR_WIDTH-2-LEFTMARGIN-RIGHTMARGIN, TAB_HEIGHT, TRUE);
		m_Tabs.RedrawWindow();
	} /* if */

	// resize clear button
	CWnd* btn = GetDlgItem(IDC_CLEAR);
	if (btn)
		btn->MoveWindow(rc.right-CLEAR_WIDTH-RIGHTMARGIN, rc.bottom-TAB_HEIGHT-PADDING+1, CLEAR_WIDTH, TAB_HEIGHT-1, TRUE);

	// move "Close" button
	btn = GetDlgItem(IDCLOSE);
	if (btn)
		btn->MoveWindow(rc.right-(BUTTONWIDTH+1), rc.top+TOPMARGIN, BUTTONWIDTH, BUTTONHEIGHT, TRUE);

	// cause MDI client window to be resized
	static int recurs = 0;
	ASSERT(recurs >= 0);
	if (recurs == 0) {
		recurs++;
		((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(this->m_hWnd);
		recurs--;
	} /* if */
}

void CErrorLogDialog::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);
	if (bShow)
		((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(bShow ? this->m_hWnd : 0);
}

void CErrorLogDialog::OnClose()
{
	((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(0);
	CDialog::OnClose();
}

void CErrorLogDialog::OnExplicitClose()
{
	OnClose();	/* EndDialog() does not call this one automatically */
	EndDialog(1);
}

void CErrorLogDialog::OnChangeTab(NMHDR* pNMHDR, LRESULT* pResult)
{
	SwitchTab(m_Tabs.GetCurSel());
	*pResult = 0;
}

LRESULT CErrorLogDialog::OnNcHitTest(CPoint point)
{
	UINT hit = CDialog::OnNcHitTest(point);

	if (hit == HTTOPLEFT || hit == HTTOPRIGHT/* || hit == HTCAPTION*/)
		hit = HTTOP;
	else if (hit != HTTOP && hit != HTSYSMENU && hit != HTCLOSE)
		hit = HTBORDER;
	return hit;
}

HBRUSH CErrorLogDialog::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr;

	if (nCtlColor == CTLCOLOR_STATIC && pWnd->m_hWnd == m_LogView.m_hWnd) {
		pDC->SetBkColor(GetSysColor(COLOR_WINDOW));   // change the background color
		pDC->SetTextColor(GetSysColor(COLOR_WINDOWTEXT)); // change the text color
		hbr = GetSysColorBrush(COLOR_WINDOW);
	} else {
		hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	} /* if */

	return hbr;
}

void CErrorLogDialog::OnTimer(UINT nIDEvent)
{
	CDialog::OnTimer(nIDEvent);

	static bool prev_running = false;
	bool isrunning = theApp.CompileRunning(); // || (theApp.m_pGrep != 0 && theApp.m_pGrep->IsRunning());
	bool finished_run = prev_running && !isrunning;
	bool started_run = !prev_running && isrunning;
	prev_running = isrunning;

	static bool prev_debug = false;
	bool isdebug = (theApp.GetDebugger(false) != NULL);
	bool finished_debug = prev_debug && !isdebug;
	bool started_debug = !prev_debug && isdebug;
	prev_debug = isdebug;

	/* reset the focus to the active MDI child */
	if (finished_run && theApp.GetCompiler() && theApp.GetCompiler()->GetErrorLog()) {
		int maximize;
		ASSERT(theApp.m_pMainWnd);
		CMDIChildWnd* pActive = ((CMDIFrameWnd*)theApp.m_pMainWnd)->MDIGetActive(&maximize);
		if (pActive)
			pActive->SetFocus();
	} /* if */

	/* check for new data from the comm port */
	if ((finished_run || finished_debug) && m_logactive && !m_logsuspended && !comm.IsOpen()) {
		comm.Open();
	} else if ((started_run || started_debug) && theApp.GetIsLogEnabled() && theApp.GetDebugPort() > 0) {
		m_logsuspended = false;	/* no longer suspended, re-connect when finishing run */
	} /* if */
	if (comm.IsOpen()) {
		unsigned char buffer[256];
		size_t size = comm.GetData(buffer, sizeof buffer - 1);
		if (size > 0) {
			buffer[size] = '\0';
			AddLogMessage(CString(buffer));
		} /* if */
	} /* if */

	/* check for hoovering over an error message */
	//???
}

void CErrorLogDialog::SwitchTab(int index)
{
	switch (index) {
	case 0:	// Build
		m_ErrorList.ShowWindow(SW_SHOW);
		m_LogView.ShowWindow(SW_HIDE);
		m_SearchList.ShowWindow(SW_HIDE);
		break;
	case 1: // Log
		m_ErrorList.ShowWindow(SW_HIDE);
		m_LogView.ShowWindow(SW_SHOW);
		m_SearchList.ShowWindow(SW_HIDE);
		break;
	case 2:	// Search
		m_ErrorList.ShowWindow(SW_HIDE);
		m_LogView.ShowWindow(SW_HIDE);
		m_SearchList.ShowWindow(SW_SHOW);
		break;
	} /* switch */
	m_Tabs.SetCurSel(index);
}

void CErrorLogDialog::AddBuildMessage(const CString& msg)
{
	CDC* pDC = m_ErrorList.GetDC();
	int pos;
	if ((pos = msg.Find("error ")) > 0 && atoi((LPCTSTR)msg + pos + 6) > 0)
		m_ErrorList.AddLine(CXListBox::Red, CXListBox::White, msg);
	else if ((pos = msg.Find("warning ")) > 0 && atoi((LPCTSTR)msg + pos + 8) > 0)
		m_ErrorList.AddLine(CXListBox::Orange, CXListBox::White, msg);
	else
		m_ErrorList.AddString(msg);
	CSize size = pDC->GetTextExtent(msg);
	m_ErrorListWidth = max(m_ErrorListWidth, size.cx);
	m_ErrorList.SendMessage(LB_SETHORIZONTALEXTENT, m_ErrorListWidth, 0);
	if (m_Tabs.GetCurSel() != 0)
		SwitchTab(0);
}

void CErrorLogDialog::ClearBuildView()
{
	m_ErrorList.ResetContent();
	m_ErrorListWidth = 0;
}

void CErrorLogDialog::AddLogMessage(const CString& msg)
{
	// need to expand \n to \r\n
	// first remove all \r, so \r\n gets converted to \n; then expand \n to \r\n
	CString text = msg;
	text.Remove('\r');
	text.Replace("\n", "\r\n");

	m_LogView.SetSel(-1,-1,TRUE);	// Sets to last position
	m_LogView.ReplaceSel(text);		// Adds the text 
	m_LogView.SetSel(-1,-1,FALSE);	// Scrolls to new last position

	if (m_autoswitchlog && m_Tabs.GetCurSel() != 1)
		SwitchTab(1);
}

void CErrorLogDialog::ClearLogView()
{
	m_LogView.SetWindowText("");
	m_autoswitchlog = true;
}

void CErrorLogDialog::StartLogMonitor()
{
	if (theApp.GetIsLogEnabled() && theApp.GetDebugPort() > 0) {
		m_logactive = true;
		m_logsuspended = theApp.CompileRunning();
		if (!comm.Open(theApp.GetDebugPort(), theApp.GetDebugBaudrate()) && !m_logsuspended) {
			AddLogMessage("COM port could not be opened for logging.\n"
						  "Please verify the settings for the port\n");
			m_logactive = false;
		} /* if */
	} /* if */
}

void CErrorLogDialog::StopLogMonitor()
{
	m_logactive = false;
	m_logsuspended = false;
	if (comm.IsOpen())
		comm.Close();
}

bool CErrorLogDialog::SuspendLogMonitor(bool suspend)
{
	bool prev = m_logsuspended;
	if (theApp.GetIsLogEnabled() && theApp.GetDebugPort() > 0) {
		m_logsuspended = suspend;
		if (m_logsuspended && comm.IsOpen())
			comm.Close();
		else if (!m_logsuspended && !comm.IsOpen())
			comm.Open();	// re-open without changing parameters
	} /* if */
	return prev;
}

void CErrorLogDialog::AddSearchMessage(const CString& msg)
{
	CDC* pDC = m_SearchList.GetDC();
	int pos;
	m_SearchList.AddString(msg);
	CSize size = pDC->GetTextExtent(msg);
	m_SearchListWidth = max(m_SearchListWidth, size.cx);
	m_SearchList.SendMessage(LB_SETHORIZONTALEXTENT, m_SearchListWidth, 0);
	if (m_Tabs.GetCurSel() != 2)
		SwitchTab(2);
}

void CErrorLogDialog::ClearSearchView()
{
	m_SearchList.ResetContent();
	m_SearchListWidth = 0;
}


void CErrorLogDialog::OnClear() 
{
	switch (m_Tabs.GetCurSel()) {
	case 0:
		ClearBuildView();
		break;
	case 1:
		ClearLogView();
		break;
	case 2:
		ClearSearchView();
		break;
	} /* switch */
}

void CErrorLogDialog::OnSelChangeErrorlist()
{
	InfoTip.Hide();
	int item = m_ErrorList.GetCurSel();
	if (item >= 0) {
		/* get the string, and see whether it contains an error/warning */
		CString str;
		m_ErrorList.GetText(item, str);
		int idx = str.Find(" error ");
		if (idx < 0)
			idx = str.Find(" warning ");
		if (idx > 0) {
			ASSERT(str[idx] == ' ');
			idx++;
			while (str[idx] != '\0' && str[idx] != ' ')
				idx++;
			int err = strtol(str.GetBuffer() + idx, NULL, 10);
			if (err > 0) {
				std::string text = theApp.ErrorTip_Lookup(err);
				if (text.length() > 0) {
					str = text.c_str();
					InfoTip.SetText(str);
					/* get the position of the item in the listbox (do
					 * not use the mouse position, because the user may 
					 * navivate with the keyboard
					 */
					RECT rc;
					m_ErrorList.GetItemRect(item, &rc);
					m_ErrorList.MapWindowPoints(theApp.m_pMainWnd, &rc);
					CPoint pos((rc.left + rc.right) / 2, (rc.top + rc.bottom) / 2);
					InfoTip.Show(&pos);
					/* highlight source line */
					theApp.SelectErrorLine(m_ErrorList.GetCurSel(), false);
				} /* if */
			} /* if */
		} /* if */
	} /* if */
}

void CErrorLogDialog::OnKillFocusErrorlist()
{
	InfoTip.Hide();
}
