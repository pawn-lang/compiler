// chkupdate: checks for the availability of updated software on the web
// $Id: chkupdate.cpp 4059 2009-01-19 10:49:44Z thiadmer $
#define STRICT
#include <windows.h>
#include <msxml.h>
#include <stdio.h>
#include <time.h>
#include "chkupdate.h"
#include "tinyxml/tinyxml.h"
#include "tinyxml/xpath_processor.h"

#define SEC_MINUTE	60					/* 60 seconds in a minute */
#define SEC_HOUR	(60*SEC_MINUTE)
#define SEC_DAY		(24*SEC_HOUR)
#define SEC_WEEK	(7*SEC_DAY)

#if !defined sizearray
	#define sizearray(s)	(sizeof(s) / sizeof(s)[0])
#endif

static char AppUrl[_MAX_PATH];

/** \func BOOL CheckUpdate(LPCSTR CurVersion, int NumberPart, LPCSTR Topic, LPCSTR KeyURL, LPCSTR KeyStamp, LPCSTR Profile)
 *
 *	Checks on-line for the existence of a PAD file, gets the product version number 
 *	from the PAD file and compares this with the version passed in a string. Settings
 *	for the URL and the time-stamp of the most recent test are read from (and written
 *	to) an INI file. The full path to that INI file is passed to this function.
 *
 *	\param CurVersion	A string with the product version as is currently installed.
 *	\param NumberPart	The number that you wish to check in the complete version
 *						number. Valid values are:
 *						- CHK_FULLVERSION: the full version is tested, as a string (only equality/inequality is checked).
 *						- CHK_MAJOR: only the major version number is tested
 *						- CHK_MAJOR_MINOR: the major and minor versions are tested
 *						- CHK_BUILD: only the build number is tested
 *	\param Topic		The section in the INI file for all keywords.
 *	\param KeyURL		The key in the INI file (below the \e Topic) for the URL to
 *						the PAD file. This field is updated from the path stored in
 *						the PAD file itself.
 *	\param KeyStamp		The key in the INI file that will hold the time-stamp of
 *						the most recent update.
 *	\param Profile		The name of the INI file (preferably a full path).
 */
extern "C"
BOOL CheckUpdate(LPCSTR CurVersion, enum UPDATE_VERNUMBER NumberPart, LPCSTR Topic, LPCSTR KeyURL, LPCSTR KeyStamp, LPCSTR Profile)
{
	typedef HRESULT (WINAPI *fpURLDownloadToFile)(LPUNKNOWN pCaller, LPCTSTR szURL, LPCTSTR szFileName, DWORD dwReserved, LPBINDSTATUSCALLBACK lpfnCB);
	HINSTANCE hinst;
	fpURLDownloadToFile URLDownloadToFile;
	HRESULT hres;
	unsigned long curstamp, laststamp;
	char str[512], tempfile[_MAX_PATH];
	char lastver[40];

	/* check the timestamp */
	laststamp = GetPrivateProfileInt(Topic, KeyStamp, 0, Profile);
	curstamp = time(NULL);
	if (curstamp - laststamp < SEC_WEEK)
		return FALSE;	/* no need to check now */

	/* download the file */
	GetTempPath(sizearray(str), str);
	GetTempFileName(str, "UPD", 0, tempfile);
	GetPrivateProfileString(Topic, KeyURL, "", str, sizearray(str), Profile);
	if (strlen(str) == 0)
		return FALSE;	/* there is no update URL */

	hinst = LoadLibrary("urlmon.dll");
	if (hinst == NULL)
		return FALSE;
	URLDownloadToFile = (fpURLDownloadToFile)GetProcAddress(hinst, "URLDownloadToFileA");
	if (URLDownloadToFile == NULL) {
		FreeLibrary(hinst);
		return FALSE;
	} /* if */
	hres = URLDownloadToFile(NULL, str, tempfile, 0, NULL);
	FreeLibrary(hinst);
	if (FAILED(hres))
		return FALSE;	/* failed to download the requested file */

	/* now we have the file, parse through it (using XPath) */
	lastver[0] = '\0';
	TiXmlDocument doc(tempfile);
	if (doc.LoadFile()) {
		TinyXPath::xpath_processor xpver(doc.RootElement(), "/XML_DIZ_INFO/Program_Info/Program_Version/text()");
		TiXmlString xstring = xpver.S_compute_xpath();
		strcpy(lastver, xstring.c_str());
		/* also store the current download path in the INI file */
		TinyXPath::xpath_processor xpurl(doc.RootElement(), "/XML_DIZ_INFO/Web_Info/Application_URLs/Application_Info_URL/text()");
		xstring = xpurl.S_compute_xpath();
		strcpy(AppUrl, xstring.c_str());
	} /* if */

	/* temporary file no longer needed */
	remove(tempfile);

	/* update "last checked" timestamp */
	sprintf(str, "%ld", curstamp);
	WritePrivateProfileString(Topic, KeyStamp, str, Profile);

	/* if no key is set in the executable resources, assume that the user runs the latest version */
	if (strlen(CurVersion) == 0)
		return FALSE;

	int major_cur = 0, minor_cur = 0, build_cur = 0;
	int major_last = 0, minor_last = 0, build_last = 0;
	sscanf(CurVersion, "%d.%d.%d", &major_cur, &minor_cur, &build_cur);
	sscanf(lastver, "%d.%d.%d", &major_last, &minor_last, &build_last);

	/* compare version numbers with the one in the profile */
	switch (NumberPart) {
	case 0:
		if (strcmp(CurVersion, lastver) == 0)
			return FALSE;
		break;
	case 1:
		if (major_cur >= major_last)
			return FALSE;
		break;
	case 2:
		if (major_cur >= major_last || major_cur == major_last && minor_cur >= minor_last)
			return FALSE;
		break;
	case 3:
		if (build_cur >= build_last)
			return FALSE;
		break;
	default:
		return FALSE;
	} /* switch */

	/* pop up a message box with the notification of the update */
	sprintf(str, "An update is available on %s\n\n"
		         "        Your version: %s\n"
				 "        New version: %s\n\n"
				 "Do you wish to update now?", AppUrl, CurVersion, lastver);
	if (::MessageBox(NULL, str, "Update available", MB_ICONQUESTION | MB_YESNO) == IDYES)
		ShellExecute(0, "open", AppUrl, 0, 0, SW_SHOW);

	/* the last version is not written back to the INI file; instead, the installer should do this */

	return TRUE;
}
