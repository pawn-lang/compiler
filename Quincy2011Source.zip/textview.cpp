// TextView.cpp : implementation file
// $Id: textview.cpp 4258 2010-06-17 10:21:31Z thiadmer $

#include "stdafx.h"
#include "Quincy.h"
#include "debugger.h"
#include "TextView.h"
#include "TextDocument.h"
#include "Compiler.h"
#include "MainFrm.h"
#include "ErrorLogDialog.h"
#include "MultiDocTemplateEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTextView

static const int margin = 1;				// margin for breakpoint and program counter carets
static const char breakpointchar = '>';		// breakpoint margin displaycharacter

IMPLEMENT_DYNCREATE(CTextView, CEditorView)

CTextView::CTextView()
{
}

CTextView::~CTextView()
{
}

BEGIN_MESSAGE_MAP(CTextView, CEditorView)
	//{{AFX_MSG_MAP(CTextView)
	ON_COMMAND(ID_COMPILE, OnCompile)
	ON_COMMAND(ID_EXECUTE, OnRun)
	ON_COMMAND(ID_DEBUG_BREAKPOINT, OnDebugBreakpoint)
	ON_COMMAND(ID_DEBUG_STEP, OnDebugStep)
	ON_COMMAND(ID_DEBUG_STEPTOCURSOR, OnDebugSteptocursor)
	ON_UPDATE_COMMAND_UI(ID_COMPILE, OnUpdateCompile)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_ALL, OnUpdateFileSaveAll)
	ON_COMMAND(ID_DEBUG_STEPOUTOFFUNCTION, OnDebugStepoutoffunction)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_DEBUG_TRANSFER, OnDebugTransfer)
	ON_COMMAND(ID_NEXT_BREAKPOINT, OnNextBreakpoint)
	ON_COMMAND(ID_PREV_BREAKPOINT, OnPrevBreakpoint)
	ON_COMMAND(ID_BUILD_VIEW, OnToggleBuildView)
	ON_COMMAND(ID_SYMBOLBROWSER, OnToggleSymbolBrowser)
	ON_WM_CHAR()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextView diagnostics

#ifdef _DEBUG
void CTextView::AssertValid() const
{
	CEditorView::AssertValid();
}

void CTextView::Dump(CDumpContext& dc) const
{
	CEditorView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTextView message handlers


bool CTextView::DoCompile(bool bDoLink, bool bDoExecute, bool bDoStep, bool bTransfer)
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT(pDoc != 0);

	CString& rstrPath = const_cast<CString&>(pDoc->GetPathName());
	if (pDoc->IsModified())
		pDoc->OnSaveDocument(rstrPath);

	theApp.SaveAllDocuments(true);

	// ----- make a copy of the file spec without the extension;
	CString strSpec = rstrPath.Left(rstrPath.ReverseFind('.'));

	CString strExeSpec;
	if (theApp.UseFixedName()) {
		ASSERT(!theApp.FixedExecName().IsEmpty());
		int nIndex = rstrPath.ReverseFind('\\');
		if (nIndex == -1)
			nIndex = rstrPath.ReverseFind(':');
		if (nIndex != -1)
			strExeSpec = rstrPath.Left(nIndex + 1);
		strExeSpec += theApp.FixedExecName() + ".amx";
	} else {
		strExeSpec = strSpec + ".amx";
	}

	// ---- queue the source and object files for compile/link
	ASSERT(theApp.GetCompiler() != NULL);
	theApp.GetCompiler()->ClearArrays();
	theApp.GetCompiler()->AddSourceFile(rstrPath);
	theApp.GetCompiler()->ClearErrorLog();
	Compiler::CompileAction action = Compiler::none;
	if (bDoExecute)
		action = bDoStep ? Compiler::step : Compiler::run;
	else if (bTransfer)
		action = Compiler::transfer;
	//else if (theApp.MakeReport())
	//	action = Compiler::showreport;
	theApp.GetCompiler()->BuildTarget(strExeSpec, action);
	
	// ---- mark the document as "non-changed" since last compile; also
	//		mark all include files as non-changed (??? should ask te compiler for a list of dependencies)
	pDoc->ChangedAfterBuild = false;
	CTextDocument* pTxt;
	int idx = 0;
	do {
		pTxt = theApp.GetTextDocument(idx++);
		if (pTxt && !pTxt->IsSourceFile())
			pTxt->ChangedAfterBuild = false;
	} while (pTxt);

	return true;
}

void CTextView::OnCompile()
{
	if (!IsSourceFile()) {
		int count = CountSourceFiles();
		ASSERT(count > 0);
		if (count == 1) {
			// switch to the single other script
			CTextDocument* pDoc;
			int idx = 0;
			do
				pDoc = theApp.GetTextDocument(idx++);
			while (pDoc && !pDoc->IsSourceFile());
			if (pDoc) {
				CTextView *pView = theApp.GetTextView(pDoc->GetPathName());
				if (pView)
					pView->PostMessage(WM_COMMAND, ID_COMPILE);
			} /* if */
		} else {
			// ??? pop up a list with scripts and have the user select the proper script
			CString Msg;
			if (IsIncludeFile())
				Msg = "This is an include file.";
			else
				Msg = "This is a text file.";
			Msg += " You need to select a script file first and then start the compilation.";
			MessageBox(Msg, "Select script", MB_ICONSTOP);
		} /* if */
		return;
	} /* if */
	DoCompile(true, false);
}

void CTextView::OnDebugStep()
{
	if (!theApp.StepProgram())
		if (!BuildIfNeeded(true))
			theApp.DebugProgram(m_strExe, true);
}

void CTextView::OnDebugStepoutoffunction()
{
	theApp.StepOut();
}

void CTextView::OnRun()
{
	if (!theApp.ExecuteRunningProgram())
		if (!BuildIfNeeded(false))
			theApp.StartProgram(m_strExe);
}

// --- returns true if build is started meaning delay the execution
//     also returns true if no exe and user opts not to build, meaning no execution
//     otherwise returns false meaning execution may proceed
bool CTextView::BuildIfNeeded(bool bStep, bool bExecute, bool bTransfer)
{
	if (bStep)
		bExecute = true;	// stepping implies execution

	CEditorDoc* pDoc = GetDocument();
	ASSERT(pDoc != 0);
	CString& rstrPath = const_cast<CString&>(pDoc->GetPathName());

	if (theApp.UseFixedName()) {
		ASSERT(!theApp.FixedExecName().IsEmpty());
		int nIndex = rstrPath.ReverseFind('\\');
		if (nIndex == -1)
			nIndex = rstrPath.ReverseFind(':');
		if (nIndex != -1)
			m_strExe = rstrPath.Left(nIndex + 1);
		m_strExe += theApp.FixedExecName() + ".amx";
	} else {
		// ----- make a copy of the file spec with the .AMX extension;
		m_strExe = rstrPath.Left(rstrPath.ReverseFind('.'));
		m_strExe += ".amx";
	}
	int rtn;
	if (_access(m_strExe, 0) != 0)	{
		CString strMsg = theApp.GetFileName(m_strExe) + " does not exist. Build?";
		if (AfxMessageBox(strMsg, MB_YESNO | MB_ICONQUESTION) == IDYES)
			DoCompile(true, bExecute, bStep, bTransfer);
		return true;
	}
	if (pDoc->ChangedAfterBuild) {
		CString strMsg = theApp.GetFileName(rstrPath) + " has been modified. Build?";
		if ((rtn = AfxMessageBox(strMsg, MB_YESNOCANCEL | MB_ICONQUESTION)) == IDYES)	{
			DoCompile(true, bExecute, bStep, bTransfer);
			return true;
		} else if (rtn == IDCANCEL)
			return true;
	} else if (theApp.CompareFileTimes(rstrPath, m_strExe) > 0) {
		CString strMsg = theApp.GetFileName(m_strExe) + " out of date. Rebuild?";
		if ((rtn = AfxMessageBox(strMsg, MB_YESNOCANCEL | MB_ICONQUESTION)) == IDYES)	{
			DoCompile(true, bExecute, bStep, bTransfer);
			return true;
		}
	}
	return false;
}

// ----- return the document file specification
CString CTextView::SourceCodeFileName()
{
	CTextDocument* pDoc = (CTextDocument*)GetDocument();
	return pDoc == 0 ? CString() : pDoc->GetPathName();
}
// ----- called to set or clear a breakpoint in this source code file
void CTextView::OnDebugBreakpoint()
{
	// ---- get the name of the source code file
	CString strFile = GetDocument()->GetPathName();
	// ----- get the current line number from the source code file
	int nLineno = CurrentLineNumber();		// current line number
	theApp.ToggleBreakpoint(strFile, nLineno);
	DrawMargins();
}

void CTextView::OnNextBreakpoint()
{
	CString strFile = GetDocument()->GetPathName();
	int nLineno = CurrentLineNumber();		// current line number
	nLineno = theApp.FindBreakpoint(strFile, nLineno, 0);
	if (nLineno != -1)
		theApp.SelectFileAndLine(strFile, nLineno);
}

void CTextView::OnPrevBreakpoint()
{
	CString strFile = GetDocument()->GetPathName();
	int nLineno = CurrentLineNumber();		// current line number
	nLineno = theApp.FindBreakpoint(strFile, nLineno, -1);
	if (nLineno != -1)
		theApp.SelectFileAndLine(strFile, nLineno);
}

// --- write a 16 X 15 bitmap into the editor's left margin
//     nLine is the window's vertical pixel position
//
//	   transparent BitBlt() was adapted from http://www.codeproject.com/KB/graphics/transbitmapmask.aspx,
//	   comment by "Tim @ Fit", 26 Oct. 2003, 18:04. It is the
//	   "standard" masked BitBlt, cleanly written.
void CTextView::WriteMarginBitmap(int nRow, CBitmap& bmp)
{
	CDC* pCDC = GetDC();
	if (pCDC != NULL) {
		/* get size of the bitmap, convert to logical points */
		BITMAP bm;
		bmp.GetObject(sizeof(BITMAP), &bm);

		/* put the bitmap in a "work" DC */
		CDC dcWork;
		dcWork.CreateCompatibleDC(pCDC);
		CBitmap* bmWorkOld = static_cast<CBitmap*>(dcWork.SelectObject(&bmp));
		POINT ptSize;
		ptSize.x = bm.bmWidth;
		ptSize.y = bm.bmHeight;
		dcWork.DPtoLP(&ptSize);

		/* create monochrome mask bitmaps */
		CBitmap bmAndBack, bmAndObject;
		bmAndBack.CreateBitmap(ptSize.x, ptSize.y, 1, 1, NULL);
		bmAndObject.CreateBitmap(ptSize.x, ptSize.y, 1, 1, NULL);

		/* bitmaps for intermediate results (after masking) */
		CBitmap bmAndMem, bmSave;
		bmAndMem.CreateCompatibleBitmap(pCDC, ptSize.x, ptSize.y);
		bmSave.CreateCompatibleBitmap(pCDC, ptSize.x, ptSize.y);

		/* create a DC per bitmap and select the bitmaps into their respective DCs */
		CDC dcBack, dcObject, dcMem, dcSave;
		dcBack.CreateCompatibleDC(pCDC);
		CBitmap *bmBackOld = static_cast<CBitmap*>(dcBack.SelectObject(&bmAndBack));
		dcObject.CreateCompatibleDC(pCDC);
		CBitmap *bmObjectOld = static_cast<CBitmap*>(dcObject.SelectObject(&bmAndObject));
		dcMem.CreateCompatibleDC(pCDC);
		CBitmap *bmMemOld = static_cast<CBitmap*>(dcMem.SelectObject(&bmAndMem));
		dcSave.CreateCompatibleDC(pCDC);
		CBitmap *bmSaveOld = static_cast<CBitmap*>(dcSave.SelectObject(&bmSave));

		dcWork.SetMapMode(pCDC->GetMapMode());	/* set proper mapping mode */

		/* save the bitmap sent here, because it will be overwritten */
		dcSave.BitBlt(0, 0, ptSize.x, ptSize.y, &dcWork, 0, 0, SRCCOPY);

		/* set the background color of the source DC to the transparent color */
		COLORREF cTransparentColor = dcSave.GetPixel(0, 0);	/* upper-left pixel is transparent */
		COLORREF cColor = dcWork.SetBkColor(cTransparentColor);

		/* create the object mask for the source bitmap, also create its inverse */
		dcObject.BitBlt(0, 0, ptSize.x, ptSize.y, &dcWork, 0, 0, SRCCOPY);
		dcBack.BitBlt(0, 0, ptSize.x, ptSize.y, &dcObject, 0, 0, NOTSRCCOPY);
		dcWork.SetBkColor(cColor);		/* restore */

		/* copy the background of the main DC to the destination */
		dcMem.BitBlt(0, 0, ptSize.x, ptSize.y, pCDC, 0, nRow, SRCCOPY);
		/* mask out the places where the bitmap will be placed */
		dcMem.BitBlt(0, 0, ptSize.x, ptSize.y, &dcObject, 0, 0, SRCAND);
		/* mask out the transparent colored pixels on the bitmap */
		dcWork.BitBlt(0, 0, ptSize.x, ptSize.y, &dcBack, 0, 0, SRCAND);
		/* XOR the bitmap with the background on the destination DC */
		dcMem.BitBlt(0, 0, ptSize.x, ptSize.y, &dcWork, 0, 0, SRCPAINT);

		/* copy the destination to the screen */
		pCDC->BitBlt(0, nRow, ptSize.x, ptSize.y, &dcMem, 0, 0, SRCCOPY);

		/* place the original bitmap back into the bitmap sent here */
		dcWork.BitBlt(0, 0, ptSize.x, ptSize.y, &dcSave, 0, 0, SRCCOPY);

		/* clean up */
		dcBack.SelectObject(bmBackOld);
		dcObject.SelectObject(bmObjectOld);
		dcMem.SelectObject(bmMemOld);
		dcSave.SelectObject(bmSaveOld);
		dcWork.SelectObject(bmWorkOld);
	} /* if */
}


// ---- compute the window's zero-based client area pixel position number
//      from the one-based text line number
inline int CTextView::RelativeRow(int nLineno)
{
	ASSERT(nLineno > 0);
	int lno = nLineno - TopLine();	// zero-based line number
	int top = TopRow() % m_fontheight;
	int y = lno * m_fontheight - top;
	return y;
}

void CTextView::OnDraw(CDC* pDC)
{
	CEditorView::OnDraw(pDC);
	DrawMargins();
}

void CTextView::DrawMargins()
{
	PadMargin();
	// ---- get the name of the source code file
	CString strFile = theApp.GetFileName(SourceCodeFileName());
	if (strFile.IsEmpty())
		return;
	// ----- compute top and bottom lines of the client window
	int nLine = TopLine(); // one-based line number
	RECT rc;
	GetClientRect(&rc);
	int nBottomLine = nLine + rc.bottom / m_fontheight; // one-based line number

	// --- set flag if this file is the current debugged source code file
	bool bSrc = false;
	Debugger* pDebugger = theApp.GetDebugger(false);
	if (pDebugger != 0)	{
		const CString* pCurrentSrcFile = pDebugger->CurrentSrcFile();
		CString str = theApp.GetFileName(*pCurrentSrcFile);
		if (pCurrentSrcFile != 0)	{
			bSrc = strFile.CompareNoCase(str) == 0;
		}
	}
	// ---- iterate the lines, displaying
	//      breakpoint margin carets and the program counter cursor bar
	do	{
		bool bPC = (bSrc && nLine == theApp.GetDebugger()->CurrentLineNo()) != false;
		if (theApp.IsBreakpoint(strFile, nLine))	{
			if (bPC)
				SetPCBreakpointDisplay(nLine);
			else
				SetBreakpointDisplay(nLine, true);
		}
		else if (bPC)
			SetProgramCounterDisplay(nLine, true);
	} while (nLine++ < nBottomLine);
}

// ---- set or clear a breakpoint bitmap in the margin
// ------ nLineno is the one-based file line number
void CTextView::SetBreakpointDisplay(int nLineno, bool bOnOff)
{
	int nRelativeRow = RelativeRow(nLineno);
	CBitmap bm;
#if 0//???
	int resid = theApp.IsRGBmode() ? IDB_BITMAP4_RGB : IDB_BITMAP4;
#else
	int resid = IDB_BITMAP4;
#endif
	bm.LoadBitmap(bOnOff ? resid : IDB_BITMAP3);
	WriteMarginBitmap(nRelativeRow, bm);
	bm.DeleteObject();
}
// ---- set a breakpoint and pc bitmap in the margin
// ------ nLineno is the one-based file line number
void CTextView::SetPCBreakpointDisplay(int nLineno)
{
	int nRelativeRow = RelativeRow(nLineno);
	CBitmap bm;
#if 0//???
	int resid = theApp.IsRGBmode() ? IDB_BITMAP5_RGB : IDB_BITMAP5;
#else
	int resid = IDB_BITMAP5;
#endif
	bm.LoadBitmap(resid);
	WriteMarginBitmap(nRelativeRow, bm);
	bm.DeleteObject();
}
// ---- set or clear the program counter cursor in the margin
// ------ nLineno is the zero-based file line number
void CTextView::SetProgramCounterDisplay(int nLineno, bool bOnOff)
{
	int nRelativeRow = RelativeRow(nLineno);
	CBitmap bm;
#if 0//???
	int resid = theApp.IsRGBmode() ? IDB_BITMAP2_RGB : IDB_BITMAP2;
#else
	int resid = IDB_BITMAP2;
#endif
	bm.LoadBitmap(bOnOff ? resid : IDB_BITMAP3);
	WriteMarginBitmap(nRelativeRow, bm);
	bm.DeleteObject();
}

void CTextView::OnDebugSteptocursor()
{
	if (!theApp.TestProgramChanged())	{
		int nLineNo = CurrentLineNumber();
		CString strFile = SourceCodeFileName();
		if (!theApp.StepTo(strFile, nLineNo))
			OnRun();
	}
}

void CTextView::OnUpdateCompile(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(CanBuild() && (IsSourceFile() || CountSourceFiles() > 0));
}

bool CTextView::CanBuild()
{
	Debugger* pDebugger = theApp.GetDebugger(false);
	return !theApp.CompileRunning() && pDebugger == 0 && theApp.CanCompile();
}

bool CTextView::IsSourceFile()
{
	CTextDocument* pDoc = (CTextDocument*)GetDocument();
	ASSERT(pDoc != 0);
	return pDoc->IsSourceFile();
}

bool CTextView::IsIncludeFile()
{
	CTextDocument* pDoc = (CTextDocument*)GetDocument();
	ASSERT(pDoc != 0);
	return !pDoc->IsSourceFile() && pDoc->IsExecutableSourceFile();
}

int CTextView::CountSourceFiles()
{
	int count = 0;
	for (int idx = 0; ; idx++) {
		CTextDocument* pDoc = theApp.GetTextDocument(idx);
		if (!pDoc)
			return count;
		if (pDoc->IsSourceFile())
			count++;
	} /* for */
}

void CTextView::OnUpdateFileSaveAll(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(true);
}

void CTextView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	if (point.x < m_margin)
		OnDebugBreakpoint();
	else
		CEditorView::OnLButtonDblClk(nFlags, point);
}

void CTextView::OnDebugTransfer()
{
	if (BuildIfNeeded(false, false, true))
		return;

	CDocument* pDoc = GetDocument();
	ASSERT(pDoc != 0);

	CString& rstrPath = const_cast<CString&>(pDoc->GetPathName());
	if (pDoc->IsModified())
		pDoc->OnSaveDocument(rstrPath);

	// ----- make a copy of the file spec without the extension;
	CString strSpec = rstrPath.Left(rstrPath.ReverseFind('.'));

	CString strExeSpec;
	if (theApp.UseFixedName()) {
		ASSERT(!theApp.FixedExecName().IsEmpty());
		int nIndex = rstrPath.ReverseFind('\\');
		if (nIndex == -1)
			nIndex = rstrPath.ReverseFind(':');
		if (nIndex != -1)
			strExeSpec = rstrPath.Left(nIndex + 1);
		strExeSpec += theApp.FixedExecName();
	} else {
		strExeSpec = strSpec;
	} /* if */
	if (strExeSpec.Right(4).CompareNoCase(".amx") != 0)
		strExeSpec += ".amx";

	// ---- disable logging
	ASSERT(theApp.GetCompiler() != NULL);
	CErrorLogDialog *dlg = theApp.GetCompiler()->GetErrorLog();
	if (dlg != 0)
		dlg->SuspendLogMonitor();

	// ---- queue the source and object files for compile/link
	ASSERT(theApp.GetCompiler() != NULL);
	theApp.GetCompiler()->ClearArrays();
	theApp.GetCompiler()->ClearErrorLog();
	theApp.GetCompiler()->TransferTarget(strExeSpec, TRUE);
	theApp.GetCompiler()->RunCompilerProgram();
}

void CTextView::OnToggleBuildView()
{
	if (theApp.GetCompiler()) {
		CErrorLogDialog *dlg = theApp.GetCompiler()->GetErrorLog();
		if (dlg != 0) {
			if (::IsWindowVisible(dlg->m_hWnd)) {
				dlg->ShowWindow(SW_HIDE);
				((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(0);
			} else {
				((CMainFrame*)theApp.m_pMainWnd)->SetLowPane(dlg->m_hWnd);
			} /* if */
		} /* if */
	} /* if */
}

void CTextView::OnToggleSymbolBrowser()
{
	bool justcreated = false;
	CSymBrowseDialog *dlg = ((CMainFrame*)theApp.m_pMainWnd)->GetSymBrowser();
	if (!dlg) {
		((CMainFrame*)theApp.m_pMainWnd)->CreateSymBrowser();
		dlg = ((CMainFrame*)theApp.m_pMainWnd)->GetSymBrowser();
		justcreated = true;
	} /* if */
	if (dlg) {
		if (::IsWindowVisible(dlg->m_hWnd) && !justcreated) {
			dlg->ShowWindow(SW_HIDE);
			((CMainFrame*)theApp.m_pMainWnd)->SetRightPane(0);
		} else {
			((CMainFrame*)theApp.m_pMainWnd)->SetRightPane(dlg->m_hWnd);
			if (theApp.MakeReport()) {
				dlg->Clear();
				int count = dlg->LoadAllReportFiles();
				if (!count)
					AfxMessageBox(_T("No symbols found (from previous compiles).\nYou need to compile the script(s) for the symbol list to be updated."), MB_ICONINFORMATION);
			} else {
				AfxMessageBox(_T("The \"symbol report\" generation is turned off in the build options.\nPlease turn it on for the symbol list to be updated."), MB_ICONERROR);
			} /* if */
		} /* if */
	} /* if */
}
