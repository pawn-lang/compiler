#if !defined(AFX_BEAUTIFER_H__1C115531_2B12_4F55_BA60_EBD2602159AC__INCLUDED_)
#define AFX_BEAUTIFER_H__1C115531_2B12_4F55_BA60_EBD2602159AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Beautifer.h : header file
//
#include <vector>

/////////////////////////////////////////////////////////////////////////////
// CBeautifier dialog

class CBeautifier : public CDialog
{
	CFont* font;
	std::vector<std::string> beautifiedtext;
	std::vector<CString> configfiles;
	static CBeautifier* pBeautifier;
	ConsoleApp* m_pConsoleApp;
	static void Collect(DWORD bufct);
	void CollectSourceLines(DWORD bufct);
	void NotifyTermination();
	static void Notify();

public:
	int m_style;
	CString	m_configfile;

// Construction
public:
	CBeautifier(CWnd* pParent = NULL);   // standard constructor
	~CBeautifier();
// Dialog Data
	//{{AFX_DATA(CBeautifier)
	enum { IDD = IDD_BEAUTIFIER };
	CComboBox	m_BeautifyStyle;
	CEdit	m_samplecode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBeautifier)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBeautifier)
	afx_msg void OnStyle();
	virtual BOOL OnInitDialog();
	afx_msg void OnHelp();
	afx_msg void OnSelchangeBeautifystyle();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BEAUTIFER_H__1C115531_2B12_4F55_BA60_EBD2602159AC__INCLUDED_)
