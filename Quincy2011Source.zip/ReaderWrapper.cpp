// ReaderWrapper.cpp: implementation of the CReaderWrapper class.
//
// $Id: ReaderWrapper.cpp 4011 2008-09-11 12:39:48Z thiadmer $
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ReaderWrapper.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


/*************************************************************************

  SeaSideTech - www.seasidetech.net.
  -------------------------------------

* Software: CReaderWrapper                                                     *
* Version:  1.1						                                           *
* Date:     2004-11-09			                                               *
* Author:   Vincent FLOURIOT - vincent.flouriot@seasidetech.net                *
* License:  Freeware                                                           *
*                                                                              *
* You may use, modify and redistribute this software as you wish.              *

**************************************************************************

						OVERVIEW

  This class uses DDE messages to communicate with acrobat reader (or acrobat)
  Most of usefull DDE messages have been wrapped into that class.
  Acrobat DDE messages are described in the adobe document called IACReference.pdf
  (this document can be downloaded inside the ADOBE SDK)

**************************************************************************

 Evolution of the component CReaderWrapper.:
 -----------------------------------------
  (initials, date, modification)

   created by :	 Vincent Flouriot  08/10/04
				 1.1 : First release

*************************************************************************/

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HDDEDATA CALLBACK DdeCallback(
    UINT uType,     // Transaction type.
    UINT uFmt,      // Clipboard data format.
    HCONV hconv,    // Handle to the conversation.
    HSZ hsz1,       // Handle to a string.
    HSZ hsz2,       // Handle to a string.
    HDDEDATA hdata, // Handle to a global memory object.
    DWORD dwData1,  // Transaction-specific data    
	DWORD dwData2)  // Transaction-specific data.
{
    return 0;
}

CReaderWrapper::CReaderWrapper(CString stPdfFile)
{
	stPdfFileName=stPdfFile;
	dwIdInst=0;
	hConv=NULL;
	AutoClose=FALSE;
	TryDDE=TRUE;

	/*DDE initialisation process*/
    UINT iReturn;
    iReturn = DdeInitialize(&dwIdInst, (PFNCALLBACK)DdeCallback,
                            APPCLASS_STANDARD | APPCMD_CLIENTONLY, 0 );
	ASSERT(iReturn==DMLERR_NO_ERROR);
}

CReaderWrapper::~CReaderWrapper()
{
	/*Disconnect */
	if(hConv)
		DdeDisconnect(hConv);

	if(dwIdInst)
		DdeUninitialize(dwIdInst);
}

/*Open the pdf file in acrobat reader*/
BOOL CReaderWrapper::DocOpen(CString stPdfFile)
{
	HINSTANCE hRet;
	int retry, restart;
	BOOL result;

	if (stPdfFile.GetLength()!=0) {
		if (AutoClose && stPdfFile.CompareNoCase(stPdfFileName)!=0 && hConv!=NULL)
			DocClose();
		stPdfFileName=stPdfFile;
	} /* if */

	restart = 1;
	do {
		if (hConv == NULL) {
			/* Start the DDE server*/
			hRet = ShellExecute(0, "open", (LPCTSTR)stPdfFileName, 0, 0, SW_SHOWNORMAL);
			if ((unsigned)hRet <= 32)
				return FALSE;
			if (!TryDDE)
				return FALSE;	/*DDE was tested before (and found not-working)*/

			/* Connect to server (retry a few times), but if it fails, do not
			 * try to connect again for any next file
			 */
			TryDDE = FALSE;
			HSZ hszApp, hszTopic;
			char szApp[] = "acroview";
			char szTopic[] = "control";

			hszApp = DdeCreateStringHandle(dwIdInst, szApp, 0);
			hszTopic = DdeCreateStringHandle(dwIdInst, szTopic, 0);

			for (retry = 0; retry < 20; retry++)
			{
				hConv = DdeConnect(dwIdInst, hszApp, hszTopic, NULL);
				if (hConv != NULL)
					break;
				Sleep(500);
			}

			DdeFreeStringHandle(dwIdInst, hszApp);
			DdeFreeStringHandle(dwIdInst, hszTopic);
			
			if (hConv == NULL)
			{
				::MessageBox(NULL, "DDE connection to PDF reader failed.", NULL, MB_OK);
				Sleep(500); 
				DdeUninitialize(dwIdInst);
				return FALSE;
			}
		} /* if */

		/*DDE message DocOpen MUST be send first before using other messages*/
		CString stCmdLine;
		stCmdLine.Format("[DocOpen(\"%s\")]",stPdfFile);
		result=_ExecuteQuery(stCmdLine);
	} while (!result && restart-- > 0);

	return result;
}

/*Open the pdf file in acrobat reader*/
void CReaderWrapper::CloseAllDocs()
{
	if (Valid()) {
		CString stCmdLine;
		stCmdLine="[CloseAllDocs]";
		_ExecuteQuery(stCmdLine);
	} /* if */
}

/*Close the current document*/
void CReaderWrapper::DocClose()
{
	if (Valid()) {
		CString stCmdLine;
		stCmdLine.Format("[DocClose(\"%s\")]",stPdfFileName);
		_ExecuteQuery(stCmdLine);
	} /* if */
}

void CReaderWrapper::ExitAcrobat()
{
	if (Valid()) {
		CString stCmdLine;
		stCmdLine="[AppExit()]";
		_ExecuteQuery(stCmdLine);
	} /* if */
}


void CReaderWrapper::GoToPage(int iPage)
{
	ASSERT(iPage>0);
	if (Valid()) {
		CString stCmdLine;
		stCmdLine.Format("[DocGoTo(\"%s\",%i)]",stPdfFileName,iPage-1);
		_ExecuteQuery(stCmdLine);
	} /* if */  
}

void CReaderWrapper::GoToPage(const char *bookmark)
{
	ASSERT(bookmark!=NULL);
	if (Valid()) {
		CString stCmdLine;
		stCmdLine.Format("[DocGoToNameDest(\"%s\",%s)]",stPdfFileName,bookmark);
		_ExecuteQuery(stCmdLine);
	} /* if */
}

void CReaderWrapper::FilePrint()
{
	if (Valid()) {
		CString stCmdLine;
		stCmdLine.Format("[FilePrint(\"%s\")]",stPdfFileName);
		this->_ExecuteQuery(stCmdLine);
	} /* if */
}

void CReaderWrapper::FilePrintSilent()
{
	if (Valid()) {
		CString stCmdLine;
		stCmdLine.Format("[FilePrintSilent(\"%s\")]",stPdfFileName);
		_ExecuteQuery(stCmdLine);
	} /* if */  
}

void CReaderWrapper::SetAutoClose(BOOL value)
{
	AutoClose=value;
}

/*Private methods*/
BOOL CReaderWrapper::_ExecuteQuery(CString stQuery)
{
	HDDEDATA hData;
	hData = DdeCreateDataHandle(dwIdInst, (LPBYTE)(LPCTSTR)stQuery,
                               stQuery.GetLength()+1, 0, NULL, CF_TEXT, 0);
    if (hData == NULL) {
        ::MessageBox(NULL, stQuery, "DDE command failed", MB_OK);
		return FALSE;
    } /* if */
	
	HDDEDATA result = DdeClientTransaction((LPBYTE)hData, 0xFFFFFFFF, hConv, 0L, 0,
                                           XTYP_EXECUTE, TIMEOUT_ASYNC, NULL);
	if (result == 0) {
		/* connection was aborted; disconnect and possibly restart */
		if(hConv)
			DdeDisconnect(hConv);
		hConv = NULL;
		TryDDE = TRUE;
		return FALSE;
	} /* if */

	return TRUE;
}
