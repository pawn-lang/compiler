/*
 * Copyright (c) 2002 Wild West Software
 */

#include "ce.h"
#include <windows.h>

time_t time(time_t* pt) {
	time_t res = 0;
	if (pt != NULL) {
		res = (time_t)GetTickCount();
	}
	return res;
}

struct tm* localtime(const time_t* timer) {
	struct tm* res;
	res = (struct tm*)malloc(sizeof(struct tm));
	return res;
}

clock_t clock() {
	return (clock_t)GetTickCount();
}



#if defined(UNDER_CE) && (UNDER_CE < 300)
int isdigit(int c) {
	return iswdigit((wchar_t)c);
}
#endif



double atof(const char* string) {
	double res;
	int len, i;
	wchar_t* s;
	wchar_t* end;
	len = strlen(string);
	s = alloca((len+1) * sizeof(wchar_t));
	for (i = 0; i < len+1; i++) {
		s[i] = string[i];
	}
	res = wcstod(s, &end);
	return res;
}



void rewind(FILE* stream) {
	fseek(stream, 0, SEEK_SET);
}



char* strdup(const char* strSource) {
	char* res = NULL;
	int len;
	if (strSource != NULL) {
		len = strlen(strSource);
		res = malloc(len+1);
		memcpy(res, strSource, len+1);
	}
	return res;
}

char* strrchr(const char* string, int c) {
	char* res = NULL;
	int len, i;
	if (string != NULL) {
		len = strlen(string);
		for (i = len; --len >= 0;) {
			if (string[i] == c) {
				res = (char*)&string[i];
				break;
			}
		}
	}
	return res;
}

int stricmp(const char* string1, const char* string2) {
	int res = 0;
	int l1, l2, i;
	wchar_t* s1;
	wchar_t* s2;
	l1 = strlen(string1);
	l2 = strlen(string2);
	s1 = alloca((l1+1) * sizeof(wchar_t));
	s2 = alloca((l2+1) * sizeof(wchar_t));
	for (i = 0; i < l1+1; i++) {
		s1[i] = string1[i];
	}
	for (i = 0; i < l2+1; i++) {
		s2[i] = string2[i];
	}
	res = _wcsicmp(s1, s2);
	return res;
}



void (* signal(int sig, void (* func)(int subcode)))(int sig2) {
	return 0;
}

