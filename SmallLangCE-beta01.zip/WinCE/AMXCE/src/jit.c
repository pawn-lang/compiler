/*
 * Copyright (c) 2002 Wild West Software
 */

#include "jit.h"

#define ARCH arm
#include "arch/arm/arm-jit.h"
#include "arch/arm/arm-dis.h"

JIT_CompilerContext* jit_ctx_create(cell* bytecode_base, int bytecode_size, cell* native_base) {
	JIT_CompilerContext* ctx = (JIT_CompilerContext*)malloc(sizeof(JIT_CompilerContext));

	ctx->bytecode.base = bytecode_base;
	ctx->bytecode.ptr = bytecode_base;

	ctx->native.base = native_base;
	ctx->native.ptr = native_base;

	ctx->bytecode_size = bytecode_size;
	ctx->native_size = 0;

	ctx->map_size = 0;
	ctx->code_map = (JIT_CodeMap*)malloc(bytecode_size * sizeof(JIT_CodeMap));

	ctx->num_relocs = 0;
	ctx->reloc_tab = (JIT_RelocTable*)malloc(bytecode_size * sizeof(JIT_RelocTable));

	return ctx;
}

void jit_ctx_destroy(JIT_CompilerContext* ctx) {
	if (ctx) free(ctx);
}

void jit_ctx_add_reloc(JIT_CompilerContext* ctx, cell* patch_addr, cell* bytecode_dest) {
	ctx->reloc_tab[ctx->num_relocs].patch_addr = patch_addr;
	ctx->reloc_tab[ctx->num_relocs].bytecode_dest = bytecode_dest;
	++ctx->num_relocs;
}

cell* jit_ctx_map_bytecode_addr(JIT_CompilerContext* ctx, cell* bytecode_addr) {
	cell* res = NULL;
	int left, right, guess, diff;
	if (!ctx || 0 == ctx->map_size) return res;

	left = 0;
	right = ctx->map_size - 1;

	while (left <= right) {
		guess = (left + right) >> 1;
		diff = (int)bytecode_addr - (int)ctx->code_map[guess].bytecode;
		if (diff == 0) {
			res = ctx->code_map[guess].native;
			break;
		}
		if (diff > 0) {
			left = guess + 1;
		} else {
			right = guess - 1;
		}
	}

	return res;
}


int AMXAPI getMaxCodeSize() {
	return arm_get_max_code_size();
}

int AMXAPI asm_runJIT(void* sourceAMXbase, void* jumparray, void* compiledAMXbase) {
	int i;
	AMX_HEADER* bytecode_hdr = (AMX_HEADER*)sourceAMXbase;
	AMX_HEADER* compiled_hdr = (AMX_HEADER*)compiledAMXbase;
	cell* p_bc = (cell*)((char*)bytecode_hdr + bytecode_hdr->cod);
	cell* p_native = (cell*)((char*)compiled_hdr + compiled_hdr->cod);
	int code_size = (bytecode_hdr->dat - bytecode_hdr->cod) / sizeof(cell);
	JIT_CompilerContext* ctx = jit_ctx_create(p_bc, code_size, p_native);

	while (ctx->bytecode.ptr < (ctx->bytecode.base + code_size)) {
		/* update code map */
		ctx->code_map[ctx->map_size].bytecode = ctx->bytecode.ptr;
		ctx->code_map[ctx->map_size].native = ctx->native.ptr;
		ctx->map_size++;

		arm_compile_opcode(ctx);
	}

	/* patch generated code */
	for (i = 0; i < ctx->num_relocs; i++) {
		if (*ctx->reloc_tab[i].patch_addr == JIT_RELOC_MARKER) {
			*ctx->reloc_tab[i].patch_addr = (cell)jit_ctx_map_bytecode_addr(ctx, ctx->reloc_tab[i].bytecode_dest);
		} else {
			arm_patch_br(ctx, i);
		}
	}

	/* align to cell boundary */
	ctx->native.ptr = (cell*)JIT_CELL_ALIGN(ctx->native.ptr);

	ctx->native_size = 1 + ((int)ctx->native.ptr - (int)ctx->native.base) / sizeof(cell);
	ctx->native_size &= ~1; /* round up to even */

	compiled_hdr->dat = (cell)ctx->native.ptr - (cell)compiled_hdr;
	memcpy(ctx->native.ptr, ctx->bytecode.ptr, bytecode_hdr->hea - bytecode_hdr->dat);

	compiled_hdr->cip = (cell)jit_ctx_map_bytecode_addr(ctx, (cell*)bytecode_hdr->cip);

	_armdis_dump("__amx_jit.txt", ctx->native.base, ctx->native_size * sizeof(cell));

	jit_ctx_destroy(ctx);

	return 0; /* success */
}


cell __cdecl amx_exec_asm(cell* regs,cell* retval,cell stp,cell hea) {
	JIT_AMXRegs r;

	r.pri   = regs[0];
	r.alt   = regs[1];
	r.cip   = regs[2];
	r.data  = regs[3];
	r.stk   = regs[4];
	r.frm   = regs[5];
	r.amx   = regs[6];
	r.code  = regs[7];
	r.debug = regs[8];
	r.stp   = stp;
	r.hea   = hea;

	return arm_exec(&r, retval);
}


void* amx_opcodelist[OP_NUM_OPCODES];

void jit_init() {
	int i;
	for (i = 0; i < OP_NUM_OPCODES; i++) {
		amx_opcodelist[i] = (void*)i;
	}
}

void jit_flush_icache() {
#if defined(_WIN32) || defined(_WinCE)
	FlushInstructionCache(GetCurrentProcess(), NULL, 0);
#else
	/* FIXME: call arch-dependent function */
#endif
}

cell* jit_alloc_code_buff(int size) {
	cell* code_buff;
#if defined(_WIN32) || defined(_WinCE)
	int old_prot = 0;
#endif
	code_buff = (cell*)malloc(size);
#if defined(_WIN32) || defined(_WinCE)
	VirtualProtect(code_buff, size, PAGE_EXECUTE_READWRITE, &old_prot);
#endif
	return code_buff;
}

void jit_free_code_buff(cell* code_buff) {
	if (code_buff) free(code_buff);
}

