/*
 * Copyright (c) 2002 Wild West Software
 */

#ifndef __JIT_H__
#define __JIT_H__

#include <amx.h>

#ifdef __cplusplus
extern "C" {
#endif

#define JIT_STRUCT_OFFS(_type, _member) \
	(int)((char*) &((_type*)0)->_member)

#define JIT_CELL_ALIGN(_x) \
	( ((int)_x + (sizeof(cell) - 1)) & ~(sizeof(cell) - 1) )

#define JIT_RELOC_MARKER 0xC0DEC0DA

typedef struct _JIT_CodePtr {
	cell* base;
	cell* ptr;
} JIT_CodePtr;

typedef struct _JIT_CodeMap {
	cell* bytecode;
	cell* native;
} JIT_CodeMap;

typedef struct _JIT_RelocTable {
	cell* patch_addr;
	cell* bytecode_dest;
} JIT_RelocTable;

typedef struct _JIT_CompilerContext {
	JIT_CodePtr     bytecode;
	JIT_CodePtr     native;
	int             bytecode_size; /* in cells */
	int             native_size;   /* in cells */
	int             map_size;
	JIT_CodeMap*    code_map;
	int             num_relocs;
	JIT_RelocTable* reloc_tab;
} JIT_CompilerContext;

typedef struct _JIT_AMXRegs {
	cell pri;
	cell alt;
	cell cip;
	cell data;
	cell stk;
	cell frm;
	cell amx;
	cell code;
	cell debug;
	cell stp;
	cell hea;
} JIT_AMXRegs;

JIT_CompilerContext* jit_ctx_create(cell* bytecode_base, int bytecode_size, cell* native_base);
void                 jit_ctx_destroy(JIT_CompilerContext* ctx);
void                 jit_ctx_add_reloc(JIT_CompilerContext* ctx, cell* patch_addr, cell* bytecode_dest);
cell*                jit_ctx_map_bytecode_addr(JIT_CompilerContext* ctx, cell* bytecode_addr);

void  jit_init(void);
void  jit_flush_icache(void);
cell* jit_alloc_code_buff(int size);
void  jit_free_code_buff(cell* code_buff);

typedef int (*jit_trampoline_fn)(void);
typedef void (*jit_arch_compile_opcode_fn)(JIT_CompilerContext* ctx);
typedef cell (*jit_arch_exec_fn)(JIT_AMXRegs* regs, cell* retval);
typedef void (*jit_arch_patch_br_fn)(JIT_CompilerContext* ctx, int reloc_num);


int AMXAPI getMaxCodeSize(void);
int AMXAPI asm_runJIT(void* sourceAMXbase, void* jumparray, void* compiledAMXbase);
cell __cdecl amx_exec_asm(cell* regs,cell* retval,cell stp,cell hea);

void* amx_opcodelist[];

#ifdef __cplusplus
}
#endif

#endif /* __JIT_H__ */
