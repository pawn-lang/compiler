/* Macros for DPI ops, auto-generated from template */


/* mov/mvn */

/* Rd := imm8 ROR rot */
#define ARM_MOV_REG_IMM_COND(p, reg, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_MOV, reg, 0, imm8, rot, cond)
#define ARM_MOV_REG_IMM(p, reg, imm8, rot) \
	ARM_MOV_REG_IMM_COND(p, reg, imm8, rot, ARMCOND_AL)
#define ARM_MOV_REG_IMM8(p, reg, imm8) \
	ARM_MOV_REG_IMM(p, reg, imm8, 0)
/* S */
#define ARM_MOVS_REG_IMM_COND(p, reg, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_MOV, reg, 0, imm8, rot, cond)
#define ARM_MOVS_REG_IMM(p, reg, imm8, rot) \
	ARM_MOVS_REG_IMM_COND(p, reg, imm8, rot, ARMCOND_AL)


/* Rd := Rm */
#define ARM_MOV_REG_REG_COND(p, rd, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_MOV, rd, 0, rm, cond)
#define ARM_MOV_REG_REG(p, rd, rm) \
	ARM_MOV_REG_REG_COND(p, rd, rm, ARMCOND_AL)
/* S */
#define ARM_MOVS_REG_REG_COND(p, rd, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_MOV, rd, 0, rm, cond)
#define ARM_MOVS_REG_REG(p, rd, rm) \
	ARM_MOVS_REG_REG_COND(p, rd, rm, ARMCOND_AL)



/* Rd := Rm <shift_type> imm_shift */
#define ARM_MOV_REG_IMMSHIFT_COND(p, rd, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_MOV, rd, 0, rm, shift_type, imm_shift, cond)
#define ARM_MOV_REG_IMMSHIFT(p, rd, rm, shift_type, imm_shift) \
	ARM_MOV_REG_IMMSHIFT_COND(p, rd, rm, shift_type, imm_shift, ARMCOND_AL)
/* S */
#define ARM_MOVS_REG_IMMSHIFT_COND(p, rd, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_MOV, rd, 0, rm, shift_type, imm_shift, cond)
#define ARM_MOVS_REG_IMMSHIFT(p, rd, rm, shift_type, imm_shift) \
	ARM_MOVS_REG_IMMSHIFT_COND(p, rd, rm, shift_type, imm_shift, ARMCOND_AL)



/* Rd := (Rm <shift_type> Rs) */
#define ARM_MOV_REG_REGSHIFT_COND(p, rd, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_MOV, rd, 0, rm, shift_type, rs, cond)
#define ARM_MOV_REG_REGSHIFT(p, rd, rm, shift_type, rs) \
	ARM_MOV_REG_REGSHIFT_COND(p, rd, rm, shift_type, rs, ARMCOND_AL)
/* S */
#define ARM_MOVS_REG_REGSHIFT_COND(p, rd, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_MOV, rd, 0, rm, shift_type, rs, cond)
#define ARM_MOVS_REG_REGSHIFT(p, rd, rm, shift_type, rs) \
	ARM_MOVS_REG_REGSHIFT_COND(p, rd, rm, shift_type, rs, ARMCOND_AL)


/* Rd := imm8 ROR rot */
#define ARM_MVN_REG_IMM_COND(p, reg, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_MVN, reg, 0, imm8, rot, cond)
#define ARM_MVN_REG_IMM(p, reg, imm8, rot) \
	ARM_MVN_REG_IMM_COND(p, reg, imm8, rot, ARMCOND_AL)
#define ARM_MVN_REG_IMM8(p, reg, imm8) \
	ARM_MVN_REG_IMM(p, reg, imm8, 0)
/* S */
#define ARM_MVNS_REG_IMM_COND(p, reg, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_MVN, reg, 0, imm8, rot, cond)
#define ARM_MVNS_REG_IMM(p, reg, imm8, rot) \
	ARM_MVNS_REG_IMM_COND(p, reg, imm8, rot, ARMCOND_AL)


/* Rd := Rm */
#define ARM_MVN_REG_REG_COND(p, rd, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_MVN, rd, 0, rm, cond)
#define ARM_MVN_REG_REG(p, rd, rm) \
	ARM_MVN_REG_REG_COND(p, rd, rm, ARMCOND_AL)
/* S */
#define ARM_MVNS_REG_REG_COND(p, rd, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_MVN, rd, 0, rm, cond)
#define ARM_MVNS_REG_REG(p, rd, rm) \
	ARM_MVNS_REG_REG_COND(p, rd, rm, ARMCOND_AL)



/* Rd := Rm <shift_type> imm_shift */
#define ARM_MVN_REG_IMMSHIFT_COND(p, rd, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_MVN, rd, 0, rm, shift_type, imm_shift, cond)
#define ARM_MVN_REG_IMMSHIFT(p, rd, rm, shift_type, imm_shift) \
	ARM_MVN_REG_IMMSHIFT_COND(p, rd, rm, shift_type, imm_shift, ARMCOND_AL)
/* S */
#define ARM_MVNS_REG_IMMSHIFT_COND(p, rd, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_MVN, rd, 0, rm, shift_type, imm_shift, cond)
#define ARM_MVNS_REG_IMMSHIFT(p, rd, rm, shift_type, imm_shift) \
	ARM_MVNS_REG_IMMSHIFT_COND(p, rd, rm, shift_type, imm_shift, ARMCOND_AL)



/* Rd := (Rm <shift_type> Rs) */
#define ARM_MVN_REG_REGSHIFT_COND(p, rd, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_MVN, rd, 0, rm, shift_type, rs, cond)
#define ARM_MVN_REG_REGSHIFT(p, rd, rm, shift_type, rs) \
	ARM_MVN_REG_REGSHIFT_COND(p, rd, rm, shift_type, rs, ARMCOND_AL)
/* S */
#define ARM_MVNS_REG_REGSHIFT_COND(p, rd, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_MVN, rd, 0, rm, shift_type, rs, cond)
#define ARM_MVNS_REG_REGSHIFT(p, rd, rm, shift_type, rs) \
	ARM_MVNS_REG_REGSHIFT_COND(p, rd, rm, shift_type, rs, ARMCOND_AL)



/* DPIs, arithmetic and logical */

/* -- AND -- */

/* Rd := Rn AND (imm8 ROR rot) ; rot is power of 2 */
#define ARM_AND_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_AND, rd, rn, imm8, rot, cond)
#define ARM_AND_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_AND_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_ANDS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_AND, rd, rn, imm8, rot, cond)
#define ARM_ANDS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_ANDS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn AND imm8 */
#define ARM_AND_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_AND_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_AND_REG_IMM8(p, rd, rn, imm8) \
	ARM_AND_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_ANDS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_ANDS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_ANDS_REG_IMM8(p, rd, rn, imm8) \
	ARM_ANDS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn AND Rm */
#define ARM_AND_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_AND, rd, rn, rm, cond)
#define ARM_AND_REG_REG(p, rd, rn, rm) \
	ARM_AND_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_ANDS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_AND, rd, rn, rm, cond)
#define ARM_ANDS_REG_REG(p, rd, rn, rm) \
	ARM_ANDS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn AND (Rm <shift_type> imm_shift) */
#define ARM_AND_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_AND, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_AND_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_AND_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_ANDS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_AND, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_ANDS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_ANDS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn AND (Rm <shift_type> Rs) */
#define ARM_AND_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_AND, rd, rn, rm, shift_t, rs, cond)
#define ARM_AND_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_AND_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_ANDS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_AND, rd, rn, rm, shift_t, rs, cond)
#define ARM_ANDS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_ANDS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- EOR -- */

/* Rd := Rn EOR (imm8 ROR rot) ; rot is power of 2 */
#define ARM_EOR_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_EOR, rd, rn, imm8, rot, cond)
#define ARM_EOR_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_EOR_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_EORS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_EOR, rd, rn, imm8, rot, cond)
#define ARM_EORS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_EORS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn EOR imm8 */
#define ARM_EOR_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_EOR_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_EOR_REG_IMM8(p, rd, rn, imm8) \
	ARM_EOR_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_EORS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_EORS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_EORS_REG_IMM8(p, rd, rn, imm8) \
	ARM_EORS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn EOR Rm */
#define ARM_EOR_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_EOR, rd, rn, rm, cond)
#define ARM_EOR_REG_REG(p, rd, rn, rm) \
	ARM_EOR_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_EORS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_EOR, rd, rn, rm, cond)
#define ARM_EORS_REG_REG(p, rd, rn, rm) \
	ARM_EORS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn EOR (Rm <shift_type> imm_shift) */
#define ARM_EOR_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_EOR, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_EOR_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_EOR_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_EORS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_EOR, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_EORS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_EORS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn EOR (Rm <shift_type> Rs) */
#define ARM_EOR_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_EOR, rd, rn, rm, shift_t, rs, cond)
#define ARM_EOR_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_EOR_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_EORS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_EOR, rd, rn, rm, shift_t, rs, cond)
#define ARM_EORS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_EORS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- SUB -- */

/* Rd := Rn SUB (imm8 ROR rot) ; rot is power of 2 */
#define ARM_SUB_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_SUB, rd, rn, imm8, rot, cond)
#define ARM_SUB_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_SUB_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_SUBS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_SUB, rd, rn, imm8, rot, cond)
#define ARM_SUBS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_SUBS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn SUB imm8 */
#define ARM_SUB_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_SUB_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_SUB_REG_IMM8(p, rd, rn, imm8) \
	ARM_SUB_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_SUBS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_SUBS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_SUBS_REG_IMM8(p, rd, rn, imm8) \
	ARM_SUBS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn SUB Rm */
#define ARM_SUB_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_SUB, rd, rn, rm, cond)
#define ARM_SUB_REG_REG(p, rd, rn, rm) \
	ARM_SUB_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_SUBS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_SUB, rd, rn, rm, cond)
#define ARM_SUBS_REG_REG(p, rd, rn, rm) \
	ARM_SUBS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn SUB (Rm <shift_type> imm_shift) */
#define ARM_SUB_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_SUB, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_SUB_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_SUB_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_SUBS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_SUB, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_SUBS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_SUBS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn SUB (Rm <shift_type> Rs) */
#define ARM_SUB_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_SUB, rd, rn, rm, shift_t, rs, cond)
#define ARM_SUB_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_SUB_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_SUBS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_SUB, rd, rn, rm, shift_t, rs, cond)
#define ARM_SUBS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_SUBS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- RSB -- */

/* Rd := Rn RSB (imm8 ROR rot) ; rot is power of 2 */
#define ARM_RSB_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_RSB, rd, rn, imm8, rot, cond)
#define ARM_RSB_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_RSB_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_RSBS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_RSB, rd, rn, imm8, rot, cond)
#define ARM_RSBS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_RSBS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn RSB imm8 */
#define ARM_RSB_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_RSB_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_RSB_REG_IMM8(p, rd, rn, imm8) \
	ARM_RSB_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_RSBS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_RSBS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_RSBS_REG_IMM8(p, rd, rn, imm8) \
	ARM_RSBS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn RSB Rm */
#define ARM_RSB_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_RSB, rd, rn, rm, cond)
#define ARM_RSB_REG_REG(p, rd, rn, rm) \
	ARM_RSB_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_RSBS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_RSB, rd, rn, rm, cond)
#define ARM_RSBS_REG_REG(p, rd, rn, rm) \
	ARM_RSBS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn RSB (Rm <shift_type> imm_shift) */
#define ARM_RSB_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_RSB, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_RSB_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_RSB_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_RSBS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_RSB, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_RSBS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_RSBS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn RSB (Rm <shift_type> Rs) */
#define ARM_RSB_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_RSB, rd, rn, rm, shift_t, rs, cond)
#define ARM_RSB_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_RSB_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_RSBS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_RSB, rd, rn, rm, shift_t, rs, cond)
#define ARM_RSBS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_RSBS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- ADD -- */

/* Rd := Rn ADD (imm8 ROR rot) ; rot is power of 2 */
#define ARM_ADD_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_ADD, rd, rn, imm8, rot, cond)
#define ARM_ADD_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_ADD_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_ADDS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_ADD, rd, rn, imm8, rot, cond)
#define ARM_ADDS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_ADDS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn ADD imm8 */
#define ARM_ADD_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_ADD_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_ADD_REG_IMM8(p, rd, rn, imm8) \
	ARM_ADD_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_ADDS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_ADDS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_ADDS_REG_IMM8(p, rd, rn, imm8) \
	ARM_ADDS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn ADD Rm */
#define ARM_ADD_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_ADD, rd, rn, rm, cond)
#define ARM_ADD_REG_REG(p, rd, rn, rm) \
	ARM_ADD_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_ADDS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_ADD, rd, rn, rm, cond)
#define ARM_ADDS_REG_REG(p, rd, rn, rm) \
	ARM_ADDS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn ADD (Rm <shift_type> imm_shift) */
#define ARM_ADD_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_ADD, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_ADD_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_ADD_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_ADDS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_ADD, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_ADDS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_ADDS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn ADD (Rm <shift_type> Rs) */
#define ARM_ADD_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_ADD, rd, rn, rm, shift_t, rs, cond)
#define ARM_ADD_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_ADD_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_ADDS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_ADD, rd, rn, rm, shift_t, rs, cond)
#define ARM_ADDS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_ADDS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- ADC -- */

/* Rd := Rn ADC (imm8 ROR rot) ; rot is power of 2 */
#define ARM_ADC_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_ADC, rd, rn, imm8, rot, cond)
#define ARM_ADC_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_ADC_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_ADCS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_ADC, rd, rn, imm8, rot, cond)
#define ARM_ADCS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_ADCS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn ADC imm8 */
#define ARM_ADC_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_ADC_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_ADC_REG_IMM8(p, rd, rn, imm8) \
	ARM_ADC_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_ADCS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_ADCS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_ADCS_REG_IMM8(p, rd, rn, imm8) \
	ARM_ADCS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn ADC Rm */
#define ARM_ADC_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_ADC, rd, rn, rm, cond)
#define ARM_ADC_REG_REG(p, rd, rn, rm) \
	ARM_ADC_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_ADCS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_ADC, rd, rn, rm, cond)
#define ARM_ADCS_REG_REG(p, rd, rn, rm) \
	ARM_ADCS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn ADC (Rm <shift_type> imm_shift) */
#define ARM_ADC_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_ADC, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_ADC_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_ADC_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_ADCS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_ADC, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_ADCS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_ADCS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn ADC (Rm <shift_type> Rs) */
#define ARM_ADC_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_ADC, rd, rn, rm, shift_t, rs, cond)
#define ARM_ADC_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_ADC_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_ADCS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_ADC, rd, rn, rm, shift_t, rs, cond)
#define ARM_ADCS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_ADCS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- SBC -- */

/* Rd := Rn SBC (imm8 ROR rot) ; rot is power of 2 */
#define ARM_SBC_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_SBC, rd, rn, imm8, rot, cond)
#define ARM_SBC_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_SBC_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_SBCS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_SBC, rd, rn, imm8, rot, cond)
#define ARM_SBCS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_SBCS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn SBC imm8 */
#define ARM_SBC_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_SBC_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_SBC_REG_IMM8(p, rd, rn, imm8) \
	ARM_SBC_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_SBCS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_SBCS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_SBCS_REG_IMM8(p, rd, rn, imm8) \
	ARM_SBCS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn SBC Rm */
#define ARM_SBC_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_SBC, rd, rn, rm, cond)
#define ARM_SBC_REG_REG(p, rd, rn, rm) \
	ARM_SBC_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_SBCS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_SBC, rd, rn, rm, cond)
#define ARM_SBCS_REG_REG(p, rd, rn, rm) \
	ARM_SBCS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn SBC (Rm <shift_type> imm_shift) */
#define ARM_SBC_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_SBC, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_SBC_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_SBC_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_SBCS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_SBC, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_SBCS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_SBCS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn SBC (Rm <shift_type> Rs) */
#define ARM_SBC_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_SBC, rd, rn, rm, shift_t, rs, cond)
#define ARM_SBC_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_SBC_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_SBCS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_SBC, rd, rn, rm, shift_t, rs, cond)
#define ARM_SBCS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_SBCS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- RSC -- */

/* Rd := Rn RSC (imm8 ROR rot) ; rot is power of 2 */
#define ARM_RSC_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_RSC, rd, rn, imm8, rot, cond)
#define ARM_RSC_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_RSC_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_RSCS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_RSC, rd, rn, imm8, rot, cond)
#define ARM_RSCS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_RSCS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn RSC imm8 */
#define ARM_RSC_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_RSC_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_RSC_REG_IMM8(p, rd, rn, imm8) \
	ARM_RSC_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_RSCS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_RSCS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_RSCS_REG_IMM8(p, rd, rn, imm8) \
	ARM_RSCS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn RSC Rm */
#define ARM_RSC_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_RSC, rd, rn, rm, cond)
#define ARM_RSC_REG_REG(p, rd, rn, rm) \
	ARM_RSC_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_RSCS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_RSC, rd, rn, rm, cond)
#define ARM_RSCS_REG_REG(p, rd, rn, rm) \
	ARM_RSCS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn RSC (Rm <shift_type> imm_shift) */
#define ARM_RSC_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_RSC, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_RSC_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_RSC_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_RSCS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_RSC, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_RSCS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_RSCS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn RSC (Rm <shift_type> Rs) */
#define ARM_RSC_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_RSC, rd, rn, rm, shift_t, rs, cond)
#define ARM_RSC_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_RSC_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_RSCS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_RSC, rd, rn, rm, shift_t, rs, cond)
#define ARM_RSCS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_RSCS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- ORR -- */

/* Rd := Rn ORR (imm8 ROR rot) ; rot is power of 2 */
#define ARM_ORR_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_ORR, rd, rn, imm8, rot, cond)
#define ARM_ORR_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_ORR_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_ORRS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_ORR, rd, rn, imm8, rot, cond)
#define ARM_ORRS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_ORRS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn ORR imm8 */
#define ARM_ORR_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_ORR_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_ORR_REG_IMM8(p, rd, rn, imm8) \
	ARM_ORR_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_ORRS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_ORRS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_ORRS_REG_IMM8(p, rd, rn, imm8) \
	ARM_ORRS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn ORR Rm */
#define ARM_ORR_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_ORR, rd, rn, rm, cond)
#define ARM_ORR_REG_REG(p, rd, rn, rm) \
	ARM_ORR_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_ORRS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_ORR, rd, rn, rm, cond)
#define ARM_ORRS_REG_REG(p, rd, rn, rm) \
	ARM_ORRS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn ORR (Rm <shift_type> imm_shift) */
#define ARM_ORR_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_ORR, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_ORR_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_ORR_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_ORRS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_ORR, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_ORRS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_ORRS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn ORR (Rm <shift_type> Rs) */
#define ARM_ORR_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_ORR, rd, rn, rm, shift_t, rs, cond)
#define ARM_ORR_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_ORR_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_ORRS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_ORR, rd, rn, rm, shift_t, rs, cond)
#define ARM_ORRS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_ORRS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)

/* -- BIC -- */

/* Rd := Rn BIC (imm8 ROR rot) ; rot is power of 2 */
#define ARM_BIC_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_REG_IMM8ROT_COND(p, ARMOP_BIC, rd, rn, imm8, rot, cond)
#define ARM_BIC_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_BIC_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)
#define ARM_BICS_REG_IMM_COND(p, rd, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_BIC, rd, rn, imm8, rot, cond)
#define ARM_BICS_REG_IMM(p, rd, rn, imm8, rot) \
	ARM_BICS_REG_IMM_COND(p, rd, rn, imm8, rot, ARMCOND_AL)

/* Rd := Rn BIC imm8 */
#define ARM_BIC_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_BIC_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_BIC_REG_IMM8(p, rd, rn, imm8) \
	ARM_BIC_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)
#define ARM_BICS_REG_IMM8_COND(p, rd, rn, imm8, cond) \
	ARM_BICS_REG_IMM_COND(p, rd, rn, imm8, 0, cond)
#define ARM_BICS_REG_IMM8(p, rd, rn, imm8) \
	ARM_BICS_REG_IMM8_COND(p, rd, rn, imm8, ARMCOND_AL)


/* Rd := Rn BIC Rm */
#define ARM_BIC_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_REG_REG_COND(p, ARMOP_BIC, rd, rn, rm, cond)
#define ARM_BIC_REG_REG(p, rd, rn, rm) \
	ARM_BIC_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)
#define ARM_BICS_REG_REG_COND(p, rd, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_BIC, rd, rn, rm, cond)
#define ARM_BICS_REG_REG(p, rd, rn, rm) \
	ARM_BICS_REG_REG_COND(p, rd, rn, rm, ARMCOND_AL)


/* Rd := Rn BIC (Rm <shift_type> imm_shift) */
#define ARM_BIC_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_REG_IMMSHIFT_COND(p, ARMOP_BIC, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_BIC_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_BIC_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)
#define ARM_BICS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_BIC, rd, rn, rm, shift_type, imm_shift, cond)
#define ARM_BICS_REG_IMMSHIFT(p, rd, rn, rm, shift_type, imm_shift) \
	ARM_BICS_REG_IMMSHIFT_COND(p, rd, rn, rm, shift_type, imm_shift, ARMCOND_AL)


/* Rd := Rn BIC (Rm <shift_type> Rs) */
#define ARM_BIC_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_REG_REGSHIFT_COND(p, ARMOP_BIC, rd, rn, rm, shift_t, rs, cond)
#define ARM_BIC_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_BIC_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)
#define ARM_BICS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, cond) \
	ARM_DPIOP_S_REG_REGSHIFT_COND(p, ARMOP_BIC, rd, rn, rm, shift_t, rs, cond)
#define ARM_BICS_REG_REGSHIFT(p, rd, rn, rm, shift_type, rs) \
	ARM_BICS_REG_REGSHIFT_COND(p, rd, rn, rm, shift_type, rs, ARMCOND_AL)





/* DPIs, comparison */

/* PSR := TST Rn, (imm8 ROR 2*rot) */
#define ARM_TST_REG_IMM_COND(p, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_TST, 0, rn, imm8, rot, cond)
#define ARM_TST_REG_IMM(p, rn, imm8, rot) \
	ARM_TST_REG_IMM_COND(p, rn, imm8, rot, ARMCOND_AL)

/* PSR := TST Rn, imm8 */
#define ARM_TST_REG_IMM8_COND(p, rn, imm8, cond) \
	ARM_TST_REG_IMM_COND(p, rn, imm8, 0, cond)
#define ARM_TST_REG_IMM8(p, rn, imm8) \
	ARM_TST_REG_IMM8_COND(p, rn, imm8, ARMCOND_AL)

/* PSR := TST Rn, Rm */
#define ARM_TST_REG_REG_COND(p, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_TST, 0, rn, rm, cond)
#define ARM_TST_REG_REG(p, rn, rm) \
	ARM_TST_REG_REG_COND(p, rn, rm, ARMCOND_AL)

/* PSR := TST Rn, (Rm <shift_type> imm8) */
#define ARM_TST_REG_IMMSHIFT_COND(p, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_TST, 0, rn, rm, shift_type, imm_shift, cond)
#define ARM_TST_REG_IMMSHIFT(p, rn, rm, shift_type, imm_shift) \
	ARM_TST_REG_IMMSHIFT_COND(p, rn, rm, shift_type, imm_shift, ARMCOND_AL)
/* PSR := TEQ Rn, (imm8 ROR 2*rot) */
#define ARM_TEQ_REG_IMM_COND(p, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_TEQ, 0, rn, imm8, rot, cond)
#define ARM_TEQ_REG_IMM(p, rn, imm8, rot) \
	ARM_TEQ_REG_IMM_COND(p, rn, imm8, rot, ARMCOND_AL)

/* PSR := TEQ Rn, imm8 */
#define ARM_TEQ_REG_IMM8_COND(p, rn, imm8, cond) \
	ARM_TEQ_REG_IMM_COND(p, rn, imm8, 0, cond)
#define ARM_TEQ_REG_IMM8(p, rn, imm8) \
	ARM_TEQ_REG_IMM8_COND(p, rn, imm8, ARMCOND_AL)

/* PSR := TEQ Rn, Rm */
#define ARM_TEQ_REG_REG_COND(p, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_TEQ, 0, rn, rm, cond)
#define ARM_TEQ_REG_REG(p, rn, rm) \
	ARM_TEQ_REG_REG_COND(p, rn, rm, ARMCOND_AL)

/* PSR := TEQ Rn, (Rm <shift_type> imm8) */
#define ARM_TEQ_REG_IMMSHIFT_COND(p, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_TEQ, 0, rn, rm, shift_type, imm_shift, cond)
#define ARM_TEQ_REG_IMMSHIFT(p, rn, rm, shift_type, imm_shift) \
	ARM_TEQ_REG_IMMSHIFT_COND(p, rn, rm, shift_type, imm_shift, ARMCOND_AL)
/* PSR := CMP Rn, (imm8 ROR 2*rot) */
#define ARM_CMP_REG_IMM_COND(p, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_CMP, 0, rn, imm8, rot, cond)
#define ARM_CMP_REG_IMM(p, rn, imm8, rot) \
	ARM_CMP_REG_IMM_COND(p, rn, imm8, rot, ARMCOND_AL)

/* PSR := CMP Rn, imm8 */
#define ARM_CMP_REG_IMM8_COND(p, rn, imm8, cond) \
	ARM_CMP_REG_IMM_COND(p, rn, imm8, 0, cond)
#define ARM_CMP_REG_IMM8(p, rn, imm8) \
	ARM_CMP_REG_IMM8_COND(p, rn, imm8, ARMCOND_AL)

/* PSR := CMP Rn, Rm */
#define ARM_CMP_REG_REG_COND(p, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_CMP, 0, rn, rm, cond)
#define ARM_CMP_REG_REG(p, rn, rm) \
	ARM_CMP_REG_REG_COND(p, rn, rm, ARMCOND_AL)

/* PSR := CMP Rn, (Rm <shift_type> imm8) */
#define ARM_CMP_REG_IMMSHIFT_COND(p, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_CMP, 0, rn, rm, shift_type, imm_shift, cond)
#define ARM_CMP_REG_IMMSHIFT(p, rn, rm, shift_type, imm_shift) \
	ARM_CMP_REG_IMMSHIFT_COND(p, rn, rm, shift_type, imm_shift, ARMCOND_AL)
/* PSR := CMN Rn, (imm8 ROR 2*rot) */
#define ARM_CMN_REG_IMM_COND(p, rn, imm8, rot, cond) \
	ARM_DPIOP_S_REG_IMM8ROT_COND(p, ARMOP_CMN, 0, rn, imm8, rot, cond)
#define ARM_CMN_REG_IMM(p, rn, imm8, rot) \
	ARM_CMN_REG_IMM_COND(p, rn, imm8, rot, ARMCOND_AL)

/* PSR := CMN Rn, imm8 */
#define ARM_CMN_REG_IMM8_COND(p, rn, imm8, cond) \
	ARM_CMN_REG_IMM_COND(p, rn, imm8, 0, cond)
#define ARM_CMN_REG_IMM8(p, rn, imm8) \
	ARM_CMN_REG_IMM8_COND(p, rn, imm8, ARMCOND_AL)

/* PSR := CMN Rn, Rm */
#define ARM_CMN_REG_REG_COND(p, rn, rm, cond) \
	ARM_DPIOP_S_REG_REG_COND(p, ARMOP_CMN, 0, rn, rm, cond)
#define ARM_CMN_REG_REG(p, rn, rm) \
	ARM_CMN_REG_REG_COND(p, rn, rm, ARMCOND_AL)

/* PSR := CMN Rn, (Rm <shift_type> imm8) */
#define ARM_CMN_REG_IMMSHIFT_COND(p, rn, rm, shift_type, imm_shift, cond) \
	ARM_DPIOP_S_REG_IMMSHIFT_COND(p, ARMOP_CMN, 0, rn, rm, shift_type, imm_shift, cond)
#define ARM_CMN_REG_IMMSHIFT(p, rn, rm, shift_type, imm_shift) \
	ARM_CMN_REG_IMMSHIFT_COND(p, rn, rm, shift_type, imm_shift, ARMCOND_AL)

/* end generated */

