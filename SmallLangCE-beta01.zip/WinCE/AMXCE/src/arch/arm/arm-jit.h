/*
 * Copyright (c) 2002 Sergey Chaban <serge@wildwestsoftware.com>
 * Copyright (c) 2002 Wild West Software
 */

#ifndef __ARM_JIT_H__
#define __ARM_JIT_H__

#include <amx.h>
#include <jit.h>


#ifdef __cplusplus
extern "C" {
#endif

int arm_get_max_code_size(void);
void arm_compile_opcode(JIT_CompilerContext* ctx);
cell arm_exec(JIT_AMXRegs* regs, cell* retval);
void arm_patch_br(JIT_CompilerContext* ctx, int reloc_num);

#ifdef __cplusplus
}
#endif

#endif /* __ARM_JIT_H__ */

