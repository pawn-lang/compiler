/*
 * Copyright (c) 2002 Sergey Chaban <serge@wildwestsoftware.com>
 * Copyright (c) 2002 Wild West Software
 */

#include "arm-jit.h"
#include "arm-codegen.h"

#define REG_PRI ARMREG_R0
#define REG_ALT ARMREG_R1

#define REG_FRM ARMREG_R2
#define REG_STK ARMREG_R3

#define REG_STP ARMREG_R4
#define REG_HEA ARMREG_R5

#define REG_DAT ARMREG_R6
#define REG_TMP ARMREG_R7

#define REG_AMX ARMREG_R8

#define REGS_TO_SAVE ( (1 << ARMREG_R4) | (1 << ARMREG_R5) | (1 << ARMREG_R6) | (1 << ARMREG_R7) | (1 << ARMREG_R8) )


int arm_get_max_code_size() {
	return 32;
}

cell arm_exec(JIT_AMXRegs* regs, cell* retval) {
	arminstr_t* tramp = (arminstr_t*)jit_alloc_code_buff(256);
	arminstr_t* p = tramp;

	p = arm_emit_lean_prologue(p, 0, REGS_TO_SAVE);

	p = arm_mov_reg_imm32(p, REG_PRI, regs->pri);
	p = arm_mov_reg_imm32(p, REG_ALT, regs->alt);
	p = arm_mov_reg_imm32(p, REG_DAT, regs->data);
	p = arm_mov_reg_imm32(p, REG_STK, regs->data + regs->stk);
	p = arm_mov_reg_imm32(p, REG_FRM, regs->data + regs->frm);
	p = arm_mov_reg_imm32(p, REG_STP, regs->stp);
	p = arm_mov_reg_imm32(p, REG_HEA, regs->hea);
	p = arm_mov_reg_imm32(p, REG_AMX, regs->amx);

	p = arm_mov_reg_imm32(p, REG_TMP, regs->cip);
	ARM_MOV_REG_REG(p, ARMREG_LR, ARMREG_PC);
	ARM_MOV_REG_REG(p, ARMREG_PC, REG_TMP);

	p = arm_emit_std_epilogue(p, 0, REGS_TO_SAVE);

	*retval = ((jit_trampoline_fn)tramp)();

	return 0;
}


void arm_patch_br(JIT_CompilerContext* ctx, int reloc_num) {
	cell* dest_addr = jit_ctx_map_bytecode_addr(ctx, ctx->reloc_tab[reloc_num].bytecode_dest);
	int offs = (int)(dest_addr - ctx->reloc_tab[reloc_num].patch_addr) - 2;
	((ARMInstrBR*)ctx->reloc_tab[reloc_num].patch_addr)->offset = offs;
}


#define GET_PARAM(_v, _p) do {_v=*(cell*)_p++;} while (0)

#define SELECT_REG(_op) reg = (op == OP_ ## _op ## _ ## PRI ? REG_PRI : REG_ALT)

/* [STK] := _reg; STK -= sizeof(cell) */
#define PUSH_REG(_p, _reg) \
	ARM_EMIT_WXFER_IMM(_p, -(int)sizeof(cell), _reg, REG_STK, ARMOP_STR, 1, 0, 1, ARMCOND_AL);

/* STK += sizeof(cell); _reg := [STK] */
#define POP_REG(_p, _reg) \
	ARM_EMIT_WXFER_IMM(_p, (int)sizeof(cell), _reg, REG_STK, ARMOP_LDR, 1, 0, 0, ARMCOND_AL);

/*
 * params: code ptr, dest reg, base reg, imm offset
 * trashes REG_TMP
 */
#define LDR_BASE(_p, _dreg, _breg, _offs) \
	if (((_offs) & ~ARM_WXFER_MAX_OFFS) == 0 || (-(int)(_offs) <= ARM_WXFER_MAX_OFFS)) { \
		ARM_LDR_IMM((_p), (_dreg), (_breg), (_offs)); \
	} else { \
		_p = arm_mov_reg_imm32(_p, REG_TMP, _offs); \
		ARM_LDR_REG_REG((_p), (_dreg), (_breg), REG_TMP); \
	}

#define STR_BASE(_p, _dreg, _breg, _offs) \
	if (((_offs) & ~ARM_WXFER_MAX_OFFS) == 0 || (-(int)(_offs) <= ARM_WXFER_MAX_OFFS)) { \
		ARM_STR_IMM((_p), (_dreg), (_breg), (_offs)); \
	} else { \
		_p = arm_mov_reg_imm32(_p, REG_TMP, _offs); \
		ARM_STR_REG_REG((_p), (_dreg), (_breg), REG_TMP); \
	}

#define LDR_DAT(_p, _dreg, _offs) LDR_BASE(_p, _dreg, REG_DAT, _offs)
#define LDR_FRM(_p, _dreg, _offs) LDR_BASE(_p, _dreg, REG_FRM, _offs)

#define STR_DAT(_p, _dreg, _offs) STR_BASE(_p, _dreg, REG_DAT, _offs)
#define STR_FRM(_p, _dreg, _offs) STR_BASE(_p, _dreg, REG_FRM, _offs)


/*
 * _dreg := effective_address(_breg + _offs)
 * trashes REG_TMP
 * TODO: optimize
 */
#define LDEA_BASE(_p, _dreg, _breg, _offs) \
	do { \
		_p = arm_mov_reg_imm32(_p, REG_TMP, _offs); \
		ARM_ADD_REG_REG(_p, _dreg, _breg, REG_TMP); \
	} while (0)


#define LONG_JUMP(_p, _addr) \
	ARM_LDR_IMM((_p), REG_TMP, ARMREG_PC, 0); \
	ARM_B(p, 0); \
	jit_ctx_add_reloc(ctx, (cell*)p, (cell*)_addr); \
	*(cell*)p++ = (cell)(_addr); \
	ARM_MOV_REG_REG(p, ARMREG_PC, REG_TMP);

#define CMP_BR_(_cond, _r1, _r2, _addr) \
	ARM_CMP_REG_REG(p, (_r1), (_r2)); \
	jit_ctx_add_reloc(ctx, (cell*)p, (cell*)_addr); \
	ARM_B_COND(p, (_cond), 0);

/* FIXME: support any imm, not only imm8 */
#define CMP_IMM_BR_(_cond, _r1, _imm, _addr) \
	ARM_CMP_REG_IMM8(p, (_r1), (_imm)); \
	jit_ctx_add_reloc(ctx, (cell*)p, (cell*)_addr); \
	ARM_B_COND(p, (_cond), 0);

#define BR_(_cond) \
	GET_PARAM(addr, psrc); \
	CMP_BR_((_cond), REG_PRI, REG_ALT, addr); \
	op_size = 2;


void arm_compile_opcode(JIT_CompilerContext* ctx) {
	arminstr_t* p = (arminstr_t*)ctx->native.ptr;
	cell* psrc = ctx->bytecode.ptr;
	arminstr_t* br;
	cell offs, val, addr;
	int reg, i, op_size = 1;
	OPCODE op = *(OPCODE*)psrc++;

	switch (op) {
	case OP_NONE:
		break;

	/*
	 * Params: address
	 * Action: PRI/ALT := [DAT + address]
	 */
	case OP_LOAD_PRI:
	case OP_LOAD_ALT:
		SELECT_REG(LOAD);
		GET_PARAM(offs, psrc);
		LDR_DAT(p, reg, offs);
		op_size = 2;
		break;

	/*
	 * Params: offset
	 * Action: PRI/ALT := [FRM + offset]
	 */
	case OP_LOAD_S_PRI:
	case OP_LOAD_S_ALT:
		SELECT_REG(LOAD_S);
		GET_PARAM(offs, psrc);
		LDR_FRM(p, reg, offs);
		op_size = 2;
		break;

	/*
	 * Params: address
	 * Action: PRI/ALT := [[DAT+address]]
	 */ 
	case OP_LREF_PRI:
	case OP_LREF_ALT:
		SELECT_REG(LREF);
		GET_PARAM(offs, psrc);
		LDR_DAT(p, reg, offs);
		ARM_LDR_IMM(p, reg, reg, 0);
		op_size = 2;
		break;

	/*
	 * Params: offset
	 * Action: PRI/ALT := [[FRM + offset]]
	 */ 
	case OP_LREF_S_PRI:
	case OP_LREF_S_ALT:
		SELECT_REG(LREF_S);
		GET_PARAM(offs, psrc);
		LDR_FRM(p, reg, offs);
		ARM_LDR_IMM(p, reg, reg, 0);
		op_size = 2;
		break;

	/*
	 * Params: <none>
	 * Action: PRI := [DAT + PRI]
	 */
	case OP_LOAD_I:
		ARM_LDR_REG_REG(p, REG_PRI, REG_DAT, REG_PRI);
		break;

	/*
	 * Params: cell(1 | 2 | 4)
	 * Action: PRI := $param bytes from [DAT + PRI]
	 */
	case OP_LODB_I:
		GET_PARAM(val, psrc);
		switch (val) {
		case 1:
			ARM_LDRB_REG_REG(p, REG_PRI, REG_DAT, REG_PRI);
			break;
		case 2:
			ARM_LDRH_REG_REG(p, REG_PRI, REG_DAT, REG_PRI);
			break;
		case 4:
			ARM_LDR_REG_REG(p, REG_PRI, REG_DAT, REG_PRI);
			break;
		default:
			break;
		}
		op_size = 2;
		break;

	/*
	 * Params: value
	 * Action: PRI/ALT := value
	 */
	case OP_CONST_PRI:
	case OP_CONST_ALT:
		SELECT_REG(CONST);
		GET_PARAM(val, psrc);
		p = arm_mov_reg_imm32(p, reg, val);
		op_size = 2;
		break;

	/*
	 * Params: offset
	 * Action: PRI/ALT := FRM + offset
	 */
	case OP_ADDR_PRI:
	case OP_ADDR_ALT:
		SELECT_REG(ADDR);
		GET_PARAM(offs, psrc);
		LDEA_BASE(p, reg, REG_FRM, offs);
		op_size = 2;
		break;

	/*
	 * Params: address
	 * [DAT + address] := PRI/ALT
	 */
	case OP_STOR_PRI:
	case OP_STOR_ALT:
		SELECT_REG(STOR);
		GET_PARAM(offs, psrc);
		STR_DAT(p, reg, offs);
		op_size = 2;
		break;

	/*
	 * Params: offset
	 * [FRM + offset] := PRI/ALT
	 */
	case OP_STOR_S_PRI:
	case OP_STOR_S_ALT:
		SELECT_REG(STOR_S);
		GET_PARAM(offs, psrc);
		STR_FRM(p, reg, offs);
		op_size = 2;
		break;

	/*
	 * Params: address
	 * Action: [[DAT + address]] := PRI/ALT
	 */
	case OP_SREF_PRI:
	case OP_SREF_ALT:
		SELECT_REG(SREF);
		GET_PARAM(offs, psrc);
		LDEA_BASE(p, REG_TMP, REG_DAT, offs);
		ARM_STR_IMM(p, reg, REG_TMP, 0);
		op_size = 2;
		break;

	/*
	 * Params: address
	 * Action: [[FRM + offset]] := PRI/ALT
	 */
	case OP_SREF_S_PRI:
	case OP_SREF_S_ALT:
		SELECT_REG(SREF_S);
		GET_PARAM(offs, psrc);
		LDEA_BASE(p, REG_TMP, REG_DAT, offs);
		ARM_STR_IMM(p, reg, REG_TMP, 0);
		op_size = 2;
		break;

	/*
	 * Params: <none>
	 * Action: [DATA + ALT] := PRI
	 */
	case OP_STOR_I:
		ARM_STR_REG_REG(p, REG_PRI, REG_DAT, REG_ALT);
		break;

	/*
	 * Params: cell(1 | 2 | 4)
	 * Action: [DAT + ALT] := $param bytes from PRI
	 */
	case OP_STRB_I:
		GET_PARAM(val, psrc);
		switch (val) {
		case 1:
			ARM_STRB_REG_REG(p, REG_PRI, REG_DAT, REG_ALT);
			break;
		case 2:
			ARM_STRH_REG_REG(p, REG_PRI, REG_DAT, REG_ALT);
			break;
		case 4:
			ARM_STR_REG_REG(p, REG_PRI, REG_DAT, REG_ALT);
			break;
		default:
			break;
		}
		op_size = 2;
		break;

	/*
	 * Params: <none>
	 * Action: PRI := [DAT + ALT + (PRI * sizeof(cell))]
	 */
	case OP_LIDX:
		ARM_ADD_REG_IMMSHIFT(p, REG_PRI, REG_ALT, REG_PRI, ARMSHIFT_LSL, 2);
		ARM_LDR_REG_REG(p, REG_PRI, REG_DAT, REG_PRI);
		break;

	/*
	 * Params: shift
	 * Action: PRI := [DAT + ALT + (PRI << shift)]
	 */
	case OP_LIDX_B:
		GET_PARAM(val, psrc);
		val &= 0x1F;
		ARM_ADD_REG_IMMSHIFT(p, REG_PRI, REG_ALT, REG_PRI, ARMSHIFT_LSL, val);
		ARM_LDR_REG_REG(p, REG_PRI, REG_DAT, REG_PRI);
		op_size = 2;
		break;

	/*
	 * Params: <none>
	 * Action: PRI := ALT + (PRI * sizeof(cell))
	 */
	case OP_IDXADDR:
		ARM_ADD_REG_IMMSHIFT(p, REG_PRI, REG_ALT, REG_PRI, ARMSHIFT_LSL, 2);
		break;

	/*
	 * Params: shift
	 * Action: PRI := ALT + (PRI << shift)
	 */
	case OP_IDXADDR_B:
		GET_PARAM(val, psrc);
		val &= 0x1F;
		ARM_ADD_REG_IMMSHIFT(p, REG_PRI, REG_ALT, REG_PRI, ARMSHIFT_LSL, val);
		op_size = 2;
		break;

	/*
	 * Params: number
	 * Action: PRI/ALT ^= sizeof(cell) - number
	 */
	case OP_ALIGN_PRI:
	case OP_ALIGN_ALT:
		GET_PARAM(val, psrc);
		SELECT_REG(ALIGN);
		p = arm_mov_reg_imm32(p, REG_TMP, sizeof(cell) - val);
		ARM_EOR_REG_REG(p, reg, reg, REG_TMP);
		op_size = 2;
		break;

	case OP_LCTRL:
		break;
	case OP_SCTRL:
		break;

	/*
	 * Params: <none>
	 * Action: PRI := ALT / ALT := PRI
	 */
	case OP_MOVE_PRI:
	case OP_MOVE_ALT:
		SELECT_REG(MOVE);
		ARM_MOV_REG_REG(p, reg, (reg == REG_PRI ? REG_ALT : REG_PRI));
		break;

	/*
	 * Params: <none>
	 * Action: swap PRI & ALT
	 */
	case OP_XCHG:
		ARM_MOV_REG_REG(p, REG_TMP, REG_PRI);
		ARM_MOV_REG_REG(p, REG_PRI, REG_ALT);
		ARM_MOV_REG_REG(p, REG_ALT, REG_TMP);
		break;

	/*
	 * Params: <none>
	 * Actions: [STK] := PRI/ALT, STK -= sizeof(cell)
	 */
	case OP_PUSH_PRI:
	case OP_PUSH_ALT:
		SELECT_REG(PUSH);
		PUSH_REG(p, reg);
		break;

	/*
	 * Params: value
	 * Action: rep %value time: PUSH(PRI)
	 */
	case OP_PUSH_R:
		GET_PARAM(val, psrc);
		if (val <= 8) {
			for (i = 0; (cell)i < val; i++) {
				PUSH_REG(p, REG_PRI);
			}
		} else {
			p = arm_mov_reg_imm32(p, REG_TMP, val);
			br = p;
			PUSH_REG(p, REG_PRI);
			ARM_SUBS_REG_IMM8(p, REG_TMP, REG_TMP, 1);
			ARM_B_COND(p, ARMCOND_NE, (char*)p + sizeof(arminstr_t) - (char*)br);
		}
		op_size = 2;
		break;

	/*
	 * Params: value
	 * Action: [STK] = value; STK -= sizeof(cell)
	 */
	case OP_PUSH_C:
		GET_PARAM(val, psrc);
		p = arm_mov_reg_imm32(p, REG_TMP, val);
		PUSH_REG(p, REG_TMP);
		op_size = 2;
		break;

	/*
	 * Params: offset
	 * Action: PUSH([DAT + offset])
	 */
	case OP_PUSH:
		GET_PARAM(offs, psrc);
		LDR_DAT(p, REG_TMP, offs);
		PUSH_REG(p, REG_TMP);
		op_size = 2;
		break;

	/*
	 * Params: offset
	 * Action: PUSH([FRM + offset])
	 */
	case OP_PUSH_S:
		GET_PARAM(offs, psrc);
		LDR_FRM(p, REG_TMP, offs);
		PUSH_REG(p, REG_TMP);
		op_size = 2;
		break;

	/*
	 * Params: <none>
	 * Action: POP(PRI/ALT)
	 */
	case OP_POP_PRI:
	case OP_POP_ALT:
		SELECT_REG(POP);
		POP_REG(p, reg);
		break;

	/*
	 * Params: value
	 * Action: ALT := STK; STK += value
	 */
	case OP_STACK:
		GET_PARAM(val, psrc);
		ARM_MOV_REG_REG(p, REG_ALT, REG_STK);
		p = arm_mov_reg_imm32(p, REG_TMP, val);
		ARM_ADD_REG_REG(p, REG_STK, REG_STK, REG_TMP);
		op_size = 2;
		break;

	case OP_HEAP:
		break;

	/*
	 * Params: <none>
	 * Action: PUSH(FRM); FRM := STK
	 */
	case OP_PROC:
		PUSH_REG(p, REG_FRM);
		ARM_MOV_REG_REG(p, REG_FRM, REG_STK);
		break;

	/*
	 * Params: <none>
	 * Action: POP(FRM); POP(CIP)
	 */
	case OP_RET:
		POP_REG(p, REG_FRM);
		// TODO: implement
		break;

	/*
	 * Params: <none>
	 * Action: POP(FRM); POP(CIP); STK += STK
	 */
	case OP_RETN:
		POP_REG(p, REG_FRM);
		POP_REG(p, REG_TMP); /* dummy CIP */
		POP_REG(p, REG_TMP);
		ARM_ADD_REG_REG(p, REG_STK, REG_STK, REG_TMP);
		ARM_MOV_REG_REG(p, ARMREG_PC, ARMREG_LR);
		break;

	/*
	 * Params: address
	 * Action: PUSH(CIP + 5); CIP := address
	 */
	case OP_CALL:
		GET_PARAM(addr, psrc);
		ARM_PUSH1(p, ARMREG_LR);
		PUSH_REG(p, ARMREG_PC); /* dummy */
		jit_ctx_add_reloc(ctx, (cell*)p, (cell*)addr);
		ARM_BL(p, 0);
		ARM_POP1(p, ARMREG_LR);
		break;

	case OP_CALL_PRI:
		break;

	/*
	 * Params: address
	 * Action: CIP := address
	 */
	case OP_JUMP:
		GET_PARAM(addr, psrc);
		jit_ctx_add_reloc(ctx, (cell*)p, (cell*)addr);
		ARM_B(p, 0);
		op_size = 2;
		break;

	case OP_JREL:
		break;

	/*
	 * Params: address
	 * Action: if (PRI == 0) CIP := address
	 */
	case OP_JZER:
		GET_PARAM(addr, psrc);
		CMP_IMM_BR_(ARMCOND_EQ, REG_PRI, 0, addr);
		op_size = 2;
		break;

	/*
	 * Params: address
	 * Action: if (PRI != 0) CIP := address
	 */
	case OP_JNZ:
		GET_PARAM(addr, psrc);
		CMP_IMM_BR_(ARMCOND_NE, REG_PRI, 0, addr);
		op_size = 2;
		break;

	/*
	 * Params: address
	 * Action: if (PRI == ALT) CIP := address
	 */
	case OP_JEQ:
		BR_(ARMCOND_EQ);
		break;

	/*
	 * Params: address
	 * Action: if (PRI != ALT) CIP := address
	 */
	case OP_JNEQ:
		BR_(ARMCOND_NE);
		break;

	/*
	 * Params: address
	 * Action: if (PRI < ALT) CIP := address (unsigned)
	 */
	case OP_JLESS:
		BR_(ARMCOND_LO);
		break;

	/*
	 * Params: address
	 * Action: if (PRI <= ALT) CIP := address (unsigned)
	 */
	case OP_JLEQ:
		BR_(ARMCOND_LS);
		break;

	/*
	 * Params: address
	 * Action: if (PRI > ALT) CIP := address (unsigned)
	 */
	case OP_JGRTR:
		BR_(ARMCOND_LO);
		break;

	/*
	 * Params: address
	 * Action: if (PRI >= ALT) CIP := address (unsigned)
	 */
	case OP_JGEQ:
		BR_(ARMCOND_HS);
		break;

	/*
	 * Params: address
	 * Action: if (PRI < ALT) CIP := address (signed)
	 */
	case OP_JSLESS:
		BR_(ARMCOND_LT);
		break;

	/*
	 * Params: address
	 * Action: if (PRI <= ALT) CIP := address (signed)
	 */
	case OP_JSLEQ:
		BR_(ARMCOND_LE);
		break;

	/*
	 * Params: address
	 * Action: if (PRI > ALT) CIP := [CIP + 1]; (signed)
	 */
	case OP_JSGRTR:
		BR_(ARMCOND_GT);
		break;

	/*
	 * Params: address
	 * Action: if (PRI >= ALT) CIP := [CIP + 1]; (signed)
	 */
	case OP_JSGEQ:
		BR_(ARMCOND_GE);
		break;

	/*
	 * Params: <none>
	 * Action: PRI <<= ALT
	 */
	case OP_SHL:
		ARM_SHL_REG(p, REG_PRI, REG_PRI, REG_ALT);
		break;

	/*
	 * Params: <none>
	 * Action: PRI >>= ALT (logical)
	 */
	case OP_SHR:
		ARM_SHR_REG(p, REG_PRI, REG_PRI, REG_ALT);
		break;

	/*
	 * Params: <none>
	 * Action: PRI >>= ALT (arithmetic, with sign extension)
	 */
	case OP_SSHR:
		ARM_SAR_REG(p, REG_PRI, REG_PRI, REG_ALT);
		break;

	/*
	 * Params: value
	 * Action: PRI/ALT <<= value
	 */
	case OP_SHL_C_PRI:
	case OP_SHL_C_ALT:
		SELECT_REG(SHL_C);
		GET_PARAM(val, psrc);
		ARM_SHL_IMM(p, reg, reg, val);
		op_size = 2;
		break;

	/*
	 * Params: value
	 * Action: PRI/ALT >>= value (logical)
	 */
	case OP_SHR_C_PRI:
	case OP_SHR_C_ALT:
		SELECT_REG(SHL_C);
		GET_PARAM(val, psrc);
		ARM_SHR_IMM(p, reg, reg, val);
		op_size = 2;
		break;

	case OP_SMUL:
		break;
	case OP_SDIV:
		break;
	case OP_SDIV_ALT:
		break;
	case OP_UMUL:
		break;
	case OP_UDIV:
		break;
	case OP_UDIV_ALT:
		break;

	/*
	 * Params: <none>
	 * Action: PRI += ALT
	 */
	case OP_ADD:
		ARM_ADD_REG_REG(p, REG_PRI, REG_PRI, REG_ALT);
		break;

	/*
	 * Params: <none>
	 * Action: PRI -= ALT
	 */
	case OP_SUB:
		ARM_SUB_REG_REG(p, REG_PRI, REG_PRI, REG_ALT);
		break;

	/*
	 * Params: <none>
	 * Action: PRI := ALT - PRI
	 */
	case OP_SUB_ALT:
		ARM_SUB_REG_REG(p, REG_PRI, REG_ALT, REG_PRI);
		break;

	/*
	 * Params: <none>
	 * Action: PRI &= ALT
	 */
	case OP_AND:
		ARM_AND_REG_REG(p, REG_PRI, REG_PRI, REG_ALT);
		break;

	/*
	 * Params: <none>
	 * Action: PRI |= ALT
	 */
	case OP_OR:
		ARM_ORR_REG_REG(p, REG_PRI, REG_PRI, REG_ALT);
		break;

	/*
	 * Params: <none>
	 * Action: PRI ^= ALT
	 */
	case OP_XOR:
		ARM_EOR_REG_REG(p, REG_PRI, REG_PRI, REG_ALT);
		break;

	/*
	 * Params: <none>
	 * Action: PRI := (PRI ? 0 : 1)
	 */
	case OP_NOT:
		ARM_CMP_REG_IMM8(p, REG_PRI, 0);
		p = arm_mov_reg_imm32_cond(p, REG_PRI, 0, ARMCOND_NE);
		p = arm_mov_reg_imm32_cond(p, REG_PRI, 1, ARMCOND_EQ);
		break;

	/*
	 * Params: <none>
	 * Action: PRI := -PRI
	 */
	case OP_NEG:
		ARM_RSB_REG_IMM8(p, REG_PRI, REG_PRI, 0);
		break;
	/*
	 * Params: <none>
	 * Action: PRI = ~PRI
	 */
	case OP_INVERT:
		ARM_MVN_REG_REG(p, REG_PRI, REG_PRI);
		break;

	case OP_ADD_C:
		break;
	case OP_SMUL_C:
		break;

	/*
	 * Params: <none>
	 * Action: PRI/ALT := 0
	 */
	case OP_ZERO_PRI:
	case OP_ZERO_ALT:
		SELECT_REG(ZERO);
		p = arm_mov_reg_imm32(p, reg, 0);
		break;

	case OP_ZERO:
		break;
	case OP_ZERO_S:
		break;
	case OP_SIGN_PRI:
		break;
	case OP_SIGN_ALT:
		break;
	case OP_EQ:
		break;
	case OP_NEQ:
		break;
	case OP_LESS:
		break;
	case OP_LEQ:
		break;
	case OP_GRTR:
		break;
	case OP_GEQ:
		break;
	case OP_SLESS:
		break;
	case OP_SLEQ:
		break;
	case OP_SGRTR:
		break;
	case OP_SGEQ:
		break;
	case OP_EQ_C_PRI:
		break;
	case OP_EQ_C_ALT:
		break;

	/*
	 * Params: <none>
	 * Action: PRI/ALT++
	 */
	case OP_INC_PRI:
	case OP_INC_ALT:
		SELECT_REG(INC);
		ARM_ADD_REG_IMM8(p, reg, reg, 1);
		break;

	case OP_INC:
		break;

	/*
	 * Params: offset
	 * Action: [FRM + offset]++
	 */
	case OP_INC_S:
		GET_PARAM(offs, psrc);
		LDR_FRM(p, REG_TMP, offs);
		ARM_ADD_REG_IMM8(p, REG_TMP, REG_TMP, 1);
		STR_FRM(p, REG_TMP, offs);
		break;

	case OP_INC_I:
		break;
	case OP_DEC_PRI:
		break;
	case OP_DEC_ALT:
		break;
	case OP_DEC:
		break;

	/*
	 * Params: offset
	 * Action: [FRM + offset]--
	 */
	case OP_DEC_S:
		GET_PARAM(offs, psrc);
		LDR_FRM(p, REG_TMP, offs);
		ARM_SUB_REG_IMM8(p, REG_TMP, REG_TMP, 1);
		STR_FRM(p, REG_TMP, offs);
		break;

	case OP_DEC_I:
		break;
	case OP_MOVS:
		break;
	case OP_CMPS:
		break;
	case OP_FILL:
		break;

	/*
	 * Params: 0 (params other than 0 have a special meaning)
	 * Action: abort execution (exit value in PRI)
	 */
	case OP_HALT:
		op_size = 2;
		break;

	case OP_BOUNDS:
		break;

	case OP_SYSREQ_PRI:
	case OP_SYSREQ_C:
		if (op == OP_SYSREQ_C) GET_PARAM(val, psrc);

		/*
		 *	typedef int (AMXAPI *AMX_CALLBACK)(
		 *		struct __amx* amx, cell index,
		 *		cell* result, cell* params);
		 */
		ARM_PUSH7(p, REG_PRI, REG_ALT, REG_AMX, REG_DAT, REG_FRM, REG_STK, ARMREG_LR);

		/* update AMX structure */
		ARM_SUB_REG_REG(p, REG_TMP, REG_FRM, REG_DAT);
		ARM_STR_IMM(p, REG_TMP, REG_AMX, JIT_STRUCT_OFFS(AMX, frm));

		ARM_SUB_REG_REG(p, REG_TMP, REG_STK, REG_DAT);
		ARM_STR_IMM(p, REG_TMP, REG_AMX, JIT_STRUCT_OFFS(AMX, stk));

		ARM_STR_IMM(p, REG_HEA, REG_AMX, JIT_STRUCT_OFFS(AMX, hea));

		/* prepare arguments */
		if (op == OP_SYSREQ_C) {
			p = arm_mov_reg_imm32(p, ARMREG_A2, val);
		} else {
			ARM_MOV_REG_REG(p, ARMREG_A2, REG_PRI);
		}
		ARM_MOV_REG_REG(p, ARMREG_A1, REG_AMX);
		ARM_MOV_REG_REG(p, ARMREG_A3, ARMREG_SP);
		if (REG_STK != ARMREG_A4) ARM_MOV_REG_REG(p, ARMREG_A4, REG_STK);

		ARM_LDR_IMM(p, REG_TMP, REG_AMX, JIT_STRUCT_OFFS(AMX, callback));
		ARM_MOV_REG_REG(p, ARMREG_LR, ARMREG_PC);
		ARM_MOV_REG_REG(p, ARMREG_PC, REG_TMP);

		ARM_POP7(p, REG_PRI, REG_ALT, REG_AMX, REG_DAT, REG_FRM, REG_STK, ARMREG_LR);

		if (op == OP_SYSREQ_C) op_size = 2;
		break;

	case OP_FILE:
		op_size = 4;
		break;

	case OP_LINE:
		op_size = 3;
		break;

	case OP_SYMBOL:
		op_size = 5;
		break;

	case OP_SRANGE:
		op_size = 3;
		break;

	case OP_JUMP_PRI:
		break;
	case OP_SWITCH:
		break;
	case OP_CASETBL:
		break;
	case OP_SWAP_PRI:
		break;
	case OP_SWAP_ALT:
		break;

	/*
	 * Params: offset
	 * Action: PUSH(FRM + offset)
	 */
	case OP_PUSHADDR:
		GET_PARAM(offs, psrc);
		ARM_SUB_REG_REG(p, REG_TMP, REG_FRM, REG_DAT);
		LDEA_BASE(p, REG_TMP, REG_TMP, offs);
		PUSH_REG(p, REG_TMP);
		op_size = 2;
		break;

	case OP_NOP:
		break;

	default:
		break;
	}

	ctx->bytecode.ptr += op_size;
	ctx->native.ptr = (cell*)p;
}
