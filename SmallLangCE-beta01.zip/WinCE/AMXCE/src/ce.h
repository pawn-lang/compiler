/*
 * Copyright (c) 2002 Wild West Software
 */

#ifndef __CE_H__
#define __CE_H__

#include <stdlib.h> /* for time_t, FILE etc. */

#ifdef  __cplusplus
extern "C" {
#endif

/*
 * time.h
 */

#define CLOCKS_PER_SEC  1000
#define CLK_TCK  CLOCKS_PER_SEC

typedef long clock_t;

struct tm {
	int tm_sec;     /* seconds after the minute - [0,59] */
	int tm_min;     /* minutes after the hour - [0,59] */
	int tm_hour;    /* hours since midnight - [0,23] */
	int tm_mday;    /* day of the month - [1,31] */
	int tm_mon;     /* months since January - [0,11] */
	int tm_year;    /* years since 1900 */
	int tm_wday;    /* days since Sunday - [0,6] */
	int tm_yday;    /* days since January 1 - [0,365] */
	int tm_isdst;   /* daylight savings time flag */
};

time_t time(time_t*);
struct tm* localtime(const time_t*);
clock_t clock(void);



/*
 * ctype.h
 */
#if defined(UNDER_CE) && (UNDER_CE < 300)
int isdigit(int);
#endif


/*
 * stdlib.h
 */
double atof(const char* string);


/*
 * stdio.h
 */
void rewind(FILE* stream);


/*
 * string.h
 */
char* strdup(const char* strSource);
char* strrchr(const char* string, int c);
int stricmp( const char* string1, const char* string2);


/*
 * signal.h
 */
#define SIGINT 2
void (* signal(int, void (*)(int)))(int);

#ifdef  __cplusplus
}
#endif

#endif /* __CE_H__ */
