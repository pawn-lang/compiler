#if !defined(AFX_GREPINPUT_H__C0A82AA3_53B8_11D2_A779_00C0A80034F0__INCLUDED_)
#define AFX_GREPINPUT_H__C0A82AA3_53B8_11D2_A779_00C0A80034F0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// GrepInput.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// GrepInput dialog

class GrepInput : public CDialog
{
// Construction
public:
	GrepInput(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(GrepInput)
	enum { IDD = IDD_GREPINPUT };
	CString	m_strGrepInput;
	BOOL	m_bMatchCase;
	BOOL	m_bMatchWord;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(GrepInput)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(GrepInput)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GREPINPUT_H__C0A82AA3_53B8_11D2_A779_00C0A80034F0__INCLUDED_)
