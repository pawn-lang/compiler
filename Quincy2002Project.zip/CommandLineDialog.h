// CommandLineDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCommandLineDialog dialog

class CCommandLineDialog : public CDialog
{
// Construction
public:
	CCommandLineDialog(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCommandLineDialog)
	enum { IDD = IDD_COMMANDLINE };
	CString	m_strCommandLine;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCommandLineDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCommandLineDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
