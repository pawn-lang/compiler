
#if defined __cplusplus
extern "C"
#endif
BOOL CheckFontInstall(LPSTR lpFontname, LPSTR lpFilename);
