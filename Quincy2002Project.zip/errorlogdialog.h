// ErrorLogDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CErrorLogDialog dialog

class CErrorLogDialog : public CDialog
{
// Construction
public:
	CErrorLogDialog(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CErrorLogDialog)
	enum { IDD = IDD_ERRORLOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CErrorLogDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CErrorLogDialog)
	afx_msg void OnDblclkErrorlist();
	virtual void OnOK();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CFont fntMono;
};
