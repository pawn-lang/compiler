// GrepResult.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "GrepResult.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GrepResult dialog


GrepResult::GrepResult(CWnd* pParent)
	: CDialog(GrepResult::IDD, pParent)
{
	//{{AFX_DATA_INIT(GrepResult)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void GrepResult::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GrepResult)
	DDX_Control(pDX, IDC_GREPLIST, m_ResultList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(GrepResult, CDialog)
	//{{AFX_MSG_MAP(GrepResult)
	ON_LBN_DBLCLK(IDC_GREPLIST, OnDblclkGreplist)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GrepResult message handlers

void GrepResult::OnDblclkGreplist() 
{
	OnOK();
}

void GrepResult::OnOK() 
{
	// -- get the current selection and send to CQuincyApp object
	CListBox* pList = static_cast<CListBox*>(GetDlgItem(IDC_GREPLIST));
	ASSERT(pList != 0);
	theApp.SelectGrepLine(pList->GetCurSel());
}

int GrepResult::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	theApp.RestoreDialogWindowPosition("GrepLog", this);
	return 0;
}

void GrepResult::OnDestroy() 
{
	theApp.SaveDialogWindowPosition("GrepLog", this);
	CDialog::OnDestroy();
}
