// QuincyDoc.h : interface of the CQuincyDoc class
//
/////////////////////////////////////////////////////////////////////////////

class CQuincyDoc : public CDocument
{
	static CQuincyDoc* m_pOpenDocument;
	int m_nProjectType;
	CString m_strTarget;
	CString m_strWorking;
	CString m_strPath;
protected: // create from serialization only
	CQuincyDoc();
	DECLARE_DYNCREATE(CQuincyDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQuincyDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void SetTitle(LPCTSTR lpszTitle);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CQuincyDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	bool IsConsoleApplication() const
		{ return m_nProjectType == 0; }
	bool IsLibraryTarget() const
		{ return m_nProjectType == 1; }
	bool IsGUITarget() const
		{ return m_nProjectType == 2; }
	bool IsDLLTarget() const
		{ return m_nProjectType == 3; }
	const CString& TargetName() const
		{ return m_strTarget; }
	const CString& ProjectPath() const
		{ return m_strPath; }
	const CString& WorkingDirectory() const
		{ return m_strWorking; }
	static CQuincyDoc* CurrentProject()
		{ return m_pOpenDocument; }
	void DoOnProperties()
		{ OnProperties(); }
protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CQuincyDoc)
	afx_msg void OnUpdateTrue(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFalse(CCmdUI* pCmdUI);
	afx_msg void OnProperties();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
