// GeneralOptions.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "GeneralOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptions dialog


CGeneralOptions::CGeneralOptions(CWnd* pParent)
	: CPropertyPage(CGeneralOptions::IDD)
{
	//{{AFX_DATA_INIT(CGeneralOptions)
	m_CheckForUpdates = FALSE;
	//}}AFX_DATA_INIT
}


void CGeneralOptions::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneralOptions)
	DDX_Check(pDX, IDC_CHECKFORUPDATES, m_CheckForUpdates);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGeneralOptions, CPropertyPage)
	//{{AFX_MSG_MAP(CGeneralOptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptions message handlers

