// BuildDialog.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "OptionsSheet.h"
#include "BuildDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBuildDialog dialog


CBuildDialog::CBuildDialog(CWnd* pParent)
	: CPropertyPage(CBuildDialog::IDD)
{
	//{{AFX_DATA_INIT(CBuildDialog)
	m_strDefine = _T("");
	m_strInclude = _T("");
	m_strCmdLineOptions = _T("");
	m_Report = FALSE;
	m_Verbose = FALSE;
	m_strTargetPath = _T("");
	m_FixedName = BST_INDETERMINATE;
	//}}AFX_DATA_INIT
	m_nOptimize = 0;
}


void CBuildDialog::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBuildDialog)
	DDX_Check(pDX, IDC_DEBUG, m_bDebugging);
	DDX_Text(pDX, IDC_DEFINE, m_strDefine);
	DDX_Text(pDX, IDC_INCLUDE, m_strInclude);
	DDX_Text(pDX, IDC_EDIT1, m_strCompiler);
	DDX_Text(pDX, IDC_CMDLINEOPTIONS, m_strCmdLineOptions);
	DDX_Check(pDX, IDC_REPORT, m_Report);
	DDX_Check(pDX, IDC_VERBOSE, m_Verbose);
	DDX_Text(pDX, IDC_TARGETPATH, m_strTargetPath);
	DDX_Check(pDX, IDC_FIXEDNAME, m_FixedName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBuildDialog, CPropertyPage)
	//{{AFX_MSG_MAP(CBuildDialog)
	ON_BN_CLICKED(IDC_DEBUG, OnDebug)
	ON_BN_CLICKED(IDC_BROWSEINCLUDES, OnBrowseincludes)
	ON_BN_CLICKED(IDC_BROWSECOMPILER, OnBrowsecompiler)
	ON_BN_CLICKED(IDC_BROWSETARGET, OnBrowsetarget)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBuildDialog message handlers
BOOL CBuildDialog::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	UpdateData();
	return true;
}

void CBuildDialog::OnDebug() 
{
//	if (m_bDebugging) {
//		m_Verbose.Check();
//		m_Verbose.EnableWindow(false);
//	} else {
//		m_Verbose.EnableWindow();
//	} /* if */
	UpdateData();
}

void CBuildDialog::OnOK() 
{
	UpdateData();
	CPropertyPage::OnOK();
}

BOOL CBuildDialog::OnSetActive() 
{
	static_cast<COptionsSheet*>(GetParent())->RegisterActiveIndex();
	return CPropertyPage::OnSetActive();
}


void CBuildDialog::OnBrowseincludes() 
{
	CString includes;
	if (theApp.SelectFolder("#include directory", &includes))	{
		if (!m_strInclude.IsEmpty())
			m_strInclude += ';';
		m_strInclude += includes;
		UpdateData(0);
	}
}

void CBuildDialog::OnBrowsecompiler() 
{
	if (theApp.SelectFolder("Compiler", &m_strCompiler))
		UpdateData(0);
}

void CBuildDialog::OnBrowsetarget() 
{
	CString target;
	if (theApp.SelectFolder("Output directory", &target))	{
		m_strTargetPath = target;
		UpdateData(0);
	}
}
