#if !defined(AFX_LINKDIALOG_H__E401F280_766E_11D4_8400_808948C13107__INCLUDED_)
#define AFX_LINKDIALOG_H__E401F280_766E_11D4_8400_808948C13107__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// LinkDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLinkDialog dialog

class CLinkDialog : public CPropertyPage
{
	DECLARE_DYNCREATE(CLinkDialog)
// Construction
public:
	CLinkDialog();
	~CLinkDialog();

// Dialog Data
	//{{AFX_DATA(CLinkDialog)
	enum { IDD = IDD_LINK_PROPERTIES };
	CString	m_strLib;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CLinkDialog)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CLinkDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LINKDIALOG_H__E401F280_766E_11D4_8400_808948C13107__INCLUDED_)
