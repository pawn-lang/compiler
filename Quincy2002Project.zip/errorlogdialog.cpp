// ErrorLogDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Quincy.h"
#include "ErrorLogDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CErrorLogDialog dialog


CErrorLogDialog::CErrorLogDialog(CWnd* pParent)
	: CDialog(CErrorLogDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CErrorLogDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	fntMono.CreateFont(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, 
						ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
						DEFAULT_QUALITY, FIXED_PITCH | FF_DONTCARE, "Andante");
}


void CErrorLogDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CErrorLogDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

	CListBox* pList = static_cast<CListBox*>(GetDlgItem(IDC_ERRORLIST));
	ASSERT(pList != 0);
	pList->SetFont(&fntMono);
}


BEGIN_MESSAGE_MAP(CErrorLogDialog, CDialog)
	//{{AFX_MSG_MAP(CErrorLogDialog)
	ON_LBN_DBLCLK(IDC_ERRORLIST, OnDblclkErrorlist)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CErrorLogDialog message handlers

void CErrorLogDialog::OnDblclkErrorlist() 
{
	OnOK();
}

void CErrorLogDialog::OnOK() 
{
	// -- get the current selection and send to CQuincyApp object
	CListBox* pList = static_cast<CListBox*>(GetDlgItem(IDC_ERRORLIST));
	ASSERT(pList != 0);
	theApp.SelectErrorLine(pList->GetCurSel());
}

int CErrorLogDialog::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	theApp.RestoreDialogWindowPosition("ErrorLog", this);
	return 0;
}

void CErrorLogDialog::OnDestroy() 
{
	theApp.SaveDialogWindowPosition("ErrorLog", this);
	CDialog::OnDestroy();
}

