// SampleCode.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "SampleCode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSampleCode

CSampleCode::CSampleCode()
{
	m_tabstops = 4;
	m_syntaxcolor = true;
	m_fontheight = 16;
	m_fontweight = FW_NORMAL;
	_tcscpy(m_fontname, "Andante");
}

CSampleCode::~CSampleCode()
{
}

BEGIN_MESSAGE_MAP(CSampleCode, CEdit)
	//{{AFX_MSG_MAP(CSampleCode)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSampleCode message handlers

const char* code[] = {
	"\\c// --- sample.p",
	"\\k#include \\n<core>",
	"\\nmain()",
	"{",
	"\t\\c/* Say hello */",
	"\t\\nprint \\s\"Hello...\"",
	"\t\\kreturn\\n 0",
	"}"
};

bool CSampleCode::testfont(int ht)
{
	CFont* font = new CFont;
	DWORD size = theApp.EditorScreenFont(font, m_fontname, ht, m_fontweight);
	delete font;
	return ht != HIWORD(size);
}

static const int maxheight = 40;
static const int minheight = 12;
static const int fontincr = 1;

void CSampleCode::AdjustFont(int adj)
{
	if (m_fontheight < maxheight-adj && m_fontheight > minheight-adj)	{
		do	{
			m_fontheight += adj;
			if (m_fontheight >= maxheight || m_fontheight <= minheight)
				break;
		} while (testfont(m_fontheight));
	}
	Invalidate();
}

void CSampleCode::IncreaseFont()
{
	AdjustFont(fontincr);
}

void CSampleCode::DecreaseFont()
{
	AdjustFont(-fontincr);
}

void CSampleCode::DefaultFont()
{
	m_fontheight = 16;
	m_fontweight = FW_NORMAL;
	_tcscpy(m_fontname, "Andante");
	Invalidate();
}

void CSampleCode::ChangeFont(LPCTSTR name, int height, int weight)
{
	m_fontheight = height;
	m_fontweight = weight;
	_tcscpy(m_fontname, name);
	Invalidate();
}

void CSampleCode::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	CFont* font = new CFont;
	DWORD size = theApp.EditorScreenFont(font, m_fontname, m_fontheight, m_fontweight);
	int ht = HIWORD(size);
	int wd = LOWORD(size);
	CFont* pOldFont = dc.SelectObject(font);
	COLORREF backgroundcolor = m_syntaxcolor ? m_backgroundcolor : RGB(255,255,255);
	COLORREF normalcolor = m_syntaxcolor ? m_normalcolor : RGB(0,0,0);
	dc.SetBkColor(backgroundcolor);
	dc.SetTextColor(normalcolor);
	CRect rc;
	GetClientRect(&rc);
	CBrush br(backgroundcolor);
	dc.FillRect(&rc, &br);

	for (int i = 0; i < sizeof code / sizeof(const char*); i++)	{
		int x = 0;
		const char* cp;
		for (cp = code[i]; *cp; cp++)	{
			char ch[] = " ";
			if (*cp == '\\')	{
				cp++;
				if (m_syntaxcolor)	{
					COLORREF clr;
					switch (*cp)	{
						case 'n':
							clr = m_normalcolor;
							break;
						case 's':
							clr = m_stringcolor;
							break;
						case 'k':
							clr = m_keywordcolor;
							break;
						case 'c':
							clr = m_commentcolor;
							break;
						default:
							break;
					}
					dc.SetTextColor(clr);
				}
				if (*cp != '\\')
					continue;
			}
			if (*cp == '\t')
				for (; x < m_tabstops; x++)
					dc.ExtTextOut(x * wd, i * ht, ETO_CLIPPED, &rc, ch, 1, 0);
			else	{
				*ch = *cp;
				int col = (x++) * wd;
				if (col + wd < rc.right)
					dc.ExtTextOut(col, i * ht, ETO_CLIPPED, &rc, ch, 1, 0);
			}
		}
	}
	dc.SelectObject(pOldFont);
	delete font;
}
