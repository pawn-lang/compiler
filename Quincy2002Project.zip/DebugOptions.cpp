// DebugOptions.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "OptionsSheet.h"
#include "DebugOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDebugOptions property page

CDebugOptions::CDebugOptions(CWnd* pParent)
	: CPropertyPage(CDebugOptions::IDD)
{
	//{{AFX_DATA_INIT(CDebugOptions)
	m_AutoTransfer = FALSE;
	m_DebugBaudrate = 0;
	m_DebugPort = 0;
	m_Local = 0;
	//}}AFX_DATA_INIT
}


void CDebugOptions::DoDataExchange(CDataExchange* pDX)
{
	GetDlgItem(IDC_DBG_BAUD)->EnableWindow((m_Local == 1));
	GetDlgItem(IDC_DBG_PORTNUM)->EnableWindow((m_Local == 1));

	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDebugOptions)
	DDX_Check(pDX, IDC_AUTOTRANSFER, m_AutoTransfer);
	DDX_CBIndex(pDX, IDC_DBG_BAUD, m_DebugBaudrate);
	DDX_CBIndex(pDX, IDC_DBG_PORTNUM, m_DebugPort);
	DDX_Radio(pDX, IDC_DBG_LOCAL, m_Local);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDebugOptions, CPropertyPage)
	//{{AFX_MSG_MAP(CDebugOptions)
	ON_BN_CLICKED(IDC_DBG_LOCAL, OnDbgLocal)
	ON_BN_CLICKED(IDC_DBG_SERIAL, OnDbgSerial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDebugOptions message handlers

BOOL CDebugOptions::OnSetActive() 
{
	static_cast<COptionsSheet*>(GetParent())->RegisterActiveIndex();
	return CPropertyPage::OnSetActive();
}

void CDebugOptions::OnDbgLocal() 
{
	m_DebugPort = -1;
	GetDlgItem(IDC_DBG_BAUD)->EnableWindow(FALSE);
	GetDlgItem(IDC_DBG_PORTNUM)->EnableWindow(FALSE);
}

void CDebugOptions::OnDbgSerial() 
{
	m_DebugPort = -1;	
	GetDlgItem(IDC_DBG_BAUD)->EnableWindow(TRUE);
	GetDlgItem(IDC_DBG_PORTNUM)->EnableWindow(TRUE);
}
