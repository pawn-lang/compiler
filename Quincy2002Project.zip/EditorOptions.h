#if !defined(AFX_EDITOROPTIONS_H__F6309F61_72D1_11D4_A77C_00207815827F__INCLUDED_)
#define AFX_EDITOROPTIONS_H__F6309F61_72D1_11D4_A77C_00207815827F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// EditorOptions.h : header file
//

#include "ColorBox.h"
#include "SampleCode.h"

/////////////////////////////////////////////////////////////////////////////
// CEditorOptions dialog

class CEditorOptions : public CPropertyPage
{
	DECLARE_DYNCREATE(CEditorOptions)

	void GetColor(CColorBox& wnd, CPoint point, COLORREF& cr);
	void UpdateColors();
	void DefaultColors();
// Construction
public:
	int m_nTabstops;
	int m_nMaxundos;
	COLORREF m_backgroundcolor;
	COLORREF m_normalcolor;
	COLORREF m_keywordcolor;
	COLORREF m_commentcolor;
	COLORREF m_stringcolor;

	CEditorOptions();
	~CEditorOptions();

// Dialog Data
	//{{AFX_DATA(CEditorOptions)
	enum { IDD = IDD_EDITOR_PROPERTIES };
	CSpinButtonCtrl	m_MaxUndosSpin;
	CSampleCode	m_SampleCode;
	CColorBox	m_Background;
	CColorBox	m_Normal;
	CColorBox	m_String;
	CColorBox	m_Keyword;
	CColorBox	m_Comment;
	CSpinButtonCtrl	m_TabstopsSpin;
	CEdit	m_Tabstops;
	BOOL	m_AutoIndent;
	BOOL	m_SyntaxColors;
	CString	m_MaxUndos;
	BOOL	m_bold;
	int		m_taboption;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CEditorOptions)
	public:
	virtual void OnOK();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CEditorOptions)
	virtual BOOL OnInitDialog();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnDefaults();
	afx_msg void OnSpin(NMHDR *pNotifyStruct, LRESULT* result);
	afx_msg void OnSyntaxcolors();
	afx_msg void OnFontplus();
	afx_msg void OnFontminus();
	afx_msg void OnBold();
	afx_msg void OnEditorfont();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITOROPTIONS_H__F6309F61_72D1_11D4_A77C_00207815827F__INCLUDED_)
