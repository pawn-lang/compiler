// ProjectDlg.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "ProjectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ProjectDlg dialog


ProjectDlg::ProjectDlg(CWnd* pParent)
	: CDialog(ProjectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(ProjectDlg)
	m_nProjectType = -1;
	m_strTarget = _T("");
	m_strWorking = _T("");
	m_strPath = _T("");
	//}}AFX_DATA_INIT
}


void ProjectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ProjectDlg)
	DDX_Control(pDX, IDC_BROWSEPROJECT, m_browseproject);
	DDX_Control(pDX, IDC_TARGET, m_target);
	DDX_Control(pDX, IDC_PROJPATH, m_projectpath);
	DDX_Radio(pDX, IDC_CONSOLE, m_nProjectType);
	DDX_Text(pDX, IDC_TARGET, m_strTarget);
	DDX_Text(pDX, IDC_WORKING, m_strWorking);
	DDX_Text(pDX, IDC_PROJPATH, m_strPath);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ProjectDlg, CDialog)
	//{{AFX_MSG_MAP(ProjectDlg)
	ON_BN_CLICKED(IDC_BROWSEWORKING, OnBrowseworking)
	ON_BN_CLICKED(IDC_BROWSEPROJECT, OnBrowseproject)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ProjectDlg message handlers

BOOL ProjectDlg::OnInitDialog() 
{
	CString strPath;
	strPath = theApp.GetProfileString("Pawn", "Outfile");
	if (strPath.GetLength() > 0)
		m_strTarget = strPath;

	CDialog::OnInitDialog();

	if (!strPath.IsEmpty())
		m_target.EnableWindow(false);

	if (!m_strPath.IsEmpty())	{
		m_projectpath.EnableWindow(false);
		m_browseproject.EnableWindow(false);
	}
	return TRUE;
}


void ProjectDlg::OnOK() 
{
	UpdateData();
	if (m_strTarget.IsEmpty())	{
		AfxMessageBox("Target name required", MB_ICONSTOP);
		m_target.SetFocus();
	}
	else if (m_strPath.IsEmpty())	{
		AfxMessageBox("Target path required", MB_ICONSTOP);
		m_projectpath.SetFocus();
	}
	else
		CDialog::OnOK();
}

void ProjectDlg::OnBrowseworking() 
{
	UpdateData();
	if (theApp.SelectFolder("Working Directory", &m_strWorking))
		UpdateData(0);	
}

void ProjectDlg::OnBrowseproject() 
{
	UpdateData();
	if (theApp.SelectFolder("Target Path", &m_strPath))
		UpdateData(0);	
}
