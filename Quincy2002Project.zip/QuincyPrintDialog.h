#if !defined(AFX_QUINCYPRINTDIALOG_H__64D73F03_7B38_11D4_B7A3_00207815827F__INCLUDED_)
#define AFX_QUINCYPRINTDIALOG_H__64D73F03_7B38_11D4_B7A3_00207815827F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// QuincyPrintDialog.h

////////////////////////////
// CLineNumberButton class

class CLineNumberButton : public CButton
{
	DECLARE_DYNAMIC(CLineNumberButton)
	CFont font;
public:
	CLineNumberButton();
protected:
	//{{AFX_MSG(CLineNumberButton)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CQuincyPrintDialog dialog

class CQuincyPrintDialog : public CPrintDialog
{
	DECLARE_DYNAMIC(CQuincyPrintDialog)
	CLineNumberButton lnobutton;	// print line number checkbox
	static LOGFONT logfont;
public:
	bool printlinenumbers;	// publicly exposed for setting and testing
	CQuincyPrintDialog(bool bSetup = false);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CQuincyPrintDialog)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QUINCYPRINTDIALOG_H__64D73F03_7B38_11D4_B7A3_00207815827F__INCLUDED_)
