#include <windows.h>

#pragma argsused
int CALLBACK _export EnumFontFamProc(LOGFONT FAR *lpfont,
                                     NEWTEXTMETRIC FAR *txtmetric,
                                     int fonttype, LPARAM lpInfo)
{
  // return 0 to stop search (font name was found)
  return lstrcmpi((LPSTR)lpInfo,lpfont->lfFaceName) != 0;
}

BOOL CheckFontInstall(LPSTR lpFontname, LPSTR lpFilename)
{
  int result;
  FONTENUMPROC lpfnEnum;
  HDC hdc;

  lpfnEnum = MakeProcInstance((FARPROC)EnumFontFamProc, hInst);
  hdc = GetDC(0);
  result = EnumFontFamilies(hdc, NULL, lpfnEnum, (LPARAM)lpFontname);
  ReleaseDC(0, hdc);

  if (result != 0) {
    if (lpFilename!=NULL && AddFontResource(lpFilename)) {
      SendMessage(HWND_BROADCAST, WM_FONTCHANGE, 0, 0L);
      return TRUE;                      // font now installed
    } else {
      return FALSE;                     // could not install font
    } /* if */
  } else {
    return TRUE;                        // font already installed
  } /* if */
}

