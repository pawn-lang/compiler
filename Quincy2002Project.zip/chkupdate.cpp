#define STRICT
#include <windows.h>
#include <msxml.h>
#include <stdio.h>
#include <time.h>
#include "tinyxml/tinyxml.h"
#include "tinyxml/xpath_processor.h"

#define SEC_MINUTE	60					/* 60 seconds in a minute */
#define SEC_HOUR	(60*SEC_MINUTE)
#define SEC_DAY		(24*SEC_HOUR)
#define SEC_WEEK	(7*SEC_DAY)

#if !defined sizearray
	#define sizearray(s)	(sizeof(s) / sizeof(s)[0])
#endif

static char AppUrl[_MAX_PATH];

extern "C"
BOOL CheckUpdate(LPCSTR CurVersion, LPCSTR Topic, LPCSTR KeyURL, LPCSTR KeyStamp, LPCSTR Profile)
{
	typedef HRESULT (WINAPI *fpURLDownloadToFile)(LPUNKNOWN pCaller, LPCTSTR szURL, LPCTSTR szFileName, DWORD dwReserved, LPBINDSTATUSCALLBACK lpfnCB);
	HINSTANCE hinst;
	fpURLDownloadToFile URLDownloadToFile;
	HRESULT hres;
	unsigned long curstamp, laststamp;
	char str[512], tempfile[_MAX_PATH];
	char lastver[40];

	/* check the timestamp */
	laststamp = GetPrivateProfileInt(Topic, KeyStamp, 0, Profile);
	curstamp = time(NULL);
	if (curstamp - laststamp < SEC_WEEK)
		return FALSE;	/* no need to check now */

	/* download the file */
	GetTempPath(sizearray(str), str);
	GetTempFileName(str, "UPD", 0, tempfile);
	GetPrivateProfileString(Topic, KeyURL, "", str, sizearray(str), Profile);
	if (strlen(str) == 0)
		return FALSE;	/* there is no update URL */

	hinst = LoadLibrary("urlmon.dll");
	if (hinst == NULL)
		return FALSE;
	URLDownloadToFile = (fpURLDownloadToFile)GetProcAddress(hinst, "URLDownloadToFileA");
	if (URLDownloadToFile == NULL) {
		FreeLibrary(hinst);
		return FALSE;
	} /* if */
	hres = URLDownloadToFile(NULL, str, tempfile, 0, NULL);
	FreeLibrary(hinst);
	if (FAILED(hres))
		return FALSE;	/* failed to download the requested file */

	/* now we have the file, parse through it (using XPath) */
	lastver[0] = '\0';
	TiXmlDocument doc(tempfile);
	if (doc.LoadFile()) {
		TinyXPath::xpath_processor xpver(doc.RootElement(), "/XML_DIZ_INFO/Program_Info/Program_Version/text()");
		TiXmlString xstring = xpver.S_compute_xpath();
		strcpy(lastver, xstring.c_str());
		/* also store the current download path in the INI file */
		TinyXPath::xpath_processor xpurl(doc.RootElement(), "/XML_DIZ_INFO/Web_Info/Application_URLs/Application_Info_URL/text()");
		xstring = xpurl.S_compute_xpath();
		strcpy(AppUrl, xstring.c_str());
	} /* if */

	/* temporary file no longer needed */
	remove(tempfile);

	/* update "last checked" timestamp */
	sprintf(str, "%ld", curstamp);
	WritePrivateProfileString(Topic, KeyStamp, str, Profile);

	/* compare version string with the one in the profile */
	/* if no key is set in the profile, add it (so assume that the user runs the latest version */
	if (strlen(CurVersion) == 0 || strcmp(CurVersion, lastver) == 0)
		return FALSE;

	/* pop up a message box with the notification of the update */
	sprintf(str, "An update is available on %s\n\n"
		         "        Your version: %s\n"
				 "        New version: %s\n\n"
				 "Do you wish to update now?", AppUrl, CurVersion, lastver);
	if (::MessageBox(NULL, str, "Update available", MB_ICONINFORMATION|MB_YESNO) == IDYES)
		ShellExecute(0, "open", AppUrl, 0, 0, SW_SHOW);

	/* the last version is not written back to the INI file; instead, the installer should do this */

	return TRUE;
}
