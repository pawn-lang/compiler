// TextDocument.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTextDocument document

#include "EditorDoc.h"

class CTextDocument : public CEditorDoc
{
protected:
	CTextDocument();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CTextDocument)

// Attributes
public:

// Operations
public:
	bool IsSourceFile();
	bool IsExecutableSourceFile();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTextDocument)
	public:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTextDocument();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CTextDocument)
	afx_msg void OnUpdateFilePrint(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDeleteFile(CCmdUI* pCmdUI);
	afx_msg void OnUpdateInsertFile(CCmdUI* pCmdUI);
	afx_msg void OnUpdateExecute(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDebugBreakpoint(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDebugWatch(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDebugStep(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDebugStepover(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDebugSteptocursor(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDebugStepoutoffunction(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDebugTransfer(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
