// LinkDialog.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "OptionsSheet.h"
#include "LinkDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLinkDialog property page

IMPLEMENT_DYNCREATE(CLinkDialog, CPropertyPage)

CLinkDialog::CLinkDialog() : CPropertyPage(CLinkDialog::IDD)
{
	//{{AFX_DATA_INIT(CLinkDialog)
	m_strLib = _T("");
	//}}AFX_DATA_INIT
}

CLinkDialog::~CLinkDialog()
{
}

void CLinkDialog::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLinkDialog)
	DDX_Text(pDX, IDC_LIB, m_strLib);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLinkDialog, CPropertyPage)
	//{{AFX_MSG_MAP(CLinkDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLinkDialog message handlers


BOOL CLinkDialog::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	
	return true;
}

BOOL CLinkDialog::OnSetActive() 
{
	static_cast<COptionsSheet*>(GetParent())->RegisterActiveIndex();
	return CPropertyPage::OnSetActive();
}
