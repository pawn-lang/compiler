#if !defined(AFX_BUILDDIALOG_H__8BD5EC81_72CA_11D4_A77C_00207815827F__INCLUDED_)
#define AFX_BUILDDIALOG_H__8BD5EC81_72CA_11D4_A77C_00207815827F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// BuildDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBuildDialog dialog

class CBuildDialog : public CPropertyPage
{
// Construction
public:
	int m_nOptimize;

	CBuildDialog(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBuildDialog)
	enum { IDD = IDD_BUILD_PROPERTIES };
	BOOL	m_bDebugging;
	CString	m_strDefine;
	CString	m_strInclude;
	CString	m_strCompiler;
	CString	m_strCmdLineOptions;
	BOOL	m_Report;
	BOOL	m_Verbose;
	CString	m_strTargetPath;
	BOOL	m_FixedName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBuildDialog)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBuildDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnDebug();
	virtual void OnOK();
	afx_msg void OnBrowseincludes();
	afx_msg void OnBrowsecompiler();
	afx_msg void OnVerbose();
	afx_msg void OnReport();
	afx_msg void OnBrowsetarget();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BUILDDIALOG_H__8BD5EC81_72CA_11D4_A77C_00207815827F__INCLUDED_)
