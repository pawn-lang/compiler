// AddWatch.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddWatch dialog

class CAddWatch : public CDialog
{
// Construction
public:
	CAddWatch(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddWatch)
	enum { IDD = IDD_ADDWATCH };
	CString	m_strWatchVariable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddWatch)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddWatch)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
