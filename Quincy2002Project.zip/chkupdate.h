#ifndef CHKUPDATE_H
#define CHKUPDATE_H

#if defined __cplusplus
  extern "C" {
#endif

BOOL CheckUpdate(LPCSTR Topic, LPCSTR key, LPCSTR KeyVersion, LPCSTR KeyStamp, LPCSTR Profile);

#if defined __cplusplus
  }
#endif

#endif /* CHKUPDATE_H */
