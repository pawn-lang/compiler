// ExamineDialog.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "ExamineDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExamineDialog dialog


CExamineDialog::CExamineDialog(CWnd* pParent)
	: CDialog(CExamineDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExamineDialog)
	m_strExpression = _T("");
	m_strNewValue = _T("");
	//}}AFX_DATA_INIT
}


void CExamineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExamineDialog)
	DDX_Text(pDX, IDC_EXAMINE_VARIABLE, m_strExpression);
	DDX_Text(pDX, IDC_EXAMINE_NEWVALUE, m_strNewValue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExamineDialog, CDialog)
	//{{AFX_MSG_MAP(CExamineDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExamineDialog message handlers

void CExamineDialog::OnOK() 
{
	UpdateData(true);
	if (m_strExpression.IsEmpty())
		CDialog::OnOK();
	else	{
		CString strVarValue;
		// ---- if any change, update the variable
		if (!m_strNewValue.IsEmpty())
			theApp.SetVariableValue(m_strExpression, m_strNewValue);
		// ---- get the variable's value and display it
		CWnd* pWnd = GetDlgItem(IDC_EXAMINE_VALUE);
		ASSERT(pWnd != 0);
		theApp.GetVariableValue(m_strExpression, pWnd);
	}
}

