// ProjectDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ProjectDlg dialog

class ProjectDlg : public CDialog
{
// Construction
public:
	ProjectDlg(CWnd* pParent = 0);   // standard constructor

// Dialog Data
	//{{AFX_DATA(ProjectDlg)
	enum { IDD = IDD_PROJDIALOG };
	CButton	m_browseproject;
	CEdit	m_target;
	CEdit	m_projectpath;
	int		m_nProjectType;
	CString	m_strTarget;
	CString	m_strWorking;
	CString	m_strPath;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ProjectDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ProjectDlg)
	virtual void OnOK();
	afx_msg void OnBrowseworking();
	afx_msg void OnBrowseproject();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
