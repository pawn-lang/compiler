// AddWatch.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "AddWatch.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddWatch dialog


CAddWatch::CAddWatch(CWnd* pParent)
	: CDialog(CAddWatch::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddWatch)
	m_strWatchVariable = _T("");
	//}}AFX_DATA_INIT
}


void CAddWatch::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddWatch)
	DDX_Text(pDX, IDC_WATCH_VARIABLE, m_strWatchVariable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddWatch, CDialog)
	//{{AFX_MSG_MAP(CAddWatch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddWatch message handlers
