// RunOptions.cpp : implementation file
//

#include "stdafx.h"
#include "quincy.h"
#include "OptionsSheet.h"
#include "RunOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRunOptions dialog


CRunOptions::CRunOptions(CWnd* pParent)
	: CPropertyPage(CRunOptions::IDD)
{
	//{{AFX_DATA_INIT(CRunOptions)
	m_strCommandLine = _T("");
	m_strRuntimeDirectory = _T("");
	m_CommandLinePromptOption = -1;
	//}}AFX_DATA_INIT
}


void CRunOptions::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRunOptions)
	DDX_Text(pDX, IDC_COMMAND_LINE, m_strCommandLine);
	DDX_Text(pDX, IDC_RUNTIMEDIRECTORY, m_strRuntimeDirectory);
	DDX_Radio(pDX, IDC_NOCOMMANLINE, m_CommandLinePromptOption);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRunOptions, CPropertyPage)
	//{{AFX_MSG_MAP(CRunOptions)
	ON_BN_CLICKED(IDC_BROWSERUNTIMEWK, OnBrowseruntimewk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRunOptions message handlers

BOOL CRunOptions::OnSetActive() 
{
	static_cast<COptionsSheet*>(GetParent())->RegisterActiveIndex();
	return CPropertyPage::OnSetActive();
}

void CRunOptions::OnBrowseruntimewk() 
{
	if (theApp.SelectFolder("Runtime Working Files", &m_strRuntimeDirectory))
		UpdateData(0);
}
