// ------- stabs.h

#ifndef STABS_H
#define STABS_H

#include <string>

class CStab	: public CObject {
	bool has_symbols;
public:
	CStab(const std::string& filename);
	bool TestSymbols() const { return has_symbols; }
};

#endif
