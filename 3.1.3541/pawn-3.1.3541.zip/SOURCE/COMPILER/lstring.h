/* prototypes for strlcpy() and strlcat() */

#include <stddef.h>

size_t
strlcpy(char *dst, const char *src, size_t siz);

size_t
strlcat(char *dst, const char *src, size_t siz);
