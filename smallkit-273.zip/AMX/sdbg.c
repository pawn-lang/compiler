/*  Small debugger
 *
 *  Minimal debugger with a console interface.
 *
 *  Copyright (c) ITB CompuPhase, 1998-2005
 *
 *  This software is provided "as-is", without any express or implied warranty.
 *  In no event will the authors be held liable for any damages arising from
 *  the use of this software.
 *
 *  Permission is granted to anyone to use this software for any purpose,
 *  including commercial applications, and to alter it and redistribute it
 *  freely, subject to the following restrictions:
 *
 *  1.  The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software. If you use this software in
 *      a product, an acknowledgment in the product documentation would be
 *      appreciated but is not required.
 *  2.  Altered source versions must be plainly marked as such, and must not be
 *      misrepresented as being the original software.
 *  3.  This notice may not be removed or altered from any source distribution.
 *
 *  Version: $Id: Sdbg.c,v 1.37 2005-02-09 10:17:47+01 thiadmer Exp $
 */
#include <assert.h>
#if defined __WIN32 || defined _WIN32 || defined __WIN32__ || defined __MSDOS__ || defined __WATCOMC__
  #include <conio.h>
  #if defined __WIN32 || defined _WIN32 || defined __WIN32__ || defined __WATCOMC__
    #if !defined __WIN32__
      #define __WIN32__ 1
    #endif
    #include <windows.h>
    #if !defined amx_Init && !defined NO_WIN32_CONSOLE && !defined AMX_TERMINAL
      #define WIN32_CONSOLE
    #endif
  #endif
#elif !defined macintosh
  #include "../linux/getch.h"
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#if defined READLINE
  #define __READLINE_IMPORT__   1
  #define __P(protos) protos
  #include <readline/readline.h>
  #include <readline/history.h>
#endif
#include "osdefs.h"     /* for _MAX_PATH */
#include "amx.h"


#define MAXSTACKTRACE   128
#define MAXLINELENGTH   128
#define MAX_DIMS        2       /* number of array dimensions */
#define TABSIZE         8
#define EATLINE         5       /* the number of characters for the line number */
#define STD_COLUMNS     80      /* number of characters that fit on a line */
#define WIDE_COLUMNS    132
#if defined amx_Init
  #define STD_LINES     29      /* number of lines that fit on a screen */
#else
  #define STD_LINES     24      /* number of lines that fit on a screen */
#endif
#define WATCHLINES      4       /* default number of watches displayed */
#define LISTLINES       (STD_LINES - WATCHLINES - 10) /* default code lines */

#if defined AMX_TERMINAL || defined amx_Init
  /* required functions are implemented elsewhere */
  int amx_printf(char *,...);
  int amx_putchar(int);
  int amx_fflush(void);
  int amx_getch(void);
  char *amx_gets(char *,int);
  int amx_termctl(int,int);
  void amx_clrscr(void);
  void amx_clreol(void);
  void amx_gotoxy(int x,int y);
  void amx_wherexy(int *x,int *y);
  unsigned int amx_setattr(int foregr,int backgr,int highlight);
  #if defined amx_Init
    #define STR_PROMPT  "dbg\xbb "
    #define CHR_HLINE   '\x97'
  #else
    #define STR_PROMPT  "dbg> "
    #define CHR_HLINE   '-'
  #endif
  #define CHR_VLINE     '|'
#elif defined VT100 || defined LINUX || defined ANSITERM
  /* ANSI/VT100 terminal, or shell emulating "xterm" */
  #if !defined VT100 && !defined ANSITERM && defined LINUX
    #define VT100
  #endif
  #define amx_printf      printf
  #define amx_putchar(c)  putchar(c)
  #define amx_fflush()    fflush(stdout)
  #define amx_getch()     getch()
  #define amx_gets(s,n)   fgets(s,n,stdin)
  int amx_termctl(int,int);
  void amx_clrscr(void);
  void amx_clreol(void);
  void amx_gotoxy(int x,int y);
  void amx_wherexy(int *x,int *y);
  unsigned int amx_setattr(int foregr,int backgr,int highlight);
  #define STR_PROMPT    "dbg> "
  #define CHR_HLINE     '-'
  #define CHR_VLINE     '|'
#elif defined WIN32_CONSOLE
  /* Win32 console */
  #define amx_printf      printf
  #define amx_putchar(c)  putchar(c)
  #define amx_fflush()    fflush(stdout)
  #define amx_getch()     getch()
  #define amx_gets(s,n)   fgets(s,n,stdin)
  int amx_termctl(int,int);
  void amx_clrscr(void);
  void amx_clreol(void);
  void amx_gotoxy(int x,int y);
  void amx_wherexy(int *x,int *y);
  unsigned int amx_setattr(int foregr,int backgr,int highlight);
  #define STR_PROMPT    "dbg\xaf "
  #define CHR_HLINE     '\xc4'
  #define CHR_VLINE     '\xb3'
#elif defined(USE_CURSES)
  /* Use the "curses" library to implement the console */
  const int _False = 0;     /* to avoid compiler warnings */
  #define amx_printf        printw
  #define amx_putchar(c)    addch(c)
  #define amx_fflush()      (0)
  #define amx_getch()       getch()
  #define amx_gets(s,n)     getnstr(s,n)
  #define amx_clrscr()      (void)(0)
  #define amx_clreol()      (void)(0)
  #define amx_gotoxy(x,y)   (void)(0)
  #define amx_wherexy(x,y)  (*(x)=*(y)=0)
  #define amx_setattr(c,b,h) (_False)
  #define amx_termctl(c,v)  (_False)
  #define STR_PROMPT        "dbg> "
  #define CHR_HLINE         '-'
  #define CHR_VLINE         '|'
#else
  /* assume a streaming terminal; limited features (no colour, no cursor
   * control)
   */
  const int _False = 0;     /* to avoid compiler warnings */
  #define amx_printf        printf
  #define amx_putchar(c)    putchar(c)
  #define amx_fflush()      fflush(stdout)
  #define amx_getch()       getch()
  #define amx_gets(s,n)     fgets(s,n,stdin)
  #define amx_clrscr()      (void)(0)
  #define amx_clreol()      (void)(0)
  #define amx_gotoxy(x,y)   (void)(0)
  #define amx_wherexy(x,y)  (*(x)=*(y)=0)
  #define amx_setattr(c,b,h) (_False)
  #define amx_termctl(c,v)  (_False)
  #define STR_PROMPT        "dbg> "
  #define CHR_HLINE         '-'
  #define CHR_VLINE         '|'
#endif
#define CHR_CURLINE         '*'
#if defined VT100
  #define CHR_HLINE_VT100   'q' // in alternate font
  #define CHR_VLINE_VT100   'x'
#endif

enum {
  BP_NONE,
  BP_CODE,
  BP_DATA,
  /* --- */
  BP_TYPES
};

enum {
  DISP_DEFAULT,
  DISP_STRING,
  DISP_BIN,   /* ??? not implemented */
  DISP_HEX,
  DISP_BOOL,
  DISP_FIXED,
  DISP_FLOAT,
  /* --- */
  DISP_TYPES
};

typedef struct tagSYMBOL {
  struct tagSYMBOL *next;
  char name[sNAMEMAX+1];
  ucell addr;
  int file;             /* file number that a function appears in */
  int line;             /* line number that a function starts on */
  int vclass;           /* variable class (global, local, static) */
  int tag;              /* variable tag (if known) */
  int type;             /* symbol type (local var/global var/function */
  int calllevel;        /* nesting level (visibility) of the variable */
  int length[MAX_DIMS]; /* for arrays */
  int dims;             /* for arrays */
  int disptype;         /* display type, may be preset based on the tag */
} SYMBOL;

typedef struct tagBREAKPOINT {
  struct tagBREAKPOINT *next;
  int type;             /* one of the BP_xxx types */
  ucell addr;           /* line number, or previous value */
  int file;             /* file in which the breakpoint appears */
  int index;            /* array element */
  int number;           /* sequential breakpoint number (to refer to the breakpoint) */
  SYMBOL *sym;
} BREAKPOINT;

typedef struct tagNAMELIST {
  struct tagNAMELIST *next;
  char *name;
  int number;
} NAMELIST;

#define iVARIABLE   1   /* cell that has an address and that can be fetched directly (lvalue) */
#define iREFERENCE  2   /* iVARIABLE, but must be dereferenced */
#define iARRAY      3
#define iREFARRAY   4   /* an array passed by reference (i.e. a pointer) */
#define iFUNCTN     9

static NAMELIST filenames= { NULL };
static int curfileno=-1;
static char **cursource;
static int curline;
static int stopline;
static int autolist=1;
static int screencolumns=STD_COLUMNS;
static int screenlines=STD_LINES;
static int listlines=LISTLINES;
static int watchlines=WATCHLINES;
static BREAKPOINT breakpoints={ NULL };
static NAMELIST watches={ NULL };
static SYMBOL functab={ NULL };
static SYMBOL vartab={ NULL };
static int curtopline;  /* current line that is on top in the list */
static ucell callstack[MAXSTACKTRACE];
static int terminal;
static char chr_hline=CHR_HLINE;
static char chr_vline=CHR_VLINE;


static void draw_hline(int forceinit)
{
static char hline_str[WIDE_COLUMNS+1] = "";

  /* initialize the string, if not yet done */
  if (forceinit || strlen(hline_str)==0) {
    memset(hline_str,chr_hline,sizeof hline_str);
    hline_str[screencolumns]='\0';
  } /* if */

  #if defined VT100
    if (terminal)
      amx_printf("\016");          /* SO code to select the graphic set */
  #endif

  amx_printf(hline_str);

  #if defined VT100
    if (terminal)
      amx_printf("\017");          /* SI code to select the standard set */
  #endif
}

#if defined WIN32_CONSOLE
void win32_screensize(int *width,int *height)
{
  CONSOLE_SCREEN_BUFFER_INFO csbi;
  assert(width!=NULL && height!=NULL);
  GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE),&csbi);
  *width=(int)csbi.dwSize.X;
  *height=(int)csbi.dwSize.Y;
}
#endif

static int csrsave_x, csrsave_y;
#if !defined NDEBUG
  static int csrsave_flag=0;
#endif

static void term_csrsave(void)
{
  assert(terminal);
  #if !defined NDEBUG
    assert(csrsave_flag==0);
    csrsave_flag++;
  #endif
  amx_wherexy(&csrsave_x,&csrsave_y);
}

static void term_csrrestore(void)
{
  assert(terminal);
  #if !defined NDEBUG
    assert(csrsave_flag==1);
    csrsave_flag--;
  #endif
  amx_gotoxy(csrsave_x,csrsave_y);
}

static void term_refresh(void)
{
  assert(terminal);
  amx_clrscr();
  amx_gotoxy(1,watchlines+1);
  draw_hline(1);
  amx_gotoxy(1,watchlines+listlines+2);
  draw_hline(0);
  amx_gotoxy(1,watchlines+listlines+3);
}

static void term_open(void)
{
  terminal=1;
  screencolumns=STD_COLUMNS;
  screenlines=STD_LINES;
  amx_clrscr();
  amx_termctl(1,0);                        /* disable "auto-wrap" */
  #if defined VT100
    screencolumns=WIDE_COLUMNS;
    chr_hline=CHR_HLINE_VT100;
    chr_vline=CHR_VLINE_VT100;
    amx_printf("\033[?3h");                /* set 132 column-mode */
    amx_printf("\033[%d;%dr",watchlines+listlines+3,STD_LINES-1); /* set window */
    amx_printf("\033)0");                  /* select graphics codes for set G1 */
  #endif
  #if defined WIN32_CONSOLE
    win32_screensize(&screencolumns,&screenlines);
    screenlines--;      /* keep last line empty */
  #elif defined READLINE
    rl_get_screen_size(&screencolumns,&screenlines);
    screenlines--;      /* keep last line empty */
  #endif
  term_refresh();
}

static void term_close(void)
{
  assert(terminal);
  #if defined VT100
    amx_printf("\033[?3l");                /* reset to 80 column-mode */
    amx_printf("\033[r");                  /* scrolling region is full screen */
    screencolumns=STD_COLUMNS;
    chr_hline=CHR_HLINE;
    chr_vline=CHR_VLINE;
  #endif
  amx_termctl(1,1);                        /* re-enable "auto-wrap" */
  amx_clrscr();
  screencolumns=STD_COLUMNS;
  terminal=0;
}

static int term_switch(int number)
{
  if (terminal)
    return amx_termctl(2,number);
  return 0;
}

static void source_free(char **source)
{
  int i;

  assert(source!=NULL);
  for (i=0; source[i]!=NULL; i++)
    free(source[i]);
  free(source);
}

static char **source_load(char *filename)
{
  char **source;
  FILE *fp;
  char line[256];
  int lines,i;

  /* open the file, number of characters */
  assert(filename!=NULL);
  if ((fp=fopen(filename,"rt"))==NULL)
    return NULL;
  lines=0;
  while (fgets(line,sizeof(line),fp)!=NULL)
    lines++;

  /* allocate memory, reload the file */
  if ((source=(char **)malloc((lines+1)*sizeof(char *)))==NULL) {
    fclose(fp);
    return NULL;
  } /* if */
  for (i=0; i<=lines; i++)      /* initialize, so that source_free() works */
    source[i]=NULL;
  rewind(fp);
  i=0;
  while (fgets(line,sizeof(line),fp)!=NULL) {
    assert(i<lines);
    source[i]=strdup(line);
    if (source[i]==NULL) {
      fclose(fp);
      source_free(source);      /* free everything allocated so far */
      return NULL;
    } /* if */
    i++;
  } /* if */

  fclose(fp);
  return source;
}

static void source_list(int startline, int numlines)
{
  /* cursource and curline should already have been set */
  int result,lastline;

  if (terminal) {
    term_csrsave();
    amx_gotoxy(1,watchlines+2);
    numlines=listlines;  /* override user setting */
  } /* if */

  if (startline<0)
    startline=0;
  lastline=startline+numlines;
  curtopline=startline; /* save line that is currently displayed at the top */

  /* seek to line number from the start (to avoid displaying something
   * beyond the file)
   */
  for (result=0; cursource[result]!=NULL && result<startline; result++)
    /* nothing */;
  if (cursource[result]!=NULL) {
    assert(result==startline);
    while (cursource[startline]!=NULL && startline<lastline) {
      char c1='\0',c2='\0';
      if (terminal)
        amx_clreol();
      if ((int)strlen(cursource[startline])>screencolumns-EATLINE) {
        c1=cursource[startline][screencolumns-EATLINE-1];
        c2=cursource[startline][screencolumns-EATLINE];
        cursource[startline][screencolumns-EATLINE-1] = '\n';
        cursource[startline][screencolumns-EATLINE] = '\0';
      } /* if */
      amx_setattr(-1,-1,startline==curline);
      if (!terminal) {
        if (startline==curline)
          amx_printf("%3d%c %s",startline+1,CHR_CURLINE,cursource[startline]);
        else
          amx_printf("%3d  %s",startline+1,cursource[startline]);
      } else {
        amx_printf("%4d",startline+1);
        #if defined VT100
          if (terminal)
            amx_printf("\016");    /* SO code to select the graphic set */
        #endif
        amx_printf("%c",chr_vline);
        #if defined VT100
          if (terminal)
            amx_printf("\017");    /* SI code to select the standard set */
        #endif
        amx_printf("%s",cursource[startline]);
      } /* if */
      if (c1!='\0') {
        cursource[startline][screencolumns-EATLINE-1] = c1;
        cursource[startline][screencolumns-EATLINE] = c2;
      } /* if */
      startline++;
    } /* while */
  } /* if */

  if (terminal) {
    amx_setattr(-1,-1,0);
    while (startline<lastline) {
      amx_clreol();
      amx_printf("\n");
      startline++;
    } /* while */
    term_csrrestore();
  } /* if */
}

static int gettopline(int line,int topline)
{
  if (!terminal)
    return topline;
  if (line<curtopline || line>=curtopline+listlines)
    return topline;
  return curtopline;
}

static char *skipwhitespace(char *str)
{
  while (*str==' ' || *str=='\t')
    str++;
  return str;
}

static char *skipvalue(char *str)
{
  while (isdigit(*str))
    str++;
  str=skipwhitespace(str);
  return str;
}

static char *skippath(char *str)
{
  char *p1,*p2;

  /* DOS/Windows pathnames */
  if ((p1=strrchr(str,'\\'))!=NULL)
    p1++;
  else
    p1=str;
  /* Unix pathnames */
  if ((p2=strrchr(str,'/'))!=NULL)
    p2++;
  else
    p2=str;
  return p1>p2 ? p1 : p2;
}

static void namelist_init(NAMELIST *root)
{
  NAMELIST *next;

  while (root->next!=NULL) {
    next=root->next;
    root->next=next->next;      /* unlink */
    free(next->name);           /* then free */
    free(next);
  } /* while */
}

static NAMELIST *namelist_find(NAMELIST *root,int number)
{
  NAMELIST *name;

  for (name=root->next; name!=NULL && name->number!=number; name=name->next)
    /* nothing */;
  return name;
}

static int namelist_delete(NAMELIST *root,NAMELIST *item)
{
  NAMELIST *cur;

  /* find the item */
  assert(root!=NULL);
  cur=root;
  while (cur->next!=NULL && cur->next!=item)
    cur=cur->next;
  assert(cur!=NULL);
  if (cur->next==NULL)
    return 0;                   /* item not found */

  cur->next=item->next;         /* unlink */
  free(item->name);             /* then free */
  free(item);

  return 1;
}

static NAMELIST *namelist_add(NAMELIST *root,char *name,int number)
{
  NAMELIST *cur, *pred;

  /* allocate a structure */
  cur=malloc(sizeof(NAMELIST));
  if (cur==NULL)
    return NULL;
  cur->name=strdup(name);
  cur->number=number;
  if (cur->name==NULL) {
    free(cur);
    return NULL;
  } /* if */

  /* link it in the list */
  assert(root!=NULL);
  for (pred=root; pred->next!=NULL && pred->next->number<number; pred=pred->next)
    /* nothing */;
  cur->next=pred->next;
  pred->next=cur;

  return cur;
}

static int namelist_count(NAMELIST *root)
{
  int count = 0;
  NAMELIST *name;

  for (name=root->next; name!=NULL; name=name->next)
    count++;
  return count;
}

static void file_init(void)
{
  namelist_init(&filenames);
}

static NAMELIST *file_find(int number)
{
  return namelist_find(&filenames,number);
}

static NAMELIST *file_add(char *name,int number)
{
  return namelist_add(&filenames,name,number);
}

static SYMBOL *add_symbol(SYMBOL *table,char *name,int type,ucell addr,
                          int vclass,int level)
{
  SYMBOL *sym;

  if ((sym=(SYMBOL *)malloc(sizeof(SYMBOL)))==NULL)
    return NULL;
  memset(sym,0,sizeof(SYMBOL));
  assert(strlen(name)<=sNAMEMAX);
  strcpy(sym->name,name);
  sym->type=type;
  sym->addr=addr;
  sym->vclass=vclass;
  sym->calllevel=level;
  sym->length[0]=0;     /* indeterminate */
  sym->length[1]=0;     /* indeterminate */
  if (type==iARRAY || type==iREFARRAY)
    sym->dims=1;        /* for now, assume single dimension */
  else
    sym->dims=0;        /* not an array */
  sym->disptype=DISP_DEFAULT;
  sym->next=table->next;
  table->next=sym;
  return sym;
}

static SYMBOL *find_symbol(SYMBOL *table,char *name,int level)
{
  SYMBOL *sym = table->next;

  while (sym!=NULL) {
    if (strcmp(name,sym->name)==0 && sym->calllevel==level)
      return sym;
    sym=sym->next;
  } /* while */
  return NULL;
}

static SYMBOL *find_symbol_addr(SYMBOL *table,ucell addr,int level)
{
  SYMBOL *sym = table->next;

  while (sym!=NULL) {
    if (sym->addr==addr && sym->calllevel==level)
      return sym;
    sym=sym->next;
  } /* while */
  return NULL;
}

static void delete_symbol(SYMBOL *table,ucell addr,int level)
{
  SYMBOL *prev = table;
  SYMBOL *cur = prev->next;

  /* Delete all local symbols below a certain address (these are local
   * variables from a function/block that one stepped out of). Also
   * remove all symbols of deeper calllevels (removes the static variables
   * at the end of a function).
   */
  while (cur!=NULL) {
    if ((cur->calllevel > level)
        || ((1 == cur->vclass) && (cur->addr < addr)))
    {
      prev->next=cur->next;
      free(cur);
      cur=prev->next;
    } else {
      prev=cur;
      cur=cur->next;
    } /* if */
  } /* while */
}

static void delete_allsymbols(SYMBOL *table)
{
  SYMBOL *sym=table->next, *next;

  while (sym!=NULL) {
    next=sym->next;
    free(sym);
    sym=next;
  } /* while */
}

static cell get_symbolvalue(AMX *amx,SYMBOL *sym,int index)
{
  cell *value;
  cell base;

  if (sym->type==iREFERENCE || sym->type==iREFARRAY) {   /* a reference */
    amx_GetAddr(amx,sym->addr,&value);
    base=*value;
  } else {
    base=sym->addr;
  } /* if */
  amx_GetAddr(amx,(cell)(base+index*sizeof(cell)),&value);
  return *value;
}

static char *get_string(AMX *amx,SYMBOL *sym,int maxlength)
{
static char string[MAXLINELENGTH];
  char *ptr;
  cell *addr;
  cell base;
  int length,num;

  assert(sym->type==iARRAY || sym->type==iREFARRAY);
  assert(sym->dims==1);
  assert(maxlength<MAXLINELENGTH);
  string[0]='\0';

  /* get the staring address and the length of the string */
  base=sym->addr;
  if (sym->type==iREFARRAY) {   /* a reference */
    amx_GetAddr(amx,base,&addr);
    base=*addr;
  } /* if */
  amx_GetAddr(amx,base,&addr);
  amx_StrLen(addr,&length);

  /* allocate a temporary buffer */
  ptr=malloc(length+1);
  if (ptr!=NULL) {
    amx_GetString(ptr,addr,0);
    num=length;
    if (num>=maxlength) {
      num=maxlength-1;
      if (num>3)
        num-=3;         /* make space for the ... terminator */
    } /* if */
    assert(num>=0);
    strncpy(string,ptr,num);
    string[num]='\0';
    if (num<length && num==maxlength-3)
      strcat(string,"...");
    free(ptr);
  } /* if */
  return string;
}

static void printvalue(long value, int disptype)
{
  if (disptype==DISP_FLOAT) {
    amx_printf("%f", amx_ctof(value));
  } else if (disptype==DISP_FIXED) {
    #define MULTIPLIER 1000
    long ipart=value/MULTIPLIER;
    value-=MULTIPLIER*ipart;
    if (value<0)
      value=-value;
    amx_printf("%ld.%03ld", ipart, value);
  } else if (disptype==DISP_HEX) {
    amx_printf("%lx", value);
  } else if (disptype==DISP_BOOL) {
    switch (value) {
    case 0:
      amx_printf("false");
      break;
    case 1:
      amx_printf("true");
      break;
    default:
      amx_printf("%ld (true)",value);
      break;
    } /* switch */
  } else {
    amx_printf("%ld", value);
  } /* if */
}

static void display_variable(AMX *amx,SYMBOL *sym,int index,int idxlevel)
{
  if ((sym->type==iARRAY || sym->type==iREFARRAY) && idxlevel==0) {
    if (sym->disptype==DISP_STRING) {
      amx_printf("\"%s\"", get_string(amx,sym,40));
    } else if (sym->dims==1) {
      int len=sym->length[0];
      int i;
      if (len>5)
        len=5;
      else if (len==0)
        len=1;  /* unknown array length, assume at least 1 element */
      amx_printf("{");
      for (i=0; i<len; i++) {
        if (i>0)
          amx_printf(",");
        printvalue(get_symbolvalue(amx,sym,i),sym->disptype);
      } /* for */
      if (len<sym->length[0] || sym->length[0]==0)
        amx_printf(",...");
      amx_printf("}");
    } else {
      amx_printf("(multi-dimensional array)");
    } /* if */
  } else if ((sym->type==iARRAY || sym->type==iREFARRAY) && sym->length[0]>0 && index>=sym->length[0]) {
    amx_printf("(index out of range, size=%d)",sym->length[0]);
  } else if (sym->type!=iARRAY && sym->type!=iREFARRAY && idxlevel>0) {
    /* index used on a non-array */
    amx_printf("(invalid index, not an array)");
  } else {
    /* simple variable, or indexed array element */
    printvalue(get_symbolvalue(amx,sym,index),sym->disptype);
  } /* if */
}

static void watch_init(void)
{
  namelist_init(&watches);
}

static void watch_list(AMX *amx,int calllevel)
{
  int num,idx;
  SYMBOL *sym;
  char *indexptr;
  char name[sNAMEMAX+20]; /* extra space for an array index */
  NAMELIST *watch;

  if (terminal) {
    term_csrsave();
    amx_gotoxy(1,1);
    printf("\n");       /* clear "tab state" if the terminal driver forgot */
    amx_gotoxy(1,1);    /* and set the cursor position again */
  } /* if */

  num=0;
  for (watch=watches.next; watch!=NULL; watch=watch->next) {
    assert(watch->name!=NULL && strlen(watch->name)>0);
    strcpy(name,watch->name);
    indexptr=strchr(name,'[');
    if (indexptr!=NULL) {
      idx=atoi(indexptr+1);
      *indexptr='\0';
    } else {
      idx=0;
    } /* if */
    amx_printf("%d   %-12s ",num++,watch->name);
    /* search locals, then globals */
    sym=find_symbol(&vartab,name,calllevel);
    if (sym==NULL)
      sym=find_symbol(&vartab,name,-1);
    if (sym!=NULL)
      display_variable(amx,sym,idx,(indexptr==NULL) ? 0 : 1);
    else
      amx_printf("(unknown symbol)");
    if (terminal)
      amx_clreol();
    amx_printf("\n");
  } /* for */

  if (terminal) {
    if (num==0)
      amx_printf("(no watches)");
    for ( ; num<watchlines; num++) {
      amx_clreol();
      amx_printf("\n");
    } /* for */
    term_csrrestore();
  } else {
    if (num>0)
      draw_hline(0);
  } /* if */
}

static int watch_set(int number, char *name)
{
  NAMELIST *cur;

  /* find a free number */
  if (number<0) {
    int changed;
    number=0;
    do {
      changed=0;
      for (cur=watches.next; cur!=NULL; cur=cur->next) {
        if (cur->number==number) {
          number++;
          changed=1;
        } /* if */
      } /* for */
    } while (changed);
  } /* if */

  /* add the watch */
  return namelist_add(&watches,name,number)!=NULL;
}

static int watch_clear(int number)
{
  NAMELIST *name=namelist_find(&watches,number);
  if (name!=NULL) {
    namelist_delete(&watches,name);
    return 1;
  } /* if */
  return 0;
}

static int watch_count(void)
{
  return namelist_count(&watches);
}

static void break_init(void)
{
  BREAKPOINT *next;

  while (breakpoints.next!=NULL) {
    next=breakpoints.next;
    breakpoints.next=next->next;  /* unlink */
    free(next);                   /* then free */
  } /* while */
}

static int break_clear(int number)
{
  BREAKPOINT *cur;

  /* find the breakpoint */
  cur=&breakpoints;
  while (cur->next!=NULL && cur->next->number!=number)
    cur=cur->next;
  if (cur->next==NULL)
    return 0;                   /* breakpoint not found */

  cur->next=cur->next->next;    /* unlink */
  free(cur->next);              /* then free */
  return 1;
}

static int break_set(AMX *amx,char *str,int calllevel)
{
  BREAKPOINT *cur,*newbp;
  int number,changed;
  SYMBOL *sym;

  /* find an unused breakpoint number */
  number=0;
  do {
    changed=0;
    for (cur=breakpoints.next; cur!=NULL; cur=cur->next) {
      if (cur->number==number) {
        number++;
        changed=1;
      } /* if */
    } /* for */
  } while (changed);

  /* allocate a new breakpoint, add it in the list */
  newbp=malloc(sizeof(BREAKPOINT));
  if (newbp==0)
    return -1;
  memset(newbp,0,sizeof(BREAKPOINT));
  for (cur=&breakpoints; cur->next!=NULL && cur->next->number<number; cur=cur->next)
    /* nothing */;
  assert(cur!=NULL);
  newbp->next=cur->next;
  cur->next=newbp;

  /* find type */
  str=skipwhitespace(str);
  if (isdigit(*str)) {
    newbp->type=BP_CODE;
    newbp->file=curfileno;
    newbp->addr=(ucell)atol(str);
  } else if ((sym=find_symbol(&functab,str,-1))!=NULL) {
    newbp->type=BP_CODE;
    newbp->addr=sym->line;
    newbp->file=sym->file;
    newbp->sym=sym;
  } else {
    char *idxptr=strchr(str,'[');
    int idx=-1;
    if (idxptr!=NULL) {
      idx=atoi(idxptr+1);
      *idxptr='\0';
    } /* if */
    if ((sym=find_symbol(&vartab,str,calllevel))!=NULL) {
      if (sym->type==iARRAY || sym->type==iREFARRAY) {
        if (idxptr==NULL)
          return -1;            /* missing index on array */
        if (sym->length[0]>0 && idx>=sym->length[0])
          return -1;            /* index out of range */
      } /* if */
      if (sym->type!=iARRAY && sym->type!=iREFARRAY && idxptr!=NULL)
        return -1;
      newbp->type=BP_DATA;
      newbp->addr=get_symbolvalue(amx,sym,idx>=0 ? idx : 0);
      newbp->sym=sym;
      newbp->index=idx;
    } else {
      return -1;
    } /* if */
  } /* if */
  return number;
}

static void break_list(void)
{
  BREAKPOINT *cur;

  for (cur=breakpoints.next; cur!=NULL; cur=cur->next) {
    assert(cur->type!=BP_NONE);
    amx_printf("%2d  ",cur->number);
    if (cur->type==BP_CODE) {
      amx_printf("line: %d",cur->addr);
      if (cur->sym!=NULL) {
        amx_printf("  func: %s",cur->sym->name);
      } else {
        NAMELIST *file=file_find(cur->file);
        if (file!=NULL)
          amx_printf("  file: %s",skippath(file->name));
      } /* if */
      amx_printf("\n");
    } else {
      /* must be variable */
      assert(cur->sym!=NULL);
      amx_printf("var: %s",cur->sym->name);
      if (cur->index>=0)
        amx_printf("[%d]",cur->index);
      amx_printf("\n");
    } /* if */
  } /* for */
}

static int break_check(AMX *amx,int line,int file)
{
  BREAKPOINT *cur;

  for (cur=breakpoints.next; cur!=NULL; cur=cur->next) {
    if (cur->type==BP_CODE && (int)cur->addr==line && cur->file==file) {
      return cur->number;
    } else {
      int idx=cur->index;
      SYMBOL *sym=cur->sym;
      ucell value;
      assert(cur->type==BP_DATA);
      assert(sym!=NULL);
      value=get_symbolvalue(amx,sym,idx>=0 ? idx : 0);
      if (cur->addr!=value) {
        cur->addr=value;
        return cur->number;
      } /* if */
    } /* if */
  } /* for */
  return -1;
}

enum {
  GO,
  GO_RET,
  NEXT,
  STEP,
};

static void listcommands(char *command)
{
  if (command==NULL)
    command="";
  if (stricmp(command,"break")==0) {
    amx_printf("\tBREAK\t\tlist all breakpoints\n"
            "\tBREAK n\t\tset a breakpoint at line \"n\"\n"
            "\tBREAK func\tset a breakpoint at function with name \"func\"\n"
            "\tBREAK var\tset a breakpoint at variable \"var\"\n"
            "\tBREAK var[i]\tset a breakpoint at array element \"var[i]\"\n");
  } else if (stricmp(command,"cbreak")==0) {
    amx_printf("\tCBREAK n\tremove breakpoint number \"n\"\n"
            "\tCBREAK *\tremove all breakpoints\n");
  } else if (stricmp(command,"cw")==0 || stricmp(command,"cwatch")==0) {
    amx_printf("\tCWATCH may be abbreviated to CW\n\n"
            "\tCWATCH n\tremove watch number \"n\"\n"
            "\tCWATCH *\tremove all watches\n");
  } else if (stricmp(command,"d")==0 || stricmp(command,"disp")==0) {
    amx_printf("\tDISP may be abbreviated to D\n\n"
            "\tDISP\t\tdisplay all variables that are currently in scope\n"
            "\tDISP var\tdisplay the value of variable \"var\"\n"
            "\tDISP var[i]\tdisplay the value of array element \"var[i]\"\n");
  } else if (stricmp(command,"file")==0) {
    amx_printf("\tFILE\t\tlist all files that this program is composed off\n"
            "\tFILE name\tset the current file to \"name\"\n");
  } else if (stricmp(command,"g")==0 || stricmp(command,"go")==0) {
    amx_printf("\tGO may be abbreviated to G\n\n"
            "\tGO\t\trun until the next breakpoint or program termination\n"
            "\tGO RET\t\trun until the end of the current function\n"
            "\tGO n\t\trun until line number \"n\"\n");
  } else if (stricmp(command,"l")==0 || stricmp(command,"list")==0) {
    amx_printf("\tLIST may be abbreviated to L\n\n"
            "\tLIST\t\tdisplay 10 lines around the current line\n"
            "\tLIST n\t\tdisplay 10 lines, starting from line \"n\"\n"
            "\tLIST n m\tdisplay \"m\" lines, starting from line \"n\" (not\n"
            "\t\t\tsupported in terminal emulation modes)\n"
            "\tLIST FUNCS\tdisplay all functions\n"
            "\tLIST ON\t\tautomatically list 10 lines after each step\n"
            "\tLIST OFF\tturn off automatic list (not supported in terminal\n"
            "\t\t\temulation modes)\n");
  } else if (stricmp(command,"calls")==0
             || stricmp(command,"n")==0 || stricmp(command,"next")==0
             || stricmp(command,"quit")==0
             || stricmp(command,"s")==0 || stricmp(command,"step")==0)
  {
    amx_printf("\tno additional information\n");
  } else if (stricmp(command,"term")==0) {
    amx_printf("\tTERM OFF\tno terminal support\n"
            "\tTERM ON\tuse available terminal capabilities\n");
  } else if (stricmp(command,"type")==0) {
    amx_printf("\tTYPE var STRING\tdisplay \"var\" as string\n"
            "\tTYPE var STD\tset default display format (decimal integer)\n"
            "\tTYPE var HEX\tset hexadecimal integer format\n"
            "\tTYPE var FIXED\tset fixed point format (3 decimals)\n"
            "\tTYPE var FLOAT\tset floating point format\n");
  } else if (stricmp(command,"watch")==0 || stricmp(command,"w")==0) {
    amx_printf("\tWATCH may be abbreviated to W\n\n"
            "\tWATCH var\tset a new watch at variable \"var\"\n"
            "\tWATCH n var\tchange watch \"n\" to variable \"var\"\n");
  } else {
    amx_printf("\tBREAK\t\tset breakpoint at line number or variable name\n"
            "\tCALLS\t\tshow call stack\n"
            "\tCBREAK\t\tremove breakpoint\n"
            "\tCW(atch)\tremove a \"watchpoint\"\n"
            "\tD(isp)\t\tdisplay the value of a variable, list variables\n"
            "\tFILE\t\tswitch to a file\n"
            "\tG(o)\t\trun program (until breakpoint)\n"
            "\tL(ist)\t\tdisplay source file and symbols\n"
            "\tN(ext)\t\tRun until next line, step over functions\n"
            "\tOUTPUT\t\tShow program output (if supported by terminal)\n"
            "\tQUIT\t\texit debugger, terminate program\n"
            "\tS(tep)\t\tsingle step, step into functions\n"
            "\tTERM\t\tset terminal type\n"
            "\tTYPE\t\tset the \"display type\" of a symbol\n"
            "\tW(atch)\t\tset a \"watchpoint\" on a variable\n"
            "\n\tUse \"? <command name>\" to view more information on a command\n");
  } /* if */
}

#if defined READLINE
/* Read a string, and return a pointer to it. Returns NULL on EOF. */
char *rl_gets(char *str,int length)
{
  char *line_read=readline(STR_PROMPT);
  if (line_read==NULL)
    return NULL;

  /* copy the line (with possible truncation) */
  strncpy(str,line_read,length);
  if ((int)strlen(line_read)>length)
    str[length-1]='\0';
  #if !defined __WIN32__
    /* readline() allocates memory internally, which it asks you to deallocate
     * with free(). This is an acceptable design with a statically linked
     * library, and perhaps even with shared libraries in Unix/Linux, but it
     * is problematic with DLLs under Microsoft Windows. In Microsoft Windows,
     * the standard C library was never part of the OS, so each compiler
     * vendor provided its own. If your DLL allocates memory and your program
     * (that uses the DLL) frees it, chances are that the malloc() and free()
     * implementations assume a different heap lay-out (because they originate
     * from different vendors, or from different versions of the compiler, or
     * even because of different compilation options/flags).
     * Now if malloc() and free() disagree, trouble is never far.
     * To illustruate the problem: I downloaded a readline Win32 port (a DLL),
     * but calling free() on the returned pointer consistently crashes the
     * program. I must have a different compiler than the one used to compile
     * the DLL, or a different version of the compiler, or different compiler
     * options, or a different MSVCRT.DLL.
     * As a temporary solution, I have chosen to "leak" memory (instead of
     * crashing).
     */
    free(line_read);
  #endif

  /* If the line has any text in it, save it on the history. */
  if (strlen(str)>0)
    add_history(line_read);

  return str;
}
#else
char *rl_gets(char *str,int length)
{
  amx_printf("%s",STR_PROMPT);
  amx_gets(str,length);
  return str;
}
#endif

static int docommand(AMX *amx,int calllevel)
{
static char lastcommand[10] = "";
  char line[MAXLINELENGTH], command[32];
  int result,i;
  SYMBOL *sym;
  NAMELIST *file;
  char *params;

  for ( ;; ) {
    if (terminal) {
      term_csrsave();
      amx_gotoxy(1,screenlines);
      amx_clreol();
    } /* if */
    rl_gets(line,sizeof(line));
    if (terminal)
      term_csrrestore();
    if (line[0]=='\033') {
      assert(terminal);
      if (strcmp(line+1,"[11~")==0)
        strcpy(line,"?");       /* F1 == Help */
      else if (strcmp(line+1,"[13~")==0)
        strcpy(line,"L");       /* F3 == List */
      else if (strcmp(line+1,"[14~")==0)
        strcpy(line,"Output");  /* F4 == Output */
      else if (strcmp(line+1,"[15~")==0)
        strcpy(line,"G");       /* F5 == Go */
      else if (strcmp(line+1,"[19~")==0)
        strcpy(line,"S");       /* F8 == Step */
      else if (strcmp(line+1,"[21~")==0)
        strcpy(line,"N");       /* F10 == Next */
      else
        continue;
    } /* if */
    if ((params=strchr(line,'\n'))!=NULL)
      *params='\0';     /* strip newline character */
    if (strlen(line)==0) {
      if (!terminal) {
        int csrx,csry;
        amx_wherexy(&csrx,&csry);
        amx_gotoxy(1,csry-1);
        amx_clreol();
      } /* if */
      strcpy(line,lastcommand);
    } /* if */
    lastcommand[0]='\0';

    result=sscanf(line,"%8s",command);
    if (result<=0) {
      listcommands(NULL);
      continue;
    } /* if */
    params=strchr(line,' ');
    params=(params!=NULL) ? skipwhitespace(params) : "";

    if (stricmp(command,"?")==0) {
      result=sscanf(line,"%*s %30s",command);
      listcommands(result ? command : NULL);
    } else if (stricmp(command,"quit")==0) {
      exit(0);
    } else if (stricmp(command,"g")==0 || stricmp(command,"go")==0) {
      if (stricmp(params,"ret")==0)
        return GO_RET;
      stopline=atoi(params);
      return GO;
    } else if (stricmp(command,"s")==0 || stricmp(command,"step")==0) {
      strcpy(lastcommand,"s");
      return STEP;
    } else if (stricmp(command,"n")==0 || stricmp(command,"next")==0) {
      strcpy(lastcommand,"n");
      return NEXT;
    } else if (stricmp(command,"l")==0 || stricmp(command,"list")==0) {
      /* first check a few hard cases */
      if (stricmp(params,"funcs")==0) {
        for (sym=functab.next; sym!=NULL; sym=sym->next) {
          file=file_find(sym->file);
          amx_printf("%s\t%s(%d)\n",sym->name,
                  (file!=NULL) ? skippath(file->name) : "???",sym->line);
        } /* for */
      } else if (stricmp(params,"on")==0) {
        autolist=listlines;
        watch_list(amx,calllevel);
        source_list(curline-autolist/2,autolist);
      } else if (stricmp(params,"off")==0) {
        if (!terminal)
          autolist=1;
        else
          amx_printf("\tCommand not supported on terminals\n");
      } else {
        int lnum,numlines;
        lnum=curline-(listlines/2-1);    /* preset */
        numlines=listlines;
        sscanf(line,"%*s %d %d",&lnum,&numlines);
        lnum--;           /* if user filled in a line number, subtract 1 */
        #if !defined VT100
          if (terminal) {
            int csrx,csry;
            amx_wherexy(&csrx,&csry);
            if (csry>=screenlines)
              term_refresh();
          } /* if */
        #endif
        source_list(lnum,numlines);
      } /* if */
    } else if (stricmp(command,"break")==0) {
      if (*params=='\0') {
        break_list();
      } else {
        result=break_set(amx,params,calllevel);
        if (result<0)
          amx_printf("Invalid breakpoint, or table full\n");
      } /* if */
    } else if (stricmp(command,"cbreak")==0) {
      if (*params=='*') {
        /* clear all breakpoints */
        break_init();
      } else if (isdigit(*params)) {
        if (!break_clear(atoi(params)))
          amx_printf("\tUnknown breakpoint\n");
      } else {
        amx_printf("\tInvalid command\n");
      } /* if */
    } else if (stricmp(command,"calls")==0) {
      assert(calllevel>=0);
      if (calllevel<MAXSTACKTRACE) {
        for (i=calllevel-1; i>=0; i--) {
          sym=find_symbol_addr(&functab,callstack[i],-1);
          assert(sym!=NULL);
          file=file_find(sym->file);
          amx_printf("\t%s\t%s(%d)\n",sym->name,
                  (file!=NULL) ? skippath(file->name) : "???",sym->line);
        } /* for */
      } else {
        amx_printf("\tCall stack saturated\n");
      } /* if */
    } else if (stricmp(command,"disp")==0 || stricmp(command,"d")==0) {
      if (*params=='\0') {
        /* display all */
        for (sym=vartab.next; sym!=NULL; sym=sym->next) {
          if (sym->calllevel==-1 || sym->calllevel==calllevel) {
            amx_printf("%s\t%s\t",sym->vclass>0 ? "loc" : "glb",sym->name);
            display_variable(amx,sym,0,0);
            amx_printf("\n");
          } /* if */
        } /* for */
      } else {
        char *indexptr=strchr(params,'[');
        if (indexptr!=NULL) {
          i=atoi(indexptr+1);
          *indexptr='\0';
        } else {
          i=0;
        } /* if */
        if ((sym=find_symbol(&vartab,params,calllevel))!=NULL) {
          amx_printf("%s\t%s\t",sym->vclass>0 ? "loc" : "glb",sym->name);
          display_variable(amx,sym,i,(indexptr==NULL) ? 0 : 1);
          amx_printf("\n");
        } else {
          amx_printf("\tSymbol not found, or not a variable\n");
        } /* if */
      } /* if */
    } else if (stricmp(command,"file")==0) {
      if (*params=='\0') {
        for (file=filenames.next; file!=NULL; file=file->next)
          amx_printf("%5d\t%s\n",i,file->name);
      } else {
        /* find the file */
        for (file=filenames.next; file!=NULL; file=file->next)
          if (stricmp(params,file->name)==0 || stricmp(params,skippath(file->name))==0)
            break;
        if (file!=NULL) {
          if (curfileno!=file->number) {
            curfileno=file->number;
            curline=0;
          } /* if */
          if (cursource!=NULL)
            source_free(cursource);
          assert(file->name!=NULL);
          cursource=source_load(file->name);
          if (cursource==NULL) {
            amx_printf("\tSource file not found (or insufficient memory)\n");
            continue;
          } /* if */
        } else {
          amx_printf("\tunknown file\n");
        } /* if */
      } /* if */
    } else if (stricmp(command,"term")==0) {
      int new_term=-1;
      if (stricmp(params,"off")==0)
        new_term=0;
      else if (stricmp(params,"on")==0)
        new_term=1;
      if (new_term==-1) {
        amx_printf("\tTerminal support is %s\n",terminal ? "ON" : "OFF");
      } else if (terminal!=new_term) {
        curtopline=0;
        if (terminal)
          term_close();
        if (new_term && amx_termctl(0,0)) {
          autolist=listlines;
          term_open();
        } else {
          amx_printf("\tTerminal not supported\n");
        } /* if */
        watch_list(amx,calllevel);
        source_list(gettopline(curline,curline-autolist/2),autolist);
      } /* if */
    } else if (stricmp(command,"output")==0) {
      if (term_switch(0))       /* switch back to user screen */
        amx_getch();            /* if it worked, wait for a key press */
      term_switch(1);           /* switch to debugger screen */
    } else if (stricmp(command,"type")==0) {
      char symname[sNAMEMAX+1],*ptr;
      int len;
      for (ptr=params; *ptr!='\0' && *ptr!=' ' && *ptr!='\t'; ptr++)
        /* nothing */;
      len=(int)(ptr-params);
      if (len==0 || len>sNAMEMAX) {
        amx_printf("\tInvalid (or missing) symbol name\n");
      } else {
        strncpy(symname,params,len);
        symname[len]='\0';
        params=skipwhitespace(ptr);
        /* first look for a local symbol, if not found for a global symbol */
        sym=find_symbol(&vartab,symname,calllevel);
        if (sym==NULL)
          sym=find_symbol(&vartab,symname,-1);
        if (sym==NULL) {
          amx_printf("\tUnknown symbol \"%s\"\n",symname);
        } else {
          if (stricmp(params,"std")==0) {
            sym->disptype=DISP_DEFAULT;
          } else if (stricmp(params,"string")==0) {
            /* check array with single dimension */
            if (!(sym->type==iARRAY || sym->type==iREFARRAY) || sym->dims!=1)
              amx_printf("\t\"string\" display type is only valid for arrays with one dimension\n");
            else
              sym->disptype=DISP_STRING;
          } else if (stricmp(params,"bin")==0) {
            sym->disptype=DISP_BIN;
          } else if (stricmp(params,"hex")==0) {
            sym->disptype=DISP_HEX;
          } else if (stricmp(params,"fixed")==0) {
            sym->disptype=DISP_FIXED;
          } else if (stricmp(params,"float")==0) {
            sym->disptype=DISP_FLOAT;
          } else {
            amx_printf("\tUnknown (or missing) display type\n");
          } /* if */
          watch_list(amx,calllevel);
        } /* if */
      } /* if */
    } else if (stricmp(command,"w")==0 || stricmp(command,"watch")==0) {
      /* see whether this is a new watch, or whether one is replaced */
      if (isdigit(*params)) {
        i=atoi(params);
        params=skipvalue(params);
      } else {
        i = -1;
      } /* if */
      if (strlen(params)==0) {
        amx_printf("Missing variable name\n");
        continue;
      } /* if */
      /* is there space for another watch? (only when using terminal support) */
      if (i<0 && terminal && watch_count()>=WATCHLINES) {
        int w=watch_count()+1;  /* new number of watches */
        int l=listlines;
        int c=screenlines-w-l-3;
        if (c<=1) {
          /* command window cannot shrink, shrink code listing instead */
          c=2;
          l=screenlines-w-c-3;
          if (l<5) {
            /* code listing cannot shrink either, give a message */
            amx_printf("Too many watches, sorry\n");
            continue;
          } /* if */
        } /* if */
        watchlines=w;
        listlines=l;
        term_refresh(); /* reset */
        source_list(gettopline(curline,curline-autolist/2),autolist);
      } /* if */
      result=watch_set(i,params);
      if (result>=0)
        watch_list(amx,calllevel);
      else
        amx_printf("Invalid watch\n");
    } else if (stricmp(command,"cw")==0 || stricmp(command,"cwatch")==0) {
      if (*params=='*') {
        /* clear all watches */
        watch_init();
      } else if (isdigit(*params)) {
        watch_clear(atoi(params));
      } else {
        amx_printf("\tInvalid command syntax, use \"? cw\" for details\n");
      } /* if */
      if (terminal && watchlines>WATCHLINES) {
        int w,l,c;
        w=watch_count();        /* new number of watches */
        if (w<WATCHLINES)
          w=WATCHLINES;
        l=LISTLINES;            /* desired number of lines in code listing */
        c=screenlines-w-l-3;
        if (c<=1) {
          /* command window too small, shrink code listing */
          c=2;
          l=screenlines-w-c-3;
        } /* if */
        watchlines=w;
        listlines=l;
        term_refresh();    /* reset */
        source_list(gettopline(curline,curline-autolist/2),autolist);
      } /* if */
      watch_list(amx,calllevel);
    } else {
      amx_printf("\tInvalid command, use \"?\" to view all commands\n");
    } /* if */
  } /* for */
}

static int abortflagged = 0;
void sigabort(int sig)
{
  abortflagged=1;
  signal(sig,sigabort); /* re-install the signal handler */
}

int AMXAPI amx_InternalDebugProc(AMX *amx)
{
static int tracelevel;
static int calllevel;
static SYMBOL *curfunc;
static SYMBOL *curvar;
  int cmd,i,vclass,type,lvl;
  unsigned short flags;
  char *msg;

  switch (amx->dbgcode) {
  case DBG_INIT:
    assert(amx->flags==AMX_FLAG_BROWSE);
    /* check whether we should run */
    amx_Flags(amx,&flags);
    if ((flags & AMX_FLAG_DEBUG)==0 || curfileno!=-1)
      return AMX_ERR_DEBUG;     /* the debugger cannot run */
    /* intialize the file table and other global variables */
    file_init();
    cursource=NULL;
    curfileno=-1;
    stopline=0;
    break_init();
    watch_init();
    functab.next=NULL;
    vartab.next=NULL;
    if (amx_termctl(0,0)) {
      curtopline=0;
      autolist=listlines;
      term_switch(1);           /* switch to the debugger console */
      term_open();
      term_switch(0);           /* switch back to the program output */
    } /* if */
    /* initialize statics here */
    calllevel=0;
    curfunc=NULL;
    curvar=NULL;
    tracelevel=calllevel+1;     /* step INTO first function */
    break;
  case DBG_FILE:        /* file number in curfile, filename in dbgname */
    assert(amx->flags==(AMX_FLAG_DEBUG | AMX_FLAG_BROWSE));
    /* file should not already be set */
    assert(file_find((int)amx->curfile)==NULL);
    if (file_add(amx->dbgname,(int)amx->curfile)==NULL)
      amx_printf("\nInsufficient memory to build a file list\n");
    break;
  case DBG_LINE:        /* line number in curline, file number in curfile */
    if ((amx->flags & AMX_FLAG_BROWSE)!=0) {
      /* check whether there is a function symbol that needs to be adjusted */
      if (curfunc!=NULL) {
        curfunc->line=(int)amx->curline;
        curfunc->file=(int)amx->curfile;
      } /* if */
      curfunc=NULL;
      break;            /* ??? could build a list with valid breakpoints */
    } /* if */
    curline=(int)amx->curline-1;
    /* check breakpoints */
    msg=NULL;
    if ((int)amx->curline==stopline) {
      msg="STOPPED at line %d\n";
      i=(int)amx->curline;
      tracelevel=calllevel;
      stopline=0;
    } else if ((i=break_check(amx,(int)amx->curline,(int)amx->curfile))>=0) {
      msg="STOPPED at breakpoint %d\n";
      tracelevel=calllevel;
    } else if (abortflagged) {
      msg="STOPPED because of break request\n";
      tracelevel=calllevel;
      abortflagged=0;
    } /* if */
    if (tracelevel<calllevel)
      break;
    term_switch(1);             /* switch to the debugger console */
    if (msg!=NULL)
      amx_printf(msg,i);        /* print breakpoint number */
    assert(amx->curfile>=0);
    if (curfileno!=(int)amx->curfile) {
      NAMELIST *file;
      curfileno=(int)amx->curfile;
      if (cursource!=NULL)
        source_free(cursource);
      file=file_find(curfileno);
      cursource=(file!=NULL) ? source_load(file->name) : NULL;
      if (cursource==NULL) {
        amx_printf("\nCritical error: source file not found (or insufficient memory)\n");
        exit(1);
      } /* if */
    } /* if */
    #if !defined VT100
      if (terminal) {
        int csrx,csry;
        amx_wherexy(&csrx,&csry);
        if (csry>=screenlines)
          term_refresh();
      } /* if */
    #endif
    assert(cursource[curline]!=NULL);
    watch_list(amx,calllevel);
    source_list(gettopline(curline,curline-autolist/2),autolist);
    cmd=docommand(amx,calllevel);
    term_switch(0);             /* switch back to the program output */
    switch (cmd) {
    case GO:
      tracelevel=-1;
      break;
    case GO_RET:
      tracelevel=calllevel-1;
      break;
    case NEXT:
      tracelevel= calllevel;    /* step OVER functions */
      break;
    case STEP:
      tracelevel= calllevel+1;  /* step INTO functions */
    } /* switch */
    break;
  case DBG_SYMBOL:      /* address in dbgaddr, class/type in dbgparam,
                         * symbol name in dbgname */
    vclass=(int)(amx->dbgparam>>8);
    type=(int)amx->dbgparam & 0xff;
    if (type==iFUNCTN) {
      /* function */
      assert(vclass==0);
      assert(amx->flags==(AMX_FLAG_DEBUG | AMX_FLAG_BROWSE));
      curfunc=add_symbol(&functab,amx->dbgname,type,amx->dbgaddr,vclass,-1);
    } else {
      assert((amx->flags & AMX_FLAG_DEBUG)!=0);
      /* for local variables, must modify address relative to frame */
      if (vclass==1)
        amx->dbgaddr += amx->frm;
      lvl= ((amx->flags & AMX_FLAG_BROWSE)!=0) ? -1 : calllevel;
      /* if a static variable is declared inside a loop, it was not removed
       * at the end of the loop, so we do not have to declared it again
       */
      if (vclass==2 && find_symbol(&vartab,amx->dbgname,lvl)!=NULL)
        break;
      curvar=add_symbol(&vartab,amx->dbgname,type,amx->dbgaddr,vclass,lvl);
    } /* if */
    break;
  case DBG_SRANGE:
    /* check whether there is a symbol that needs to be adjusted */
    if (curvar!=NULL) {
      curvar->length[(int)amx->dbgaddr]=(int)amx->dbgparam;
      if (curvar->dims<(int)amx->dbgaddr+1)
        curvar->dims=(int)amx->dbgaddr+1;
      if (amx->dbgaddr==0)
        curvar=NULL;    /* last dimension handled */
    } /* if */
    break;
  case DBG_SYMTAG:
    /* check whether there is a symbol that needs to be adjusted */
    if (curvar!=NULL) {
      char tagname[sNAMEMAX+1];
      curvar->tag=(int)amx->dbgparam;
      /* check whether this tag is for floating point, fixed point or boolean */
      if (amx_FindTagId(amx,curvar->tag,tagname)==AMX_ERR_NONE) {
        if (stricmp(tagname,"bool")==0)
          curvar->disptype=DISP_BOOL;
        else if (stricmp(tagname,"float")==0)
          curvar->disptype=DISP_FLOAT;
        else if (stricmp(tagname,"fixed")==0)
          curvar->disptype=DISP_FIXED;
      } /* if */
    } /* if */
    break;
  case DBG_CLRSYM:      /* stk = stack address below which locals should be removed */
    assert((amx->flags & (AMX_FLAG_DEBUG | AMX_FLAG_BROWSE))==AMX_FLAG_DEBUG);
    delete_symbol(&vartab,amx->stk,calllevel);
    break;
  case DBG_CALL:        /* function call */
    assert((amx->flags & (AMX_FLAG_DEBUG | AMX_FLAG_BROWSE))==AMX_FLAG_DEBUG);
    assert(calllevel>=0);
    if (calllevel<MAXSTACKTRACE)
      callstack[calllevel]=amx->dbgaddr;
    calllevel++;
    break;
  case DBG_RETURN:      /* function returns */
    assert((amx->flags & (AMX_FLAG_DEBUG | AMX_FLAG_BROWSE))==AMX_FLAG_DEBUG);
    term_switch(1);     /* switch to debugger console */
    amx_printf(STR_PROMPT "Function returns: %ld\n",(long)amx->dbgparam);
    term_switch(0);     /* switch back to the program output */
    calllevel--;
    delete_symbol(&vartab,amx->stk,calllevel);
    if (tracelevel>calllevel)
      tracelevel=calllevel;
    break;
  case DBG_TERMINATE:   /* program ends, either because the "entry point"
                         * function returns, or because of a hard exit */
    assert((amx->flags & (AMX_FLAG_DEBUG | AMX_FLAG_BROWSE))==AMX_FLAG_DEBUG);
    if (amx->dbgparam==AMX_ERR_SLEEP) {
      term_switch(1);   /* switch to debugger console */
      amx_printf(STR_PROMPT "AMX put to sleep: tag=%ld, value=%ld\n",(long)amx->alt,(long)amx->pri);
      term_switch(0);   /* switch back to the program output */
    } else {
      calllevel=0;
      tracelevel=0;
      /* ??? save breakpoints on exit */
      /* ??? save watches */
      if (terminal)
        term_close();
    } /* if */
    curfileno=-1;
    break;
  } /* switch */
  return AMX_ERR_NONE;
}

#if !defined amx_Init

static void *loadprogram(AMX *amx,char *filename)
{
  FILE *fp;
  AMX_HEADER hdr;
  void *program;

  if ((fp = fopen(filename,"rb")) != NULL) {
    fread(&hdr, sizeof hdr, 1, fp);
    amx_Align32((uint32_t *)&hdr.stp);
	amx_Align32((uint32_t *)&hdr.size);
    if ((program = malloc((int)hdr.stp)) != NULL) {
      rewind(fp);
      fread(program, 1, (int)hdr.size, fp);
      fclose(fp);
      memset(amx, 0, sizeof *amx);
      amx_SetDebugHook(amx, amx_InternalDebugProc);
      if (amx_Init(amx,program) == AMX_ERR_NONE)
        return program;
      free(program);
    } /* if */
  } /* if */
  return NULL;
}

int main(int argc,char *argv[])
{
extern AMX_NATIVE_INFO core_Natives[];
extern AMX_NATIVE_INFO console_Natives[];

  AMX amx;
  cell ret;
  int err;
  void *program;
  unsigned short flags;
  char filename[_MAX_PATH],*ptr;

  amx_printf("Small command line debugger\n\n");
  /* get filename */
  if (argc == 2) {
    strcpy(filename,argv[1]);
  } else {
    amx_printf("File: ");
    amx_gets(filename,sizeof filename);
    if ((ptr=strchr(filename,'\n'))!=NULL)
      *ptr='\0';                /* strip newline characters */
  } /* if */
  if (strlen(filename)==0)
    return 1;
  if ((program = loadprogram(&amx,filename)) == NULL) {
    /* try adding an extension */
    strcat(filename, ".amx");
    if ((program = loadprogram(&amx,filename)) == NULL) {
      amx_printf("Cannot load the program file \"%s\"\n", filename);
      return 1;
    } /* if */
  } /* if */
  amx_Flags(&amx,&flags);
  if ((flags & AMX_FLAG_DEBUG)==0) {
    amx_printf("This program has no debug information\n");
    return 1;
  } /* if */
  /* switch the current directory to that of the debugged script */
  if ((ptr=strrchr(filename,'/'))!=NULL) {
    extern int chdir(const char *path);
    char dir[_MAX_PATH];
    int len=(int)(ptr-filename);
    if (len<sizeof dir) {
      strncpy(dir,filename,len);
      dir[len]='\0';
      chdir(dir);
    } /* if */
  } /* if */

  signal(SIGINT,sigabort);

  amx_Register(&amx, core_Natives, -1);
  err = amx_Register(&amx, console_Natives, -1);

  if (err == AMX_ERR_NONE) {
    err = amx_Exec(&amx, &ret, AMX_EXEC_MAIN, 0);
    while (err == AMX_ERR_SLEEP)
      err = amx_Exec(&amx, &ret, AMX_EXEC_CONT, 0);
  } /* if */

  if (err != AMX_ERR_NONE)
    amx_printf("Run time error %d on line %ld\n", err, amx.curline);
  else
    amx_printf("Normal termination, return value %ld\n", (long)ret);

  if (cursource!=NULL)
    source_free(cursource);
  delete_allsymbols(&functab);
  delete_allsymbols(&vartab);
  file_init();          /* frees the file list */
  break_init();         /* frees all existing breakpoints */
  free(program);

  return 0;
}

#endif /* !defined amx_Init */
